@echo off
cd /d "%~dp0"
python run.py
if errorlevel 1 (
  echo.
  echo Could not start. Ensure Python 3 is installed and available as "python".
  pause
)
