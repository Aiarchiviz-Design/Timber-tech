// v3.19 regression: (1) depth-correct picking/triangulation used by the GPU depth-buffer renderer, (2) no stray extended web/post solids.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const bootstrap=fs.readFileSync('tests/verify-walls.cjs','utf8').split('function fixture')[0];
eval(bootstrap.replace("const fs=require('fs'),vm=require('vm'),assert=require('assert');",'').replace('const run=','var run='));
run(fs.readFileSync('dist/renderer.js','utf8'));
// --- triangulation of concave polygons: area is preserved
run('var L=[{x:0,y:0},{x:10,y:0},{x:10,y:4},{x:4,y:4},{x:4,y:10},{x:0,y:10}];var tri=glTriangulate(L);var area=0;for(let k=0;k<tri.length;k+=3){const a=L[tri[k]],b=L[tri[k+1]],c=L[tri[k+2]];area+=Math.abs((b.x-a.x)*(c.y-a.y)-(c.x-a.x)*(b.y-a.y))/2}');
assert.equal(run('tri.length'),12,'L polygon -> 4 triangles');assert(Math.abs(run('area')-64)<1e-9,'concave triangulation covers exactly the polygon area (64)');
// --- picking uses depth, not list order: a long board nearer the camera must win even when the painter order puts it first
for(const projection of ['orthographic','perspective']){
  run(`sceneCamera.projection="${projection}";sceneCamera.distance=10000;`);
  run('var far={id:"FAR",points:[{x:0,y:0,depth:-500},{x:100,y:0,depth:-500},{x:100,y:100,depth:-500},{x:0,y:100,depth:-500}]};'+
      'var near={id:"NEAR",points:[{x:40,y:40,depth:800},{x:200,y:40,depth:800},{x:200,y:60,depth:800},{x:40,y:60,depth:800}]};');
  run('projectedFaces=[near,far]');   // painter order says FAR is "in front" (drawn last)
  assert.equal(run('pickSolid({x:50,y:50}).id'),'NEAR',projection+': nearest surface wins regardless of sort order');
  run('projectedFaces=[far,near]');assert.equal(run('pickSolid({x:50,y:50}).id'),'NEAR');
  assert.equal(run('pickSolid({x:10,y:10}).id'),'FAR','point outside the near board still hits the far one');
  assert.equal(run('pickSolid({x:500,y:500})'),null);
}
// --- a tilted long board crossing a short one: the winner changes along the board (per-pixel, not per-face, ordering)
run('sceneCamera.projection="orthographic";var tilt1={id:"LONG",points:[{x:0,y:0,depth:0},{x:100,y:0,depth:0},{x:100,y:10,depth:1000},{x:0,y:10,depth:1000}]};var flat={id:"SHORT",points:[{x:0,y:0,depth:500},{x:100,y:0,depth:500},{x:100,y:10,depth:500},{x:0,y:10,depth:500}]};projectedFaces=[tilt1,flat]');
assert.equal(run('pickSolid({x:50,y:1}).id'),'SHORT');assert.equal(run('pickSolid({x:50,y:9}).id'),'LONG');
// --- renderer falls back to the painter when WebGL is unavailable (this harness has none)
assert.equal(run('glInit()'),false);
// --- geometry: web/post ends that find no chord must not keep the 4x-depth extension (was a 360 mm spike on U-shaped roofs)
run('model.elements=[{id:"R-U",type:"roof",story:"s0",layer:"Structure",points:[{x:0,y:0},{x:10000,y:0},{x:10000,y:4000},{x:16000,y:4000},{x:16000,y:12000},{x:10000,y:12000},{x:10000,y:17000},{x:6000,y:17000},{x:6000,y:10000},{x:0,y:10000}],pitch:25,height:3000,overhang:450,thickness:200,roofType:"hip",roofFraming:{system:"trusses",hipSetback:1200}}];var h=generateRoofFraming(model.elements[0]);'+
 'var worst=0;for(const m of h.members){const A=m.a,B=m.b,d={x:B.x-A.x,y:B.y-A.y,z:B.z-A.z},len=Math.hypot(d.x,d.y,d.z),u={x:d.x/len,y:d.y/len,z:d.z/len};for(const f of roofMemberFaces(m))for(const p of f){const t=(p.x-A.x)*u.x+(p.y-A.y)*u.y+(p.z-A.z)*u.z;worst=Math.max(worst,-t,t-len)}}');
run('var worst2=0;for(const m of h.members){const A=m.a,B=m.b,d={x:B.x-A.x,y:B.y-A.y,z:B.z-A.z},len=Math.hypot(d.x,d.y,d.z),u={x:d.x/len,y:d.y/len,z:d.z/len};let w=0;for(const f of roofMemberFaces(m))for(const p of f){const t=(p.x-A.x)*u.x+(p.y-A.y)*u.y+(p.z-A.z)*u.z;w=Math.max(w,-t,t-len)}'+
 // a plumb/miter cut on a sloped top chord legitimately reaches (section depth * tan(slope)) past its node
 'const slope=Math.atan2(Math.abs(d.z),Math.hypot(d.x,d.y)),allow=/top chord/i.test(m.type)?Math.max(190,(m.depth||190)*Math.tan(slope)):190;worst2=Math.max(worst2,w-allow+190)}');
assert(run('worst2')<Math.max(...[45,90,190])*1.0+1,'no member solid extends more than one section depth past its own end, beyond the plumb/miter reach of its slope (got '+run('worst2')+' mm)');
console.log('PASS: depth-based picking (ortho+perspective, per-pixel crossing), concave triangulation, painter fallback, no un-trimmed web/post extensions on U roofs');
