// v3.20: CadTech-style Three.js viewport - module logic + wiring into the classic scripts.
const fs=require('fs'),assert=require('assert'),path=require('path');
const dist=p=>fs.readFileSync(path.join(__dirname,'..','dist',p),'utf8');
(async()=>{
  // --- wiring: the viewport is optional, and every hook degrades to the previous renderer
  const app=dist('app.js'),cam=dist('camera.js'),html=dist('index.html'),roof=dist('roof-framing.js');
  assert(/globalThis\.cadtechViewport/.test(app)&&/vp\.sync\(\)/.test(app),'draw3D dispatches to the viewport when present');
  assert(/function draw3D\(\)\{const vp=globalThis\.cadtechViewport;if\(vp&&vp\.enabled&&vp\.sync\(\)\)\{cameraUI\(\);return\}drawViewportGround\(\)/.test(app),'old renderer path kept as the fallback');
  assert(/cadtechViewport\?\.hide\(\)/.test(app),'viewport hides outside 3D views');
  assert(/function setLegacyCamera\(o,t,s\)/.test(cam)&&/cadtechViewport\?\.requestFit\(\)/.test(cam),'camera.js exposes the setter and refit hook');
  assert(/type="module" src="viewport3d\.js/.test(html),'module script is loaded');
  assert(/memberType=m\.type/.test(app),'wall framing faces carry their member type (plates vs studs)');
  assert(/assembly:m\.assembly/.test(roof),'roof framing faces carry their truss assembly (labels)');
  for(const f of ['three.module.js','three.core.js','OrbitControls.js','THREE-LICENSE.txt'])assert(fs.existsSync(path.join(__dirname,'..','dist','vendor',f)),'vendor/'+f);
  // --- palette and recipe copied from CadTech's viewer.js
  const vp=dist('viewport3d.js');
  for(const k of ["'#f8fafc'","PerspectiveCamera(38","HemisphereLight(0xffffff,0x94a3b8,2.2)","DirectionalLight(0xffffff,2.5)","DirectionalLight(0xbfe0ff,1.8)","roughness:.82","Girder:'#ffba67'","'Front jack':'#66afff'","enableDamping=true","screenSpacePanning=true"])assert(vp.includes(k),'CadTech recipe: '+k);
  // --- triangulation (pure function) on a concave and a vertical polygon
  const {triangulate}=await import('../dist/viewport3d.js');
  const area=(P,tri)=>{let a=0;for(let k=0;k<tri.length;k+=3){const A=P[tri[k]],B=P[tri[k+1]],C=P[tri[k+2]],u=[B.x-A.x,B.y-A.y,B.z-A.z],v=[C.x-A.x,C.y-A.y,C.z-A.z];a+=Math.hypot(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])/2}return a};
  const L=[[0,0],[10,0],[10,4],[4,4],[4,10],[0,10]].map(([x,y])=>({x,y,z:2})),tl=triangulate(L);
  assert.equal(tl.length,12);assert(Math.abs(area(L,tl)-64)<1e-9,'concave L polygon area preserved');
  const wall=[[0,0],[5,0],[5,3],[0,3]].map(([x,z])=>({x,y:7,z})),tw=triangulate(wall);assert.equal(tw.length,6);assert(Math.abs(area(wall,tw)-15)<1e-9,'vertical wall quad');
  const tilted=[{x:0,y:0,z:0},{x:4,y:0,z:0},{x:4,y:3,z:2},{x:0,y:3,z:2}];assert(Math.abs(area(tilted,triangulate(tilted))-4*Math.hypot(3,2))<1e-9,'sloped roof quad');
  assert.deepEqual(triangulate([{x:0,y:0,z:0},{x:1,y:1,z:1},{x:2,y:2,z:2}]),[],'degenerate polygon -> nothing');
  console.log('PASS: CadTech recipe present, fallback wiring intact, triangulation of concave / vertical / sloped faces');
})().catch(e=>{console.error(e);process.exit(1)});
