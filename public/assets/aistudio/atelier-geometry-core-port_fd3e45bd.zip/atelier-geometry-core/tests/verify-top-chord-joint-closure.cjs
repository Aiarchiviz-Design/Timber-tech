const fs=require('fs'),vm=require('vm'),assert=require('assert');
const bootstrap=fs.readFileSync('tests/verify-walls.cjs','utf8').split('function fixture')[0];
eval(bootstrap.replace("const fs=require('fs'),vm=require('vm'),assert=require('assert');",'').replace('const run=','var run='));
// Top-chord connections: (1) no top chord may be dropped, (2) exposed ends are true vertical
// plumb cuts (nothing of the solid lies beyond the vertical plane through the end node),
// (3) two top chords sharing a node close on the same plane with identical cap corners
// (no triangular gaps/slivers at ridge or hip bends).
const rot=(pts,deg,cx=6500,cy=4500)=>pts.map(p=>{const a=deg*Math.PI/180,x=p.x-cx,y=p.y-cy;return {x:Math.round((cx+x*Math.cos(a)-y*Math.sin(a))*10)/10,y:Math.round((cy+x*Math.sin(a)+y*Math.cos(a))*10)/10}});
const rect=[{x:0,y:0},{x:13000,y:0},{x:13000,y:9000},{x:0,y:9000}];
const L=[[0,0],[12000,0],[12000,5000],[6000,5000],[6000,10000],[0,10000]].map(p=>({x:p[0],y:p[1]}));
const cases=[['hip',rect],['gable',rect],['hip-L',L],['hip-rot',rot(rect,33)],['hip-L-rot',rot(L,-20)]];
let nodes=0,ends=0;
for(const [type,sp] of [['hip',609.6],['hip',600],['gable',600]])for(const [name,pts] of cases){
  if(type==='gable'&&name!=='gable')continue; if(type==='hip'&&name==='gable')continue;
  const rt=name==='gable'?'gable':'hip';
  run(`model.elements=[{id:'R',type:'roof',story:'s0',layer:'Structure',points:${JSON.stringify(pts)},pitch:25,height:3000,overhang:600,thickness:200,roofType:'${rt}',roofFraming:{system:'trusses',spacing:${sp}}}];var h=generateRoofFraming(model.elements[0]);`);
  const res=run(`(()=>{
    const tops=h.members.filter(m=>/top chord/i.test(m.type));let bad=[],nodes=0,ends=0;
    const near=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z)<.05;
    // A cleanly cut top chord is a box with planar ends: 6 faces and a 4-sided profile. A square-ended
    // blank trimmed by a plumb plane keeps a bevelled V notch (6-sided profile / 7+ faces).
    for(const m of tops){const f=m.cutFaces||roofMemberFaces(m);const short=Math.hypot(m.b.x-m.a.x,m.b.y-m.a.y,m.b.z-m.a.z)<m.depth*2;// a seam chord shorter than two section depths is legitimately bounded by two crossing miters
      if(!short&&f.length!==6)bad.push('notched ends (faces='+f.length+') '+m.id+' '+m.type);
      if(!short&&m.cutProfiles&&m.cutProfiles[0].length!==4)bad.push('notched profile ('+m.cutProfiles[0].length+' sides) '+m.id);}
    for(const m of tops){const f=m.cutFaces||roofMemberFaces(m);if(!f.flat().every(p=>[p.x,p.y,p.z].every(Number.isFinite)))bad.push('non-finite '+m.id);
      const dx=m.b.x-m.a.x,dy=m.b.y-m.a.y,hl=Math.hypot(dx,dy);
      for(const [i,end] of ['a','b'].entries()){const c=(m.endCuts||[]).find(c=>c&&c.end===end);if(!c||c.kind!=='plumb-cut'||c.plane!=='vertical'||hl<1)continue;ends++;
        const p=m[end],o={x:dx/hl*(i?1:-1)*-1,y:dy/hl*(i?1:-1)*-1};// inward dir
        const worst=Math.max(...f.flat().map(v=>-((v.x-p.x)*o.x+(v.y-p.y)*o.y)));if(worst>.05)bad.push('exposed end not plumb '+m.id+end+' overshoot '+worst.toFixed(2));}}
    for(const m of tops)for(const j of m.jointConnections||[]){if(j.kind!=='top-chord-miter')continue;const q=tops.find(t=>t.id===j.memberId);if(!q||q.id<m.id)continue;
      const pm=near(m.a,q.a)?m.a:near(m.a,q.b)?m.a:near(m.b,q.a)||near(m.b,q.b)?m.b:null;if(!pm)continue;nodes++;
      const fm=m.cutFaces.flat(),fq=q.cutFaces.flat();
      // corner points of each solid that lie within one member-depth of the node
      const cap=(f)=>f.filter(v=>Math.hypot(v.x-pm.x,v.y-pm.y,v.z-pm.z)<m.depth*1.2);
      const A=cap(fm),B=cap(fq);
      const miss=A.filter(a=>!B.some(b=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z)<.05)&&A.some(x=>x!==a)).length;
      // every cap corner of one member that is on the shared plane must also exist on the other
      const shared=A.filter(a=>B.some(b=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z)<.05)).length;
      if(shared<4)bad.push('gap at node '+m.id+'/'+q.id+' shared corners '+shared);}
    return {tops:tops.length,bad,nodes,ends};})()`);
  assert(res.tops>10,`${name}: top chords present (${res.tops})`);
  assert.equal(res.bad.length,0,`${type} ${name} @${sp}: ${res.bad.slice(0,4).join('; ')}`);
  nodes+=res.nodes;ends+=res.ends;
}
assert(nodes>20&&ends>40,`enough joints checked (${nodes} nodes, ${ends} exposed ends)`);
console.log(`PASS: ${nodes} shared top-chord nodes close on one plane; ${ends} exposed ends are true vertical plumb cuts; no top chords dropped.`);
