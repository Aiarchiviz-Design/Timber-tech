// Rotated/diagonal roofs: exposed top-chord ends must be vertical plumb planes that follow the
// member's full horizontal direction. Behavioural check lives in the joint-closure test
// (it includes 33 deg and -20 deg rotated hip roofs); run it here.
require('./verify-top-chord-joint-closure.cjs');
console.log('PASS: rotated/diagonal roof chords keep true plumb ends (see joint-closure test).');
