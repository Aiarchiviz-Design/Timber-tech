const fs=require('fs'),vm=require('vm'),assert=require('assert');
const nodes=new Map();const ctx=new Proxy({},{get:()=>()=>{}});
function node(s){if(!nodes.has(s))nodes.set(s,{style:{},dataset:{},value:'0',classList:{add(){},remove(){},toggle(){},contains(){return false}},querySelectorAll:()=>[],querySelector:()=>null,insertAdjacentHTML(){},addEventListener(){},getContext:()=>ctx,getBoundingClientRect:()=>({width:0,height:0}),children:[],close(){},showModal(){},click(){}});return nodes.get(s)}
const box={document:{body:node('body'),querySelector:node,querySelectorAll:()=>[],addEventListener(){},createElement:node},ResizeObserver:class{observe(){}},devicePixelRatio:1,console,setTimeout,clearTimeout,URL,Blob};vm.createContext(box);
vm.runInContext(fs.readFileSync('dist/joins.js','utf8'),box);
vm.runInContext(fs.readFileSync('dist/framing.js','utf8'),box);
vm.runInContext(fs.readFileSync('dist/camera.js','utf8'),box);
vm.runInContext(fs.readFileSync('dist/advanced.js','utf8'),box);
vm.runInContext(fs.readFileSync('dist/editing.js','utf8'),box);
vm.runInContext(fs.readFileSync('dist/roof-footprint.js','utf8'),box);
vm.runInContext(fs.readFileSync('dist/roof.js','utf8'),box);
vm.runInContext(fs.readFileSync('dist/roof-framing.js','utf8'),box);
vm.runInContext(fs.readFileSync('dist/app.js','utf8'),box);
vm.runInContext('render=()=>{}; properties=()=>{}; navigator=()=>{}; toast=()=>{};',box);
function run(s){return vm.runInContext(s,box)}
assert.equal(run('model.elements.length'),23);
assert.equal(run('heightOf(model.elements[0])'),3048);
run('setStoryHeight("s0",3400)');assert.equal(run('heightOf(model.elements[0])'),3400);assert.equal(run('model.stories[1].elevation'),3400);assert.equal(run('model.stories[2].elevation'),6448);
run('undo()');assert.equal(run('model.stories[0].height'),3048);
run('redo()');assert.equal(run('model.stories[0].height'),3400);
run('let testHost=model.elements[0]; let testOpening=hosted(testHost)[0]; let offsetBefore=testOpening.offset; testHost.a.x+=1000; testHost.b.x+=1000;');assert.equal(run('openingPoint(testOpening).x'),3300);
assert.throws(()=>run('validateOpening({...testOpening,offset:0})'),/host wall/);
assert.throws(()=>run('validateOpening({...testOpening,height:5000})'),/wall top/);
assert.throws(()=>run('validateOpening({...testOpening,id:"NEW",offset:2300})'),/overlap/);
run('width=1000;height=700;baseScale=.04;view="3d";solidModel()');assert(run('projectedFaces.length')>100);
const obj=run('generateOBJ()');assert(obj.includes('o N-001'));assert(obj.includes('v '));assert(obj.includes('f '));
assert(run('validateProject(clone(model)).elements.length')===23);
assert.throws(()=>run('validateProject({version:1,stories:[],elements:[]})'),/supported/);
run('selected=["W-001"]; edit("copy"); place({x:0,y:0}); place({x:0,y:15000})');assert.equal(run('model.elements.length'),26);assert.equal(run('hosted(model.elements.find(e=>e.id===selected[0])).length'),2);
run('edit("delete")');assert.equal(run('model.elements.length'),23);
console.log('PASS: synchronized story heights, undo/redo, host movement, opening constraints, solid generation, OBJ, project validation, copy/delete dependencies');


