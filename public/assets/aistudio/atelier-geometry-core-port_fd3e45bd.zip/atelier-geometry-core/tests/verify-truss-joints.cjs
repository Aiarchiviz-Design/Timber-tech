const fs=require('fs'),vm=require('vm'),assert=require('assert');const bootstrap=fs.readFileSync('tests/verify-walls.cjs','utf8').split('function fixture')[0];eval(bootstrap.replace("const fs=require('fs'),vm=require('vm'),assert=require('assert');",'').replace('const run=','var run='));
run('var test=[{id:"a",roofId:"R",assembly:"T",type:"Truss top chord",a:{x:0,y:0,z:0},b:{x:1000,y:0,z:1000},width:45,depth:190,length:Math.sqrt(2)*1000},{id:"b",roofId:"R",assembly:"T",type:"Truss top chord",a:{x:1000,y:0,z:1000},b:{x:2000,y:0,z:0},width:45,depth:190,length:Math.sqrt(2)*1000}];joinTrussMembers(test)');
assert(run('test.every(m=>roofMemberFaces(m).flat().filter(p=>Math.abs(p.x-1000)<.01).length>=4)'));
run('var webtest=[{id:"c",assembly:"U",type:"Truss bottom chord",a:{x:0,y:0,z:0},b:{x:2000,y:0,z:0},width:45,depth:190,length:2000},{id:"w",assembly:"U",type:"Truss web",a:{x:500,y:0,z:0},b:{x:1000,y:0,z:1000},width:45,depth:90,length:Math.hypot(500,1000)}];joinTrussMembers(webtest)');
assert(run('roofMemberFaces(webtest[1]).flat().every(p=>p.z>=95-.01)'));
assert(run('webtest[1].cutLength>0&&Number.isFinite(webtest[1].cutLength)'));
console.log('PASS: peak miters share the same plane; web faces stop at bottom chord face; cut lengths finite');
run('var rafterPair=[{id:"a",roofId:"R",type:"Rafter",a:{x:0,y:0,z:0},b:{x:1000,y:0,z:1000},width:45,depth:190,length:Math.hypot(1000,1000)},{id:"b",roofId:"R",type:"Rafter",a:{x:1000,y:0,z:1000},b:{x:2000,y:0,z:0},width:45,depth:190,length:Math.hypot(1000,1000)}];finishRoofConnections(rafterPair)');
assert(run('rafterPair.every(m=>roofMemberFaces(m).flat().filter(p=>Math.abs(p.x-1000)<.01).length>=4)'));
assert(run('roofMemberFaces(rafterPair[0]).flat().every(p=>p.x<=1000+.001)'));
assert(run('roofMemberFaces(rafterPair[1]).flat().every(p=>p.x>=1000-.001)'));
run('var receiving=[{id:"j",roofId:"R",type:"Rafter",a:{x:1000,y:0,z:0},b:{x:0,y:0,z:1000},width:45,depth:190,length:Math.hypot(1000,1000)},{id:"h",roofId:"R",type:"Hip / valley member",a:{x:0,y:-1000,z:1000},b:{x:0,y:1000,z:1000},width:90,depth:190,length:2000}];finishRoofConnections(receiving)');
assert(run('roofMemberFaces(receiving[0]).flat().every(p=>p.x>=45-.01)'));
assert(run('roofMemberFaces(receiving[0]).some(f=>f.every(p=>Math.abs(p.x-45)<.01))'));
assert(run('receiving[0].cutLength<receiving[0].length+190'));
console.log('PASS: rafter plumb-cut ends retain the member side; receiving hip cuts remain closed');

// Every generated web/post must record its chord joint and finish flush at the chord face.
run('var fullJoint=[{id:"tc",assembly:"V",type:"Truss top chord",a:{x:0,y:0,z:1000},b:{x:2000,y:0,z:1000},width:45,depth:190,length:2000},{id:"bc",assembly:"V",type:"Truss bottom chord",a:{x:0,y:0,z:0},b:{x:2000,y:0,z:0},width:45,depth:190,length:2000},{id:"web",assembly:"V",type:"Truss web",a:{x:1000,y:0,z:0},b:{x:1000,y:0,z:1000},width:45,depth:90,length:1000}];joinTrussMembers(fullJoint)');
assert(run('fullJoint.find(m=>m.id==="web").jointConnections.some(j=>j.memberId==="bc"&&j.kind==="web-to-chord")'));
assert(run('fullJoint.find(m=>m.id==="web").jointConnections.some(j=>j.memberId==="tc"&&j.kind==="web-to-chord")'));
assert(run('fullJoint.find(m=>m.id==="web").joinery==="Web/post end trimmed flush to chord face"'));
console.log('PASS: web-to-top/bottom chord connections are explicitly tracked and trimmed flush');
