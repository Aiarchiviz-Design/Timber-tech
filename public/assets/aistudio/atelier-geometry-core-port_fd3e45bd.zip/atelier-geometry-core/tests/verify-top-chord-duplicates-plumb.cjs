const fs=require('fs'),vm=require('vm'),assert=require('assert');
const bootstrap=fs.readFileSync('tests/verify-walls.cjs','utf8').split('function fixture')[0];
eval(bootstrap.replace("const fs=require('fs'),vm=require('vm'),assert=require('assert');",'').replace('const run=','var run='));
// Exact duplicate top chords should collapse to one physical member, while a
// separate girder ply offset by one member width must be retained.
run(`var tcA={id:'A',roofId:'R',type:'Common truss top chord',assembly:'TR-A',a:{x:0,y:0,z:0},b:{x:1000,y:0,z:500},width:45,depth:190,length:1118.0339};
var tcB={id:'B',roofId:'R',type:'Common truss top chord',assembly:'TR-B',a:{x:0,y:0,z:0},b:{x:1000,y:0,z:500},width:45,depth:190,length:1118.0339};
var ply={id:'C',roofId:'R',type:'Girder truss top chord',assembly:'GIRDER-2',a:{x:0,y:45,z:0},b:{x:1000,y:45,z:500},width:45,depth:190,length:1118.0339};
var deduped=removeDuplicateTopChords([tcA,tcB,ply]);`);
assert.equal(run('deduped.length'),2,'coincident duplicate top chord suppressed, separate ply retained');
assert(run('deduped.some(m=>m.id==="A")&&deduped.some(m=>m.id==="C")'));
// Actual geometry check: unsupported gable top-chord corners must be plumb
// cut faces, rather than a square face normal to the sloping timber.
run(`var sloped=[{id:'PLUMB-1',roofId:'R',assembly:'T1',type:'Truss top chord',a:{x:0,y:0,z:0},b:{x:1000,y:0,z:500},width:45,depth:190,length:1118.0339}];joinTrussMembers(sloped);`);
assert(run('sloped[0].endCuts&&sloped[0].endCuts.length===2&&sloped[0].endCuts.every(c=>c.kind==="plumb-cut"&&c.plane==="vertical")'));
const capAtEnd=run(`(()=>{const m=sloped[0],faces=roofMemberFaces(m),out=[];for(const end of [m.a,m.b]){const dx=m.b.x-m.a.x,dy=m.b.y-m.a.y,h=Math.hypot(dx,dy),u={x:dx/h,y:dy/h},s=end.x*u.x+end.y*u.y;out.push(faces.some(f=>f.length>=4&&f.every(p=>Math.abs(p.x*u.x+p.y*u.y-s)<.05)));}return out;})()`);
assert(capAtEnd.every(Boolean),'both ends have actual vertical plumb-cut end faces');
// Generated truss top chords must declare an end cut at both ends; receiver ends
// retain their specific plumb/receiving cut rather than being treated as square.
run(`model.elements=[{id:'R-TOP-CUT',type:'roof',story:'s0',layer:'Structure',points:[{x:0,y:0},{x:8000,y:0},{x:8000,y:5000},{x:0,y:5000}],height:3000,thickness:200,pitch:30,overhang:450,roofType:'gable',roofFraming:{system:'trusses',spacing:600}}];var generated=generateRoofFraming(model.elements[0]);`);
const topCount=run('generated.members.filter(m=>/top chord/i.test(m.type)).length');
assert(topCount>0);
assert(run('generated.members.filter(m=>/top chord/i.test(m.type)).every(m=>m.endCuts&&m.endCuts.length===2&&m.endCuts.every(c=>c.kind==="plumb-cut"||c.kind==="plumb-receiving-face"))'));
assert(run('generated.members.every(m=>Number.isFinite(m.length)&&m.length>0)'));
console.log(`PASS: duplicate top chords suppressed; separate plies retained; ${topCount} generated top chords have plumb or plumb receiving-face end cuts.`);
