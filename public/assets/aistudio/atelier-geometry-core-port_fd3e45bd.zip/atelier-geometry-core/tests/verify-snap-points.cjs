const fs=require('fs'),vm=require('vm'),assert=require('assert');const nodes=new Map(),ctx=new Proxy({},{get:()=>()=>{}});function node(s){if(!nodes.has(s))nodes.set(s,{style:{},dataset:{},value:'0',classList:{add(){},remove(){},toggle(){},contains(){return false}},querySelectorAll:()=>[],querySelector:()=>null,insertAdjacentHTML(){},addEventListener(){},getContext:()=>ctx,getBoundingClientRect:()=>({width:0,height:0}),children:[],close(){},showModal(){},click(){}});return nodes.get(s)}const box={document:{body:node("body"),querySelector:node,querySelectorAll:()=>[],addEventListener(){},createElement:node},ResizeObserver:class{observe(){}},devicePixelRatio:1,console,setTimeout,clearTimeout,URL,Blob};vm.createContext(box);for(const f of ['joins.js','framing.js','camera.js','advanced.js','trim.js','editing.js','roof-footprint.js','roof.js','truss-joints.js','hip-trusses.js','roof-framing.js','app.js'])vm.runInContext(fs.readFileSync('dist/'+f,'utf8'),box);const run=s=>vm.runInContext(s,box);run('render=()=>{};properties=()=>{};navigator=()=>{};toast=()=>{};let sampleProject=clone(model);');

function near(a,b,tol=.01){assert(Math.abs(a-b)<tol,`${a} != ${b}`)}
run('scale=1;baseScale=.1;snap=true;points=[];drag=null;tool="select";selected=[]');
// 1. a wall offers its centerline AND both finished faces
run('model.elements=[wall("W-001",[0,0],[6000,0])]');
const poly=JSON.parse(run('JSON.stringify(wallPoly(model.elements[0]))'));
assert(poly.length>=4,'wall polygon');
for(const c of poly){const s=run(`JSON.stringify(advancedSnap({x:${c.x+3},y:${c.y+3}}))`);const r=JSON.parse(s);near(r.x,c.x);near(r.y,c.y);assert.equal(run('currentSnap'),'Wall corner');}
const faceYs=[...new Set(poly.map(c=>Math.round(c.y*100)/100))];assert(faceYs.length>=2,'two faces');
for(const y of faceYs){const r=JSON.parse(run(`JSON.stringify(advancedSnap({x:3001,y:${y+4}}))`));near(r.x,3000);near(r.y,y);assert.equal(run('currentSnap'),'Midpoint','face midpoint at y='+y);}
for(const y of faceYs){const r=JSON.parse(run(`JSON.stringify(advancedSnap({x:1234,y:${y+4}}))`));near(r.y,y);assert.equal(run('currentSnap'),'On line'.replace('line','face'),'snaps ON each face line');}
// 2. thirds and quarters along the centerline and faces
let r=JSON.parse(run('JSON.stringify(advancedSnap({x:2004,y:3}))'));near(r.x,2000);assert.equal(run('currentSnap'),'Third');
r=JSON.parse(run('JSON.stringify(advancedSnap({x:1503,y:2}))'));near(r.x,1500);assert.equal(run('currentSnap'),'Quarter');
// 3. door/window: centre, jambs on centerline and both faces
run('model.elements.push({id:"D-001",type:"door",host:"W-001",offset:2000,width:900,height:2100,story:"s0",layer:"Exterior Walls",material:"Timber"})');
const c=JSON.parse(run('JSON.stringify(openingPoint(model.elements[1]))'));
r=JSON.parse(run(`JSON.stringify(advancedSnap({x:${c.x+450+3},y:${c.y+3}}))`));near(r.x,c.x+450);assert.equal(run('currentSnap'),'Jamb');
for(const y of faceYs){r=JSON.parse(run(`JSON.stringify(advancedSnap({x:${c.x-450-3},y:${y+3}}))`));near(r.x,c.x-450);near(r.y,y);assert.equal(run('currentSnap'),'Jamb','jamb on face y='+y);}
// 4. circle centre + quadrants, shape centre
run('model.elements=[{id:"C-1",type:"circle",a:{x:10000,y:10000},radius:1000,story:"s0",layer:"Annotations"},{id:"S-1",type:"slab",points:[{x:0,y:0},{x:4000,y:0},{x:4000,y:2000},{x:0,y:2000}],story:"s0",layer:"Structure",thickness:200}]');
r=JSON.parse(run('JSON.stringify(advancedSnap({x:10003,y:10002}))'));near(r.x,10000);assert.equal(run('currentSnap'),'Center');
r=JSON.parse(run('JSON.stringify(advancedSnap({x:11003,y:10002}))'));near(r.x,11000);near(r.y,10000);assert.equal(run('currentSnap'),'Quadrant');
r=JSON.parse(run('JSON.stringify(advancedSnap({x:2003,y:1002}))'));near(r.x,2000);near(r.y,1000);assert.equal(run('currentSnap'),'Shape centre');
r=JSON.parse(run('JSON.stringify(advancedSnap({x:10000+Math.cos(.5)*1000+4,y:10000+Math.sin(.5)*1000+3}))'));assert.equal(run('currentSnap'),'On curve');
// 5. face corners of two joined walls + an intersection of face lines
run('model.elements=[wall("W-1",[0,0],[6000,0]),wall("W-2",[6000,0],[6000,5000])]');
const polys=JSON.parse(run('JSON.stringify(model.elements.map(w=>wallPoly(w)))'));
const outer=polys[0].reduce((b,q)=>q.x+q.y*0>b.x?q:b,polys[0][0]);
const corner=polys[0].concat(polys[1]).sort((a,b)=>(b.x-a.x)||(a.y-b.y))[0];
r=JSON.parse(run(`JSON.stringify(advancedSnap({x:${corner.x+3},y:${corner.y-3}}))`));near(r.x,corner.x);near(r.y,corner.y);
// 6. snapping stays fast on a large model (cached geometry)
run('model.elements=[];for(let i=0;i<200;i++)model.elements.push(wall("W-"+i,[(i%20)*3000,Math.floor(i/20)*3000],[(i%20)*3000+2800,Math.floor(i/20)*3000]))');
const t0=Date.now();for(let k=0;k<400;k++)run(`advancedSnap({x:${(k*37)%60000},y:${(k*53)%30000}})`);
assert(Date.now()-t0<4000,'400 snaps on 200 walls took '+(Date.now()-t0)+' ms');
// 7. snap off returns the raw point
run('snap=false');r=JSON.parse(run('JSON.stringify(advancedSnap({x:123,y:456}))'));near(r.x,123);near(r.y,456);run('snap=true');
console.log('PASS: wall face corners/midpoints/face lines on both sides, thirds and quarters, door/window jambs, circle centre/quadrants/curve, shape centre, intersections of face lines, cached and fast on 200 walls');
