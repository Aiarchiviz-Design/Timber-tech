const fs=require('fs'),vm=require('vm'),assert=require('assert');
const nodes=new Map(),ctx=new Proxy({},{get:()=>()=>{}});
function node(s){if(!nodes.has(s))nodes.set(s,{style:{},dataset:{},value:'0',classList:{add(){},remove(){},toggle(){},contains(){return false}},querySelectorAll:()=>[],querySelector:()=>null,insertAdjacentHTML(){},addEventListener(){},getContext:()=>ctx,getBoundingClientRect:()=>({width:0,height:0}),children:[],close(){},showModal(){},click(){}});return nodes.get(s)}
const box={document:{body:node('body'),querySelector:node,querySelectorAll:()=>[],addEventListener(){},createElement:node},ResizeObserver:class{observe(){}},devicePixelRatio:1,console,setTimeout,clearTimeout,URL,Blob};
vm.createContext(box);for(const f of ['joins.js','framing.js','camera.js','advanced.js','trim.js','editing.js','roof-footprint.js','roof.js','truss-joints.js','hip-trusses.js','roof-framing.js','app.js'])vm.runInContext(fs.readFileSync('dist/'+f,'utf8'),box);
const run=s=>vm.runInContext(s,box);
run('render=()=>{};properties=()=>{};navigator=()=>{};toast=()=>{};model=clone(model);model.elements=[{id:"R-HIP-3D",type:"roof",story:"s0",layer:"Structure",points:[{x:0,y:0},{x:13000,y:0},{x:13000,y:9000},{x:0,y:9000}],pitch:25,height:3000,overhang:609.6,thickness:200,roofType:"hip",roofFraming:{system:"trusses",spacing:600,hipSetback:1828.8}}];var layout=generateRoofFraming(model.elements[0]);');
const all=run('layout.members');
const sideAssemblies=[...new Set(all.filter(m=>m.type==='Side jack top chord').map(m=>m.assembly))];
const carrierAssemblies=[...new Set(all.filter(m=>m.type==='Hip carrier top chord').map(m=>m.assembly))];
assert(sideAssemblies.length>0,'side jack top chords were generated');assert(carrierAssemblies.length>0,'hip carrier top chords were generated');
const dist3=(p,a,b)=>{const dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z,l=dx*dx+dy*dy+dz*dz,t=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy+(p.z-a.z)*dz)/(l||1)));return Math.hypot(p.x-a.x-dx*t,p.y-a.y-dy*t,p.z-a.z-dz*t)};
const carriers=all.filter(m=>m.type==='Hip carrier top chord');
const results=[];
for(const id of sideAssemblies){const tops=all.filter(m=>m.assembly===id&&m.type==='Side jack top chord');assert.equal(tops.length,1,`${id} should have a single continuous top chord`);let best=Infinity;for(const top of tops)for(const p of [top.a,top.b])for(const carrier of carriers)best=Math.min(best,dist3(p,carrier.a,carrier.b));results.push({id,best});}
const disconnected=results.filter(x=>x.best>1);
if(disconnected.length)console.error('Disconnected side-jack receiver endpoints:',disconnected);
assert.equal(disconnected.length,0,'every purple side-jack top chord must end on the pink hip-carrier centerline in 3D, not only in plan');
console.log(`PASS: ${sideAssemblies.length} side-jack top chords each have one continuous member and a 3D endpoint on the hip-carrier centerline (<= 1 mm).`);
