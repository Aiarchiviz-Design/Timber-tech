const fs=require('fs'),vm=require('vm'),assert=require('assert');
const bootstrap=fs.readFileSync('tests/verify-walls.cjs','utf8').split('function fixture')[0];
eval(bootstrap.replace("const fs=require('fs'),vm=require('vm'),assert=require('assert');",'').replace('const run=','var run='));
// A simple sloped rafter is intentionally not part of a truss assembly. Its free
// eave end previously kept a square cut, unlike the plumb-cut reference detail.
run(`var freeRafter={id:'RF-PLUMB',roofId:'R',type:'Rafter',a:{x:0,y:0,z:0},b:{x:1200,y:0,z:300},width:45,depth:190,length:Math.hypot(1200,300),section:'45 × 190'};var freeMembers=finishRoofConnections([freeRafter]);`);
assert(run(`freeRafter.endCuts&&freeRafter.endCuts.length===2&&freeRafter.endCuts.every(c=>c.kind==='plumb-cut'&&c.plane==='vertical')`),'free rafter ends are annotated as plumb cuts');
function capAtEnd(end){
  return run(`(()=>{const m=freeRafter,p=m.${end},dx=m.b.x-m.a.x,dy=m.b.y-m.a.y,h=Math.hypot(dx,dy),s=${end==='a'?1:-1},n={x:dx/h*s,y:dy/h*s};return m.cutFaces.some(f=>f.length>=4&&f.every(q=>Math.abs((q.x-p.x)*n.x+(q.y-p.y)*n.y)<0.05));})()`);
}
assert(capAtEnd('a'),'eave/start cap is a true vertical plumb plane');
assert(capAtEnd('b'),'upper/end cap is a true vertical plumb plane');
// A top chord already assigned a receiver must retain that compound receiving cut
// instead of being flattened to a generic plumb cut at the same end.
run(`var receiverChord={id:'RF-RECEIVER',roofId:'R',type:'Side jack top chord',assembly:'SJ1',receiverAssembly:'HC1',a:{x:0,y:0,z:0},b:{x:1000,y:0,z:250},width:45,depth:190,length:Math.hypot(1000,250),endCuts:[{end:'a',kind:'plumb-cut',plane:'vertical'},{end:'b',kind:'plumb-receiving-face',receiverAssembly:'HC1'}],cutFaces:roofMemberFaces({a:{x:0,y:0,z:0},b:{x:1000,y:0,z:250},width:45,depth:190}),section:'45 × 190'};finishRoofConnections([receiverChord]);`);
assert(run(`receiverChord.endCuts.some(c=>c.end==='b'&&c.kind==='plumb-receiving-face')`),'receiver-end metadata is preserved');
// Exercise actual roof-generated rafters at the reference's shallow 14-degree pitch.
run(`model.elements=[{id:'R-RAFTER-PLUMB',type:'roof',story:'s0',layer:'Structure',points:[{x:0,y:0},{x:8000,y:0},{x:8000,y:5000},{x:0,y:5000}],height:3000,thickness:200,pitch:14,overhang:600,roofType:'gable',roofFraming:{system:'rafters',spacing:600}}];var generatedRafters=generateRoofFraming(model.elements[0]);`);
assert(run(`generatedRafters.members.filter(m=>m.type==='Rafter').length>0`),'test roof generated rafters');
assert(run(`generatedRafters.members.filter(m=>m.type==='Rafter').every(m=>m.endCuts&&m.endCuts.length===2&&m.endCuts.some(c=>c.kind==='plumb-cut')&&m.endCuts.some(c=>c.kind==='plumb-receiving-face'))`),'generated rafters have a plumb eave end and a receiving cut at the ridge');
assert(run(`generatedRafters.members.filter(m=>m.type==='Rafter').every(m=>m.endCuts.filter(c=>c.kind==='plumb-cut').every(c=>{const p=m[c.end],dx=m.b.x-m.a.x,dy=m.b.y-m.a.y,h=Math.hypot(dx,dy),n={x:dx/h,y:dy/h};return m.cutFaces.some(f=>f.length>=4&&f.every(q=>Math.abs((q.x-p.x)*n.x+(q.y-p.y)*n.y)<.05));}))`),'all generated rafter plumb end faces are truly vertical');
console.log('PASS: free and generated rafter ends have real world-space vertical plumb-cut faces; receiving ends preserve their compound cut.');
