const fs=require('fs'),vm=require('vm'),assert=require('assert');
const nodes=new Map(),ctx=new Proxy({},{get:()=>()=>{}});
function node(s){if(!nodes.has(s))nodes.set(s,{style:{},dataset:{},value:'0',classList:{add(){},remove(){},toggle(){},contains(){return false}},querySelectorAll:()=>[],querySelector:()=>null,insertAdjacentHTML(){},addEventListener(){},getContext:()=>ctx,getBoundingClientRect:()=>({width:0,height:0}),children:[],close(){},showModal(){},click(){}});return nodes.get(s)}
const box={document:{body:node('body'),querySelector:node,querySelectorAll:()=>[],addEventListener(){},createElement:node},ResizeObserver:class{observe(){}},devicePixelRatio:1,console,setTimeout,clearTimeout,URL,Blob};
vm.createContext(box);for(const f of ['joins.js','framing.js','camera.js','advanced.js','trim.js','editing.js','roof-footprint.js','roof.js','truss-joints.js','hip-trusses.js','roof-framing.js','app.js'])vm.runInContext(fs.readFileSync('dist/'+f,'utf8'),box);
const run=s=>vm.runInContext(s,box);
run('render=()=>{};properties=()=>{};navigator=()=>{};toast=()=>{};model=clone(model);model.elements=[{id:"R-SJ-STOP",type:"roof",story:"s0",layer:"Structure",points:[{x:0,y:0},{x:10000,y:0},{x:10000,y:4000},{x:16000,y:4000},{x:16000,y:12000},{x:10000,y:12000},{x:10000,y:17000},{x:6000,y:17000},{x:6000,y:10000},{x:0,y:10000}],pitch:25,height:3000,overhang:609.6,thickness:200,roofType:"hip",roofFraming:{system:"trusses",spacing:600,hipSetback:1828.8}}];var layout=generateRoofFraming(model.elements[0]);');
const all=run('layout.members');
const sideIds=[...new Set(all.filter(m=>m.type==='Side jack top chord').map(m=>m.assembly))];
assert(sideIds.length>0,'side jacks generated');
const dist3=(p,a,b)=>{const d={x:b.x-a.x,y:b.y-a.y,z:b.z-a.z},l=d.x*d.x+d.y*d.y+d.z*d.z,t=Math.max(0,Math.min(1,((p.x-a.x)*d.x+(p.y-a.y)*d.y+(p.z-a.z)*d.z)/(l||1)));return Math.hypot(p.x-a.x-d.x*t,p.y-a.y-d.y*t,p.z-a.z-d.z*t)};
const lineSigned=(p,a,b,n)=> (p.x-a.x)*n.x+(p.y-a.y)*n.y;
let checked=0;
for(const id of sideIds){
 const members=all.filter(m=>m.assembly===id);
 const top=members.find(m=>m.type==='Side jack top chord'),bottom=members.find(m=>m.type==='Side jack bottom chord');
 assert(top&&bottom,`${id} needs top and bottom chords`);
 assert(top.receiverAssembly&&top.receiverAssembly===bottom.receiverAssembly,`${id} top and bottom chords must name the same receiving hip carrier`);
 const receiver=top.receiverAssembly;
 const carrierTop=all.find(m=>m.assembly===receiver&&m.type==='Hip carrier top chord');
 const carrierBottom=all.find(m=>m.assembly===receiver&&m.type==='Hip carrier bottom chord');
 assert(carrierTop&&carrierBottom,`${id} assigned hip carrier ${receiver} must exist with both chords`);
 // Each chord has one end at its receiving carrier; check against that exact assembly, not any nearby carrier.
 assert(Math.min(dist3(top.a,carrierTop.a,carrierTop.b),dist3(top.b,carrierTop.a,carrierTop.b))<1,`${id} top chord endpoint must meet its assigned hip-carrier top chord`);
 assert(Math.min(dist3(bottom.a,carrierBottom.a,carrierBottom.b),dist3(bottom.b,carrierBottom.a,carrierBottom.b))<1,`${id} bottom chord endpoint must meet its assigned hip-carrier bottom chord`);
 // The rendered solids must stop at the near face of the assigned carrier, without crossing its center plane.
 for(const [m,c] of [[top,carrierTop],[bottom,carrierBottom]]){
   assert(m.cutFaces?.length,`${m.type} should have trimmed 3D faces`);
   const dx=c.b.x-c.a.x,dy=c.b.y-c.a.y,h=Math.hypot(dx,dy);assert(h>1,'carrier plan length');
   const n0={x:-dy/h,y:dx/h};const mid={x:(m.a.x+m.b.x)/2,y:(m.a.y+m.b.y)/2};
   const center={x:c.a.x+dx*.5,y:c.a.y+dy*.5};const sign=((mid.x-center.x)*n0.x+(mid.y-center.y)*n0.y)>=0?1:-1;const n={x:n0.x*sign,y:n0.y*sign};
   const vals=m.cutFaces.flat().map(p=>lineSigned(p,c.a,c.b,n));
   const min=Math.min(...vals);
   assert(min>=c.width/2-1.5,`${id} ${m.type} solid crosses past the receiving carrier face; signed clearance ${min.toFixed(2)} mm`);
 }
 checked++;
}
console.log(`PASS: ${checked} multi-wing purple side-jack assemblies stop both top and bottom chord solids at their assigned pink hip-carrier faces.`);
