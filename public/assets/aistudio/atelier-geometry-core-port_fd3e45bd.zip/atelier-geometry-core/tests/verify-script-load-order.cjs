const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
// "addAdvancedTrussWebPattern is not defined" happened in the browser when hip-trusses.js ran against a
// stale/mismatched roof-framing.js. The function now lives in hip-trusses.js (its only caller) and every
// script carries one shared cache-busting version so a browser cannot mix old and new files.
const html=fs.readFileSync('dist/index.html','utf8');
const scripts=[...html.matchAll(/<script(?: type="module")? src="([^"?]+)\?v=([^"]*)"/g)].map(m=>({file:m[1],v:m[2]}));
assert(scripts.length>=15,'scripts found in index.html');
assert.equal(new Set(scripts.map(s=>s.v)).size,1,'all scripts share one cache version: '+[...new Set(scripts.map(s=>s.v))].join(', '));
for(const s of scripts)assert(fs.existsSync(path.join('dist',s.file)),'missing script '+s.file);
const ctx=vm.createContext({console});
vm.runInContext(fs.readFileSync('dist/hip-trusses.js','utf8'),ctx);
assert.equal(vm.runInContext('typeof addAdvancedTrussWebPattern',ctx),'function','hip-trusses.js defines addAdvancedTrussWebPattern on its own');
assert(!/function addAdvancedTrussWebPattern/.test(fs.readFileSync('dist/roof-framing.js','utf8')),'single definition (not duplicated in roof-framing.js)');
// every function hip-trusses.js calls must be defined in a script that loads before or alongside it
const calls=new Set([...fs.readFileSync('dist/hip-trusses.js','utf8').matchAll(/\b(addAdvancedTrussWebPattern|roofBoundary|roofPlanEdges|roofSettings|segmentDistance)\(/g)].map(m=>m[1]));
const all=scripts.map(s=>fs.readFileSync(path.join('dist',s.file),'utf8')).join('\n');
for(const f of calls)assert(new RegExp('function '+f+'\\(').test(all),f+' is defined in a loaded script');
console.log('PASS: script load order is self-consistent; addAdvancedTrussWebPattern is defined next to its caller.');
