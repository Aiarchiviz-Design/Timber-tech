const fs=require('fs'),vm=require('vm'),assert=require('assert');
const bootstrap=fs.readFileSync('tests/verify-walls.cjs','utf8').split('function fixture')[0];
eval(bootstrap.replace("const fs=require('fs'),vm=require('vm'),assert=require('assert');",'').replace('const run=','var run='));
run(`var members=[
 {id:'T',type:'Common truss top chord',assembly:'A',a:{x:0,y:0,z:1000},b:{x:1000,y:0,z:1500}},
 {id:'B',type:'Common truss bottom chord',assembly:'A',a:{x:0,y:0,z:0},b:{x:1000,y:0,z:0}},
 {id:'W',type:'Common truss web',assembly:'A',a:{x:500,y:0.2,z:1249.9},b:{x:500,y:0,z:0}}
]; var beforeAngle=Math.atan2(members[0].b.z-members[0].a.z,members[0].b.x-members[0].a.x); snapWebEndpointsToOwnChords(members);`);
assert(run(`Math.abs(members[2].a.y)<0.01 && Math.abs(members[2].a.z-(1000+0.5*members[2].a.x))<0.01`),'web top endpoint should snap to top chord');
assert(run(`Math.hypot(members[2].b.x-500,members[2].b.y,members[2].b.z)<0.01`),'web bottom endpoint should snap to bottom chord');
assert(run(`Math.abs(Math.atan2(members[0].b.z-members[0].a.z,members[0].b.x-members[0].a.x)-beforeAngle)<1e-12`),'top chord pitch must remain unchanged');
run(`members=[{id:'T1',type:'Common truss top chord',assembly:'A',a:{x:0,y:0,z:0},b:{x:1000,y:0,z:1000}},{id:'W1',type:'Common truss web',assembly:'A',a:{x:500,y:20,z:500},b:{x:500,y:20,z:0}}]; snapWebEndpointsToOwnChords(members);`);
assert(run(`Math.abs(members[1].a.y-20)<1e-9`),'webs farther than tolerance must not snap');
console.log('PASS: near web endpoints snap to own chords; top-chord angle and unrelated geometry stay unchanged');
