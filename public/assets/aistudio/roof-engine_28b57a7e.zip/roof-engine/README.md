# Roof Engine — roof modelling + rafter / truss generation (extracted from Atelier BIM Studio V3.94b)

Plain JavaScript (no build step, no framework). Units: **millimetres**. Plan = x/y, elevation = z (up).
The engine is a set of classic scripts that share globals. `core/` runs with **no DOM and no app.js**.

## Folders
| Path | What it is |
|---|---|
| `core/00-helpers.js` | Tiny geometry helpers extracted verbatim from the app (point-in-polygon, segment distance, polygon clean/area, surface normal, `storyOf`, `heightOf`, `wallBase`). Defines the host contract (see below). |
| `core/roof-footprint.js` | Footprint analysis: simple/convex/orthogonal checks, triangulation, plan edges (ridge/hip/valley/eave), rectangle decomposition into wings, stepped roofs. |
| `core/roof.js` | **Roof model**: `roofSettings`, `roofBoundary`, `roofGeometry(e)` → 3D facets (hip / multi-gable / shed / flat etc., pitch, overhang, thickness), 2D plan/section drawing + Properties panel (UI parts need your canvas helpers). |
| `core/roof-framing.js` | **Rafters + trusses**: `generateRoofFraming(e)` → members; `roofFramingSettings`, `roofSection`, `roofMemberFaces` (timber solids with cuts), cut list rows, duplicate chord cleanup, `projectRoofFraming` for many roofs. |
| `core/hip-trusses.js` | **Truss layout logic**: hip-end sets (girders, hip carriers, front jacks, side jacks, hip/common trusses), multi-wing (L/T/U) with junction girders, web patterns (Fink, Howe, Pratt, Warren, Queen/King post). V3.94 rules: no truss within one spacing of a girder, girder moves onto the too-close truss, jacks start 2 ft from the orange truss, 12 in minimum spacing. |
| `core/truss-joints.js` | Joint solver: heel/apex/web connections, miter + plumb cuts, receiving-face trims (`joinTrussMembers`, `finishRoofConnections`). |
| `core/truss-optimizer.js` | Design-assist review / optimizer panel and design-basis inputs (UI-bound; optional). |
| `ui/viewport3d.js`, `camera.js`, `renderer.js`, `framing-plan.js`, `ui/vendor/` | The app's 3D viewport (three.js module + software renderer), camera, 2D renderer and wall framing plan. They depend on the app shell (`app.js`) — use them as reference; `demo/viewer.html` is the minimal standalone 3D view. |
| `demo/generate.cjs` | Node example: build a model, run the engine, print member counts. `node demo/generate.cjs` |
| `demo/viewer.html` | Standalone three.js viewer (serve the folder with any static server, e.g. `npx serve .`, open `/demo/viewer.html`). |
| `tests/` | Regression tests from the app (they bootstrap `app.js`; copy the `dist/` of the full app next to run them). |
| `notes/` | Design notes per version (what each rule does and why). |

## Script load order (browser)
```html
<script src="core/00-helpers.js"></script>
<script src="core/roof-footprint.js"></script>
<script src="core/roof.js"></script>
<script src="core/truss-joints.js"></script>
<script src="core/hip-trusses.js"></script>
<script src="core/roof-framing.js"></script>
```
In Node load the same files with `vm.runInContext` (see `demo/generate.cjs`) or append `module.exports` yourself.

## Host contract (what your app must provide)
```js
model = {
  stories:  [{ id:'s0', elevation:0, height:3000 }],          // storyOf(e) looks e.story up here
  elements: [{
    id:'R-001', type:'roof', story:'s0', layer:'Structure',
    points:[{x,y},...],            // roof footprint polygon (plan, mm)
    pitch:25, height:3000, overhang:609.6, thickness:200,
    roofType:'hip',                // 'hip' | 'multiGable' | ... (see roofProperties in roof.js)
    roofFraming:{ system:'trusses' /* or 'rafters' | 'off' */, spacing:600, width:45, depth:190, webDepth:90, heel:300,
                  girderPlies:2, hipSetback:1828.8, webPattern:'Fink', panelCount:0, wingDirection:'branch', angle:0 }
  }]
};
```
`wallBase`/`heightOf` read wall/story data only for the optional "align above wall plates" feature; for pure generation a roof element and a story are enough.

## API
```js
const geo = roofGeometry(roof);              // { facets:[[{x,y,z}...]], boundary, base, drop, ... }  roof surface
const out = generateRoofFraming(roof);       // { members:[...], issues:[...] }
// member: { id, type, a:{x,y,z}, b:{x,y,z}, width, depth, length, section, assembly, receiverAssembly?, cutFaces?, endCuts? }
// types: 'Rafter', 'Common truss top chord|bottom chord|web', 'Hip truss …', 'Girder truss …', 'Junction girder …',
//        'Hip carrier …', 'Front jack …', 'Side jack …', 'Ridge member', 'Hip / valley member'
const solids = roofMemberFaces(member);      // polygon faces of the cut timber → feed any mesh renderer
const rows   = roofFramingRows();            // cut-list rows (needs the app's schedule(); see roof-framing.js)
```
Members belonging to one truss share `assembly`. Colour convention in the app: Common green, Hip truss teal, Girder/Junction orange,
Front jack blue, Side jack purple, Hip carrier pink.

## What to adapt when porting
1. **Coordinates**: engine is z-up in mm. three.js is y-up → rotate your group −90° about x (done in `demo/viewer.html`).
2. **UI functions** inside `roof.js`, `roof-framing.js`, `truss-optimizer.js` (`roofProperties`, `drawRoofPlan`, `roofFramingProperties`, dialogs) call app helpers (`field`, `choice`, `line`, `poly`, `openModal`, `toast`, `schedule`, `csv`…). They are only invoked from UI code — keep them if you want the same panels, otherwise delete them; the generators do not call them.
3. **Settings validation**: `validateRoofFraming` throws for out-of-range input (spacing 100–3000 mm, width 20–300, depth 40–1000, girder plies 1–4, hip setback 400–10000, panel count 0 or 4–24). Truss spacing is clamped to ≥ 304.8 mm (12 in).
4. **Performance**: `generateRoofFramingCached(e)` memoises on the roof JSON; call it while dragging/editing.
5. Scope: geometric design-assist (layout, members, cuts). Loads, capacities, bearings and connector design are **not** solved.

## Key layout rules (V3.94b, `core/hip-trusses.js`)
- Common/hip trusses: from the near girder at one spacing O.C.; if the last station would be closer than one spacing to the far girder, drop it and move that girder onto its station.
- Side jacks (purple): one spacing from the girder, stepping to the eave; wide eave gap split evenly.
- Front jacks (blue): first jack one spacing from the orange truss at any flush (carrier-less) end, else from the roof corner.
- 12 in hard minimum spacing for every truss role.
