// Unit test for Opening Header Corner Cripple Studs attached to King Stud
import fs from 'fs';

console.log('Testing Opening Header Corner Cripple Studs attached to King Studs...');

const framingCode = fs.readFileSync('./framing.js', 'utf8');

// Check that upper cripples use headerX0 and headerX1
if (!framingCode.includes('upperLeftX0 = headerX0') || !framingCode.includes('upperRightX1 = headerX1')) {
  console.error('FAILED: framing.js does not place upper cripples at headerX0 and headerX1');
  process.exit(1);
}

console.log('✓ framing.js places upper cripples at header corners attached directly to King Studs!');
