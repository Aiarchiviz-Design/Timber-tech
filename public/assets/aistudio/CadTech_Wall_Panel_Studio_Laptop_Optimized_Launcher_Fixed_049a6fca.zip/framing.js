/* Framing is regenerated from BIM walls and their hosted openings. These are
   construction layouts using specified member sizes, not load-sized designs. */
var WALL_COMPOSITES={timber140:{name:'Timber 140 · insulated',skins:[{name:'Gypsum',thickness:13},{name:'Structural timber',thickness:140,core:true},{name:'Sheathing',thickness:19},{name:'Air gap',thickness:25},{name:'Cladding',thickness:16}]},timber90:{name:'Timber 90 · internal',skins:[{name:'Gypsum',thickness:13},{name:'Structural timber',thickness:90,core:true},{name:'Gypsum',thickness:13}]}};
var FRAMING_DEFAULTS={enabled:true,studWidth:45,studDepth:140,spacing:406.4,plateThickness:45,topPlates:2,bottomPlates:1,headerDepth:190,headerPlies:2,autoHeaderDepth:true,cornerDetail:"threeStud",tDetail:"backingStud",blockingSpacing:1219.2};
function construction(w){
  const depth=w.structure==='composite'?(wallLayers(w).find(s=>s.core)?.thickness||140):Math.min(FRAMING_DEFAULTS.studDepth,w.thickness),
        saved=w.framing||{},
        c={...FRAMING_DEFAULTS,enabled:['Timber','Oak'].includes(w.material),studDepth:depth,headerPlies:Math.max(1,Math.min(2,Math.floor(depth/45))),...saved};
  // Preserve projects saved before the three inside-junction details existed.
  c.insideJunctionDetail=saved.insideJunctionDetail||(saved.tDetail==='blocking'?'insideBlocking':'insideStudFull');
  if(w.structure==='composite')c.studDepth=depth;
  return c;
}
function validateConstruction(w){if(w.structure&&!['basic','composite'].includes(w.structure))throw Error('Unsupported wall structure.');if(w.reference&&!['inside','center','outside','coreInside','coreCenter','coreOutside'].includes(w.reference))throw Error('Unsupported wall reference line.');if(w.structure==='composite'){const skins=wallLayers(w);if(!Array.isArray(skins)||!skins.length||skins.length>20||skins.filter(s=>s.core).length!==1||skins.some(s=>!Number.isFinite(s.thickness)||s.thickness<=0)||Math.abs(skins.reduce((a,s)=>a+s.thickness,0)-w.thickness)>JOIN_EPS)throw Error('Invalid composite layers.')}for(const k of ['baseOffset','topOffset'])if(w[k]!==undefined&&(!Number.isFinite(w[k])||Math.abs(w[k])>50000))throw Error('Invalid wall offset.');const c=construction(w);if(!["threeStud","twoStud","fourStud"].includes(c.cornerDetail)||!["backingStud","blocking"].includes(c.tDetail)||!["insideBlocking","insideStudFull","insideStudPartial"].includes(c.insideJunctionDetail)||!Number.isFinite(c.blockingSpacing)||c.blockingSpacing<100||c.blockingSpacing>10000)throw Error("Invalid junction detail.");if(typeof c.enabled!=='boolean'||!['studWidth','studDepth','spacing','plateThickness','headerDepth'].every(k=>Number.isFinite(c[k])&&c[k]>0&&c[k]<=10000)||c.spacing<Math.max(20,c.studWidth)||c.studDepth>w.thickness||!['topPlates','bottomPlates','headerPlies'].every(k=>Number.isInteger(c[k])&&c[k]>0&&c[k]<=6)||c.headerPlies*c.studWidth>c.studDepth)throw Error('Member sizes, spacing and header plies must fit the wall core.');}
function wallLayers(w){return w.structure==='composite'?(w.skins||WALL_COMPOSITES[w.composite||'timber140']?.skins||WALL_COMPOSITES.timber140.skins):[{name:w.material||'Timber',thickness:w.thickness,core:true}]}
function coreGeometry(w){const skins=wallLayers(w),coreIndex=skins.findIndex(s=>s.core),insideFinish=skins.slice(0,Math.max(0,coreIndex)).reduce((a,s)=>a+s.thickness,0),depth=skins[coreIndex]?.thickness||w.thickness;return {insideFinish,depth,center:w.structure==='composite'?w.thickness/2-insideFinish-depth/2:0}}
function referenceOffset(w){const c=coreGeometry(w),r=w.reference||'center',offset={center:0,inside:-w.thickness/2,outside:w.thickness/2,coreInside:-w.thickness/2+c.insideFinish,coreCenter:-w.thickness/2+c.insideFinish+c.depth/2,coreOutside:-w.thickness/2+c.insideFinish+c.depth}[r]||0;return offset*(w.flipped?-1:1)}
function wallCenterPoint(w,p){const u=sub2(w.b,w.a),len=Math.hypot(u.x,u.y)||1,r=referenceOffset(w);return {x:p.x-u.y/len*r,y:p.y+u.x/len*r}}
function wallBase(w){return storyOf(w).elevation+(w.baseOffset||0)}
function openingSolidPolygon(w,o){const len=distance(w.a,w.b),ps=rawWallPoly(w,lerp(w.a,w.b,(o.offset-o.width/2)/len),lerp(w.a,w.b,(o.offset+o.width/2)/len),40),shift=((w.thickness-40)/2-(o.reveal??(w.thickness-40)/2))*(w.flipped?-1:1),u=sub2(w.b,w.a);return ps.map(p=>({x:p.x-u.y/len*shift,y:p.y+u.x/len*shift}))}
function wallFramingJunctions(w, customModel){
  const mModel=customModel||(typeof model!=='undefined'?model:(typeof window!=='undefined'?window.model:null)),
        elems=(mModel?.elements||[]).filter(e=>e.type==='wall'&&e.id!==w.id&&e.story===w.story),
        len=distance(w.a,w.b),u=sub2(w.b,w.a),found=[];
  if(len<1)return found;
  for(const other of elems){
    const otherLen=distance(other.a,other.b),v=sub2(other.b,other.a);
    if(otherLen<1)continue;
    const nonParallel=Math.abs(cross2(u,v))/(len*otherLen)>.05;
    // A branch wall may terminate on the face of a through-wall, not its centreline.
    // Account for both wall half-thicknesses to avoid missing those real T-junctions.
    if(nonParallel)for(const [branchEnd,p] of [['a',other.a],['b',other.b]]){
      const d=segmentDistance(p,w.a,w.b),tol=(Math.max(0,w.thickness||0)+Math.max(0,other.thickness||0))/2+1;
      if(d.distance<=tol&&d.t>.001&&d.t<.999){
        found.push({x:d.t*len,type:'T-junction studs',otherId:other.id,branchEnd,point:{x:d.point.x,y:d.point.y}});
      }
    }
    const h=axisIntersection(w.a,w.b,other.a,other.b);
    if(h&&h.t>.001&&h.t<.999&&h.s>.001&&h.s<.999)found.push({x:h.t*len,type:'Cross-junction studs',otherId:other.id,point:h.point});
  }
  for(const other of elems){
    const otherLen=distance(other.a,other.b),v=sub2(other.b,other.a);
    if(len*otherLen<1||Math.abs(cross2(u,v))/(len*otherLen)<.05)continue;
    for(const k of ['a','b'])if([other.a,other.b].some(p=>distance(p,w[k])<=(w.thickness+other.thickness)/2+1))found.push({x:k==='a'?0:len,type:'Corner pack',otherId:other.id});
  }
  // Only collapse repeated detections of the same pair and location; distinct branches remain visible.
  return found.filter((j,i)=>!found.slice(0,i).some(o=>o.otherId===j.otherId&&o.type===j.type&&Math.abs(o.x-j.x)<1));
}
function insideJunctionCenter(w,other,branchEnd){
  const len=distance(w.a,w.b)||1,otherLen=distance(other.a,other.b),
        foot=framingMemberWorld(other,{x0:branchEnd==='a'?0:otherLen,x1:branchEnd==='a'?0:otherLen,depth:construction(other).studDepth}),
        p=lerp(foot[0],foot[2],.5),u=sub2(w.b,w.a);
  return ((p.x-w.a.x)*u.x+(p.y-w.a.y)*u.y)/len;
}
function insideJunctionKey(w,otherId,x){return `T:${[String(w.id),String(otherId)].sort().join('|')}:${Math.round(x)}`;}
function insideJunctionLabel(mode){return ({insideBlocking:'Wood Walls - Corner, Inside, Blocking',insideStudFull:'Wood Walls - Corner, Inside, Stud, Full',insideStudPartial:'Wood Walls - Corner, Inside, Stud, Partial'})[mode]||String(mode||'Unspecified');}
function insideJunctionDiagram(mode){
  const base='<rect x="7" y="10" width="106" height="11" rx=".5" fill="#fff" stroke="#7c3aed" stroke-width="1.2"/><rect x="53" y="19" width="14" height="26" fill="#fff" stroke="#7c3aed" stroke-width="1.2"/><line x1="10" y1="15.5" x2="110" y2="15.5" stroke="#7c3aed" stroke-width=".7"/>';
  const detail=mode==='insideBlocking'
    ?'<rect x="47" y="18" width="26" height="5" fill="#ede9fe" stroke="#7c3aed" stroke-width="1"/><line x1="47" y1="20.5" x2="73" y2="20.5" stroke="#7c3aed" stroke-width=".7"/>'
    :mode==='insideStudFull'
      ?'<rect x="47" y="8" width="26" height="15" fill="#ede9fe" stroke="#7c3aed" stroke-width="1"/><line x1="60" y1="8" x2="60" y2="23" stroke="#7c3aed" stroke-width=".7"/>'
      :'<rect x="53" y="7" width="26" height="16" fill="#ede9fe" stroke="#7c3aed" stroke-width="1"/><line x1="66" y1="7" x2="66" y2="23" stroke="#7c3aed" stroke-width=".7"/>';
  return `<svg class="junction-detail-diagram" viewBox="0 0 120 50" role="img" aria-label="${insideJunctionLabel(mode)} plan detail">${base}${detail}</svg>`;
}
function insideJunctionOptionsHtml(selectedMode){
  return `<div class="junction-detail-options" role="group" aria-label="Internal wall junction detail">${[['insideBlocking','Blocking','Horizontal blocking between return studs'],['insideStudFull','Stud, Full','Full-height backing stud'],['insideStudPartial','Stud, Partial','Full-height backing stud with offset']].map(([mode,title,desc])=>`<button type="button" class="junction-detail-option${selectedMode===mode?' is-selected':''}" data-junction-detail="${mode}" aria-pressed="${selectedMode===mode?'true':'false'}">${insideJunctionDiagram(mode)}<span class="junction-detail-option-copy"><b>${title}</b><small>${desc}</small></span><span class="junction-detail-check" aria-hidden="true">${selectedMode===mode?'✓':''}</span></button>`).join('')}</div>`;
}
/* Horizontal blocking between studs and cripples at construction().blockingSpacing (from the bottom plate up).
   A block is a 2x-depth piece laid flat on the wall: length along the wall, height = lumber depth, thickness = stud width.
   Blocks are skipped across openings, headers, sills and plates. */
function addHorizontalBlocking(w,c,members,add,usableOpenings,bottom,top){
  /* Flat horizontal blocking, same orientation as the top and bottom plates: a piece of stud-width height laid
     across the wall (thickness = stud depth) between studs and cripples. Rows sit at every blockingSpacing (4 ft)
     measured up from the wall base: 4 ft, 8 ft, 12 ft, 16 ft ... while below the top plate. Within a row, a bay is
     skipped only where an opening, header or sill sits over that same bay. Pieces under 300 mm clear are dropped. */
  const sw=c.studWidth,d=c.studDepth,step=c.blockingSpacing;
  if(!(step>0)||!(d>0))return;
  const verts=members.filter(m=>/stud|cripple|pack/i.test(m.type)&&m.z1-m.z0>1);
  for(let z=step;z<top-sw;z+=step){
    const zLo=z-sw/2,zHi=z+sw/2;
    if(zLo<bottom+sw||zHi>top-sw)continue;
    const xs=verts.filter(m=>m.z0<=zHi&&m.z1>=zLo).map(m=>(m.x0+m.x1)/2).sort((p,q)=>p-q);
    for(let i=0;i+1<xs.length;i++){
      const xa=xs[i],xb=xs[i+1];
      if(xb-xa-sw<300)continue;
      const mid=(xa+xb)/2;
      // only the bay under a header / sill / opening is skipped, not the whole row
      if(members.some(m=>/^(Header|Sill|Beam)$/i.test(m.type)&&m.z0<zHi+1&&m.z1>zLo-1&&m.x1>xa&&m.x0<xb))continue;
      if(usableOpenings.some(o=>o.sill<zHi+1&&o.head>zLo-1&&mid>o.left-sw&&mid<o.right+sw))continue;
      const mb=add('Block',xa+sw/2,xb-sw/2,zLo,zHi,d);
      if(mb)mb.section=`${sw} × ${d}`;
    }
  }
}

/* Beams on a wall whose top is level with the wall top (same storey) replace the top plate over their length.
   Inside the beam span: studs and cripples above the beam bottom are removed, studs that reach the beam are shortened
   to the beam bottom, blocks in the beam zone are removed, and the top plate is split around the beam. Jack studs are
   added under each beam end where no stud already carries it, and the beam itself is added as a member.
   A beam that runs into an opening is reported in issues and left out of the framing. */
function applyBeamAdjustments(w,c,h,members,add,mModel,usableOpenings,issues,len){
  const beams=(mModel&&mModel.elements||[]).filter(e=>e.type==='beam'&&e.story===w.story&&Number.isFinite(e.thickness)&&e.thickness>0);
  if(!beams.length||!(len>0))return;
  const sw=c.studWidth,ux=(w.b.x-w.a.x)/len,uy=(w.b.y-w.a.y)/len;
  const bottomZ=Math.max(0,...members.filter(m=>/^Bottom plate$/i.test(m.type)).map(m=>m.z1));
  const along=p=>(p.x-w.a.x)*ux+(p.y-w.a.y)*uy;
  const across=p=>Math.abs(-(p.x-w.a.x)*uy+(p.y-w.a.y)*ux);
  for(const b of beams){
    const hb=typeof heightOf==='function'?heightOf(b):b.height;
    if(!Number.isFinite(hb)||Math.abs(hb-h)>5)continue;                       // beam top must match wall top
    const reach=(w.thickness||200)/2+b.thickness/2+50;
    if(Math.max(across(b.a),across(b.b))>reach)continue;                    // beam must lie on this wall
    const xs=Math.max(0,Math.min(along(b.a),along(b.b))),xe=Math.min(len,Math.max(along(b.a),along(b.b)));
    if(xe-xs<100)continue;
    const zBot=h-b.thickness;
    if(zBot<=bottomZ+sw)continue;
    if(usableOpenings.some(o=>o.right>xs&&o.left<xe&&o.head>zBot)){issues.push(`${b.id}: beam runs into an opening on ${w.id}; beam framing not applied.`);continue;}
    // remove or shorten what the beam takes over
    const topRems=[];
    for(let i=members.length-1;i>=0;i--){
      const m=members[i];
      if(/^Beam$/i.test(m.type))continue;
      const overlapsX=m.x1>xs-1&&m.x0<xe+1;
      if(/^Top plate$/i.test(m.type)&&overlapsX&&m.z1>zBot){topRems.push({x0:m.x0,x1:m.x1,z0:m.z0,z1:m.z1,depth:m.depth});members.splice(i,1);continue;}
      if(/^Bottom plate$/i.test(m.type))continue;
      const cx=(m.x0+m.x1)/2;
      if(/stud|cripple|pack/i.test(m.type)&&m.z1-m.z0>1&&cx>xs-sw&&cx<xe+sw&&m.z1>zBot+1){
        if(m.z0>=zBot-1)members.splice(i,1);else m.z1=zBot;
        continue;
      }
      if(/^Block$/i.test(m.type)&&overlapsX&&m.z1>zBot&&m.z0<h){members.splice(i,1);continue;}
      if(overlapsX&&m.z0>=zBot-1&&m.z1>zBot)members.splice(i,1);
    }
    // top plate pieces left and right of the beam
    // each top plate layer keeps its own height outside the beam span
    for(const t of topRems)for(const [r0,r1] of [[t.x0,Math.min(t.x1,xs)],[Math.max(t.x0,xe),t.x1]]){
      if(r1-r0>20)add('Top plate',r0,r1,t.z0,t.z1,t.depth);
    }
    // the beam, and jack studs under each end
    const mb=add('Beam',xs,xe,zBot,h,b.thickness);
    if(mb)mb.section=`${b.thickness} × ${b.thickness}`;
    for(const xc of [xs+sw/2,xe-sw/2]){
      const carried=members.some(m=>/stud|cripple|pack/i.test(m.type)&&Math.abs((m.x0+m.x1)/2-xc)<30&&m.z0<=bottomZ+1&&m.z1>=zBot-1);
      if(!carried)add('Jack stud',xc-sw/2,xc+sw/2,bottomZ,zBot);
    }
  }
}

function generateWallFraming(w, customModel){
  if(!w||w.type!=='wall')return {wallId:w?.id,members:[],issues:[]};
  const mModel=customModel||(typeof model!=='undefined'?model:(typeof window!=='undefined'?window.model:null));
  const c=construction(w),len=(w.a&&w.b)?distance(w.a,w.b):NaN,
        fallbackHeight=typeof heightOf==='function'?heightOf(w):3048,
        h=Number.isFinite(w.height)&&w.height>0?w.height:fallbackHeight,
        members=[],issues=[];
  if(!c.enabled)return {wallId:w.id,members,issues};
  if(!Number.isFinite(len)||len<Math.max(1,2*c.studWidth)){
    issues.push(`${w.id}: wall axis is missing or too short for framing; no members generated.`);
    return {wallId:w.id,members,issues};
  }
  if(!Number.isFinite(h)||h<=0){
    issues.push(`${w.id}: wall height must be a positive millimetre value; no members generated.`);
    return {wallId:w.id,members,issues};
  }
  try{validateConstruction(w)}catch(err){
    issues.push(`${w.id}: invalid wall framing settings (${err?.message||'check member sizes and spacing'}); no members generated.`);
    return {wallId:w.id,members,issues};
  }
  const run=framingRun(w, mModel),sw=c.studWidth,bottom=c.bottomPlates*c.plateThickness,top=h-c.topPlates*c.plateThickness;
  if(!Number.isFinite(run.start)||!Number.isFinite(run.end)||run.end-run.start<2*sw){
    issues.push(`${w.id}: connected wall run is too short or invalid after junction offsets.`);
    return {wallId:w.id,members,issues};
  }
  if(top<=bottom){issues.push(`${w.id}: wall height does not leave clear space between the specified plate stacks.`);return {wallId:w.id,members,issues}}
  const rawHosted=(w.openings&&Array.isArray(w.openings)&&w.openings.length)?w.openings:(typeof hosted==='function'?hosted(w):(mModel?.elements||[]).filter(e=>e&&e.host===w.id));
  const allOpenings=rawHosted.map(o=>({...o,left:o.offset-o.width/2,right:o.offset+o.width/2,head:o.sill+o.height})),junctions=wallFramingJunctions(w, mModel);
  /* Reject invalid hosted openings before laying out members; do not create negative,
     out-of-wall or vertically impossible framing around malformed BIM openings. */
  const openings=[];for(const o of allOpenings){let problem='';if(!Number.isFinite(o.offset)||!Number.isFinite(o.width)||!Number.isFinite(o.height)||!Number.isFinite(o.sill)||o.width<=0||o.height<=0)problem='opening has invalid dimensions';else if(o.left<-.01||o.right>len+.01)problem='opening extends beyond its host wall';else if(o.sill<-.01||o.head>h+.01)problem='opening sill/head is outside the wall height';else if(o.type==='door'&&Math.abs(o.sill)>1)problem='door sill must start at floor level';if(problem){issues.push(`${o.id}: ${problem}; framing omitted for this opening.`);continue}openings.push(o)}
  /* Openings on one wall must not overlap: overlapping doors/windows make
     king/jack and header layouts ambiguous, so reject both affected openings. */
  const conflicted=new Set();
  for(let i=0;i<openings.length;i++)for(let j=i+1;j<openings.length;j++){
    const a=openings[i],b=openings[j];
    if(Math.min(a.right,b.right)-Math.max(a.left,b.left)>0.5){conflicted.add(a.id);conflicted.add(b.id);}
  }
  for(const id of conflicted)issues.push(`${id}: overlaps another opening on this wall; framing omitted for the conflicting openings.`);
  const usableOpenings=openings.filter(o=>!conflicted.has(o.id));
  const invalidRun=run.end-run.start<sw*2;if(invalidRun){issues.push('Connected wall run is too short for framing members.');return {wallId:w.id,members,issues}}
  function add(type,x0,x1,z0,z1,depth=c.studDepth){if(x1-x0<1||z1-z0<1)return;const member={id:`${w.id}:F-${String(members.length+1).padStart(4,'0')}`,wallId:w.id,type,x0,x1,z0,z1,depth,length:['Top plate','Bottom plate','Header','Sill','Block','Beam'].includes(type)?x1-x0:z1-z0,section:['Top plate','Bottom plate','Sill'].includes(type)?`${c.plateThickness} × ${c.studDepth}`:type==='Header'?`${depth} × ${c.headerDepth}`:`${sw} × ${depth}`};members.push(member);return member}
  if(top<=bottom){issues.push('Wall is too short for the specified plates.');return {wallId:w.id,members,issues}}
  for(let i=0;i<c.topPlates;i++)add('Top plate',run.start,run.end,h-(i+1)*c.plateThickness,h-i*c.plateThickness);
  let bottomRuns=[[run.start,run.end]];for(const o of openings.filter(o=>o.type==='door'||o.sill<1))bottomRuns=bottomRuns.flatMap(([a,b])=>o.right<=a||o.left>=b?[[a,b]]:[[a,Math.max(a,o.left)],[Math.min(b,o.right),b]].filter(([a,b])=>b-a>1));for(let i=0;i<c.bottomPlates;i++)for(const [a,b] of bottomRuns)add('Bottom plate',a,b,i*c.plateThickness,(i+1)*c.plateThickness);
  const reserved=[];for(const o of usableOpenings){
    const span=o.width;
    let numJacks=1;
    if(c.codeStandard==='AS_1684'||c.codeStandard==='EUROCODE_5'){
      numJacks=span>1500?2:1;
    }else{
      numJacks=span>1524?2:1;
    }
    const availLeft = Math.max(0, o.left);
    const availRight = Math.max(0, len - o.right);
    if (numJacks > 1 && (availLeft < (numJacks + 1) * sw || availRight < (numJacks + 1) * sw)) {
      numJacks = 1;
    }

    let hDepth=c.headerDepth||184;
    if(c.autoHeaderDepth!==false){
      if(c.codeStandard==='AS_1684'){
        if(span<=1200)hDepth=140;else if(span<=1800)hDepth=190;else if(span<=2400)hDepth=240;else hDepth=290;
      }else if(c.codeStandard==='EUROCODE_5'){
        if(span<=1200)hDepth=150;else if(span<=1800)hDepth=200;else if(span<=2400)hDepth=225;else hDepth=250;
      }else{
        if(span<=1219)hDepth=140;else if(span<=1829)hDepth=184;else if(span<=2438)hDepth=235;else hDepth=286;
      }
    }
    const availableHeaderDepth=top-o.head;
    if(availableHeaderDepth<89){
      issues.push(`${o.id}: opening head leaves only ${Math.round(availableHeaderDepth)} mm for a header; minimum geometry allowance is 89 mm. Header and associated opening framing omitted.`);
      continue;
    }
    if(hDepth>availableHeaderDepth+.01){
      if(c.autoHeaderDepth!==false){
        hDepth=availableHeaderDepth;
      }else{
        issues.push(`${o.id}: fixed header depth ${Math.round(hDepth)} mm does not fit the ${Math.round(availableHeaderDepth)} mm available above the opening; header and associated opening framing omitted.`);
        continue;
      }
    }

    const finalJw=numJacks*sw;
    const leftKingX1 = Math.max(0, o.left - finalJw);
    const leftKingX0 = Math.max(0, leftKingX1 - sw);
    const rightKingX0 = Math.min(len, o.right + finalJw);
    const rightKingX1 = Math.min(len, rightKingX0 + sw);

    reserved.push([Math.max(0, leftKingX0), Math.min(len, rightKingX1)]);

    // Always generate Left King Stud
    if (leftKingX1 - leftKingX0 > 0.5) {
      add('King stud', leftKingX0, leftKingX1, bottom, top);
    } else {
      add('King stud', 0, Math.min(sw, o.left), bottom, top);
    }

    // Always generate Right King Stud
    if (rightKingX1 - rightKingX0 > 0.5) {
      add('King stud', rightKingX0, rightKingX1, bottom, top);
    } else {
      add('King stud', Math.max(len - sw, o.right), len, bottom, top);
    }

    // Always generate Left Jack Stud(s)
    for(let k=0;k<numJacks;k++){
      const jx0 = Math.max(0, o.left - finalJw + k * sw);
      const jx1 = Math.max(0, o.left - finalJw + (k + 1) * sw);
      if (jx1 - jx0 > 0.5) {
        add('Jack stud', jx0, jx1, bottom, o.head);
      } else if (k === 0) {
        add('Jack stud', Math.max(0, o.left - sw), o.left, bottom, o.head);
      }
    }

    // Always generate Right Jack Stud(s)
    for(let k=0;k<numJacks;k++){
      const jx0 = Math.min(len, o.right + k * sw);
      const jx1 = Math.min(len, o.right + (k + 1) * sw);
      if (jx1 - jx0 > 0.5) {
        add('Jack stud', jx0, jx1, bottom, o.head);
      } else if (k === 0) {
        add('Jack stud', o.right, Math.min(len, o.right + sw), bottom, o.head);
      }
    }

    const headerX0 = Math.max(0, o.left - finalJw);
    const headerX1 = Math.min(len, o.right + finalJw);
    const hMem=add('Header',headerX0,headerX1,o.head,Math.min(top, o.head+hDepth),c.headerPlies*sw);
    if(hMem){hMem.section=`${c.headerPlies*sw} × ${Math.round(hDepth)}`;hMem.headerDepth=hDepth;hMem.headerPlies=c.headerPlies;hMem.clearSpan=span;}
    let totalSillThk=c.plateThickness;
    if(o.type==='window'&&o.sill>bottom+c.plateThickness){
      add('Sill',o.left,o.right,o.sill-c.plateThickness,o.sill);
      if(o.sill>bottom+2*c.plateThickness){
        add('Sill',o.left,o.right,o.sill-2*c.plateThickness,o.sill-c.plateThickness);
        totalSillThk=2*c.plateThickness;
      }
    }

    const crippleTop = Math.min(top, o.head + hDepth);
    const hasLower = o.type === 'window' && o.sill > bottom + totalSillThk;
    const lowerTop = o.sill - totalSillThk;

    // Corner cripples above header: move to corners, attached directly to King Studs
    const upperLeftX0 = headerX0;
    const upperLeftX1 = Math.min(headerX1, headerX0 + sw);
    if (upperLeftX1 - upperLeftX0 > 0.5) {
      add('Upper cripple', upperLeftX0, upperLeftX1, crippleTop, top);
    }

    const upperRightX0 = Math.max(upperLeftX1, headerX1 - sw);
    const upperRightX1 = headerX1;
    if (upperRightX1 - upperRightX0 > 0.5 && upperRightX0 >= upperLeftX1 - 0.01) {
      add('Upper cripple', upperRightX0, upperRightX1, crippleTop, top);
    }

    // Lower cripples under window sill
    if (hasLower) {
      add('Lower cripple', o.left, Math.min(o.right, o.left + sw), bottom, lowerTop);
      if (o.right - sw > o.left + sw - 0.1) {
        add('Lower cripple', Math.max(o.left, o.right - sw), o.right, bottom, lowerTop);
      }
    }

    // Generate interior on-center cripple studs
    for (let x = run.start + sw / 2; x <= run.end - sw / 2 + .01; x += c.spacing) {
      const cx0 = x - sw / 2, cx1 = x + sw / 2;
      if (cx0 >= upperLeftX1 - .01 && cx1 <= upperRightX0 + .01) {
        add('Upper cripple', cx0, cx1, crippleTop, top);
      }
      if (hasLower && cx0 >= o.left + sw - .01 && cx1 <= o.right - sw + .01) {
        add('Lower cripple', cx0, cx1, bottom, lowerTop);
      }
    }
  }
  for(const j of junctions){
    const other=(mModel?.elements||[]).find(e=>e.id===j.otherId),atStart=j.x<len/2;
    if(j.type==='T-junction studs'&&other){
      const oc=construction(other),
            center=insideJunctionCenter(w,other,j.branchEnd),
            half=oc.studDepth/2,left=center-half-sw,right=center+half+sw,
            jointKey=insideJunctionKey(w,other.id,center),mode=c.insideJunctionDetail;
      if(left<run.start||right>run.end||openings.some(o=>right>o.left-2*sw&&left<o.right+2*sw)){
        issues.push(`Internal wall junction ${w.id} → ${other.id} at ${Math.round(center)} mm: the selected connection zone conflicts with the wall run or a nearby opening; review the junction manually.`);
        continue;
      }
      reserved.push([left,right]);
      const leftReturn=add(j.type,left,left+sw,bottom,top),rightReturn=add(j.type,right-sw,right,bottom,top);
      for(const m of [leftReturn,rightReturn])if(m){m.role='T-junction return stud';m.junctionId=jointKey;m.connectionDetail=mode;}
      const dir=sub2(j.branchEnd==='a'?other.b:other.a,j.branchEnd==='a'?other.a:other.b),wallDirection=sub2(w.b,w.a),side=Math.sign((-wallDirection.y*dir.x+wallDirection.x*dir.y)/len)||1;
      if(mode==='insideStudFull'||mode==='insideStudPartial'){
        // Both stud variants are full-height, full-size turned studs. The partial variant
        // shifts the stud by half a stud width so part of its plan width projects past the
        // adjoining-wall edge, matching the supplied reference detail.
        const shift=mode==='insideStudPartial'?Math.min(sw/2,oc.studDepth/4):0,
              x0=center-half+shift,x1=center+half+shift,
              type=mode==='insideStudPartial'?'Inside junction backing stud (Partial)':'Inside junction backing stud (Full)',
              m=add(type,x0,x1,bottom,top,sw);
        if(m){m.lateralOffset=side*(c.studDepth-sw)/2;m.section=`${sw} × ${oc.studDepth}`;m.role=mode==='insideStudPartial'?'Partial inside backing stud':'Perpendicular backing stud';m.junctionId=jointKey;m.connectionDetail=mode;}
      }else if(mode==='insideBlocking'){
        // Short blocks laid flat between the return studs provide repeated fixing points
        // along the internal wall edge. This spacing is a detailing input, not a load design.
        let count=0;
        for(let z=bottom+c.blockingSpacing;z+sw<=top;z+=c.blockingSpacing){
          const m=add('T-junction blocking',center-half,center+half,z,z+sw,oc.studDepth);
          if(m){m.length=oc.studDepth;m.section=`${sw} × ${oc.studDepth}`;m.role='Horizontal backing';m.junctionId=jointKey;m.connectionDetail=mode;count++;}
        }
        if(count===0)issues.push(`Internal wall junction ${w.id} → ${other.id} at ${Math.round(center)} mm: no blocking pieces fit within the available wall height.`);
      }
    }else if(j.type==='Corner pack'){
      const through=other&&w.id.localeCompare(other.id)<0,
            edge=atStart?run.start:run.end,
            sign=atStart?1:-1;
      if(c.cornerDetail==='threeStud'){
        // "Wood Walls - Corner Outside, 3 Stud":
        // 1 through end stud + 1 interior drywall backing stud on through wall,
        // and 1 abutting end stud on abutting wall. (Total 3 studs at corner).
        const extent=through?sw+c.studDepth:sw,
              left=atStart?edge:edge-extent,
              right=atStart?edge+extent:edge;
        if(right-left>run.end-run.start||openings.some(o=>right>o.left-2*sw&&left<o.right+2*sw))continue;
        reserved.push([left,right]);
        const xEnd=atStart?edge:edge-sw;
        const mEnd=add(j.type,xEnd,xEnd+sw,bottom,top,c.studDepth);
        if(mEnd)mEnd.role=through?'Corner outside end stud':'Corner abutting end stud';
        if(through){
          const xBack0=atStart?edge+sw:edge-sw-c.studDepth,
                xBack1=atStart?edge+sw+c.studDepth:edge-sw,
                mBack=add('Corner backing stud',xBack0,xBack1,bottom,top,sw);
          if(mBack){
            const u=sub2(w.b,w.a),
                  cornerPt=w[atStart?'a':'b'],
                  q=other.a===undefined?other.b:distance(other.a,cornerPt)<distance(other.b,cornerPt)?other.b:other.a;
            const side=Math.sign(-u.y*(q.x-cornerPt.x)+u.x*(q.y-cornerPt.y))||sign;
            mBack.lateralOffset=side*(c.studDepth-sw)/2;
            mBack.section=`${sw} × ${c.studDepth}`;
            mBack.role='Corner drywall backing stud';
          }
        }
      }else if(c.cornerDetail==='fourStud'){
        // "Corner - Outside 4 Stud": 3 stacked end studs on through wall, 1 on abutting wall.
        const count=through?3:1,
              extent=count*sw,
              left=atStart?edge:edge-extent,
              right=atStart?edge+extent:edge;
        if(right-left>run.end-run.start||openings.some(o=>right>o.left-2*sw&&left<o.right+2*sw))continue;
        reserved.push([left,right]);
        for(let i=0;i<count;i++){
          const x=atStart?edge+i*sw:edge-(i+1)*sw;
          add(j.type,x,x+sw,bottom,top,c.studDepth);
        }
      }else{
        // "Corner - Outside 2 Stud": 1 end stud on through wall, 1 on abutting wall.
        const left=atStart?edge:edge-sw,
              right=atStart?edge+sw:edge;
        if(right-left>run.end-run.start||openings.some(o=>right>o.left-2*sw&&left<o.right+2*sw))continue;
        reserved.push([left,right]);
        add(j.type,left,right,bottom,top,c.studDepth);
      }
    }else{const center=Math.max(run.start+1.5*sw,Math.min(run.end-1.5*sw,j.x));if(openings.some(o=>center+1.5*sw>o.left-2*sw&&center-1.5*sw<o.right+2*sw))continue;reserved.push([center-1.5*sw,center+1.5*sw]);for(let i=-1;i<=1;i++)add(j.type,center+i*sw-sw/2,center+i*sw+sw/2,bottom,top)}
  }
  const xs=[run.start+sw/2,run.end-sw/2];for(let x=run.start+sw/2;x<=run.end-sw/2+.01;x+=c.spacing)xs.push(x);for(const x of xs.filter((x,i)=>!xs.slice(0,i).some(y=>Math.abs(x-y)<sw-.01))){if(x-sw/2<run.start-.01||x+sw/2>run.end+.01)continue;if(openings.some(o=>x+sw/2>o.left-2*sw&&x-sw/2<o.right+2*sw)||reserved.some(([a,b])=>x+sw/2>a+.01&&x-sw/2<b-.01))continue;add('Common stud',x-sw/2,x+sw/2,bottom,top)}
  applyBeamAdjustments(w,c,h,members,add,mModel,usableOpenings,issues,len);
  if(c.blockingSpacing>0&&w.blocking!==false)addHorizontalBlocking(w,c,members,add,usableOpenings,bottom,top);
  return {wallId:w.id,members,issues};
}
function auditWallJunctionConnections(w,layout,customModel){
  if(!w||w.type!=='wall')return [];
  const mModel=customModel||(typeof model!=='undefined'?model:(typeof window!=='undefined'?window.model:null)),members=layout?.members||[],issues=[],c=construction(w),mode=c.insideJunctionDetail;
  for(const j of wallFramingJunctions(w,mModel).filter(j=>j.type==='T-junction studs')){
    const other=(mModel?.elements||[]).find(e=>e.id===j.otherId),center=other?insideJunctionCenter(w,other,j.branchEnd):j.x,
          key=insideJunctionKey(w,j.otherId,center),parts=members.filter(m=>m.junctionId===key),
          returns=parts.filter(m=>m.role==='T-junction return stud'),
          backing=parts.filter(m=>['Horizontal backing','Perpendicular backing stud','Partial inside backing stud'].includes(m.role));
    const h=w.height||(typeof heightOf==='function'?heightOf(w):3048),bottom=c.bottomPlates*c.plateThickness,top=h-c.topPlates*c.plateThickness,
          expectedHalf=(other?construction(other).studDepth:0)/2+c.studWidth,
          intruding=members.filter(m=>m.type==='Common stud'&&m.x1>center-expectedHalf+1&&m.x0<center+expectedHalf-1);
    if(returns.length!==2)issues.push(`Internal wall junction ${w.id} → ${j.otherId} at ${Math.round(j.x)} mm: expected exactly two return studs, found ${returns.length}.`);
    else if(returns.some(m=>Math.abs(m.z0-bottom)>1||m.z1<top-1))issues.push(`Internal wall junction ${w.id} → ${j.otherId} at ${Math.round(j.x)} mm: return studs do not continue between the plate zones.`);
    if(intruding.length)issues.push(`Internal wall junction ${w.id} → ${j.otherId} at ${Math.round(j.x)} mm: ${intruding.length} ordinary stud(s) intrude into the reserved connection zone.`);
    if(mode==='insideBlocking'&&!backing.some(m=>m.role==='Horizontal backing'&&m.z1>bottom&&m.z0<top))issues.push(`Internal wall junction ${w.id} → ${j.otherId} at ${Math.round(j.x)} mm: blocking detail is missing.`);
    if(mode==='insideStudFull'&&!backing.some(m=>m.role==='Perpendicular backing stud'&&Math.abs(m.z0-bottom)<1&&m.z1>=top-1))issues.push(`Internal wall junction ${w.id} → ${j.otherId} at ${Math.round(j.x)} mm: full-height backing stud is missing or incomplete.`);
    if(mode==='insideStudPartial'){
      const partial=backing.find(m=>m.role==='Partial inside backing stud'&&Math.abs(m.z0-bottom)<1&&m.z1>=top-1);
      if(!partial)issues.push(`Internal wall junction ${w.id} → ${j.otherId} at ${Math.round(j.x)} mm: partial-detail backing stud is missing or incomplete.`);
      else if(Math.abs((partial.x0+partial.x1)/2-center)<1)issues.push(`Internal wall junction ${w.id} → ${j.otherId} at ${Math.round(j.x)} mm: partial backing stud is not offset from the full-detail position.`);
    }
  }
  return [...new Set(issues)];
}
function auditAllWallJunctions(customModel){
  const mModel=customModel||(typeof model!=='undefined'?model:(typeof window!=='undefined'?window.model:null)),walls=(mModel?.elements||[]).filter(e=>e.type==='wall'&&construction(e).enabled),connections=[],issues=[];
  for(const w of walls){
    const layout=generateWallFraming(w,mModel),junctions=wallFramingJunctions(w,mModel);
    const tChecks=auditWallJunctionConnections(w,layout,mModel);
    for(const j of junctions.filter(x=>x.type==='T-junction studs')){
      const jointIssues=tChecks.filter(msg=>msg.includes(`→ ${j.otherId} at ${Math.round(j.x)} mm`));
      connections.push({wallId:w.id,otherWallId:j.otherId,offsetMm:Math.round(j.x),detail:insideJunctionLabel(construction(w).insideJunctionDetail),status:jointIssues.length?'REVIEW':'OK',issues:jointIssues});
      issues.push(...jointIssues);
    }
    for(const j of junctions.filter(x=>x.type==='Cross-junction studs')){
      const msg=`Four-way wall crossing on ${w.id} with ${j.otherId} at ${Math.round(j.x)} mm: verify the cross-junction detail separately; the three inside-corner options are intended for T-junctions.`;
      connections.push({wallId:w.id,otherWallId:j.otherId,offsetMm:Math.round(j.x),detail:'Cross-junction (separate review)',status:'REVIEW',issues:[msg]});issues.push(msg);
    }
  }
  return {wallCount:walls.length,junctionCount:connections.length,okCount:connections.filter(c=>c.status==='OK').length,reviewCount:connections.filter(c=>c.status!=='OK').length,connections,issues:[...new Set(issues)]};
}

function auditWallFraming(w, customModel){
  const mModel=customModel||(typeof model!=='undefined'?model:(typeof window!=='undefined'?window.model:null)),layout=generateWallFraming(w,mModel),members=layout.members,issues=[...layout.issues],tol=1,c=construction(w),sw=construction(w).studWidth;
  const openings=hosted(w).filter(o=>o.host===w.id);
  for(const m of members){if(!Number.isFinite(m.x0)||!Number.isFinite(m.x1)||!Number.isFinite(m.z0)||!Number.isFinite(m.z1)||m.x1-m.x0<tol||m.z1-m.z0<tol)issues.push(`${m.id}: invalid member extents.`);if(m.x0 < -tol||m.x1>distance(w.a,w.b)+tol)issues.push(`${m.id}: member extends beyond the wall axis.`)}
  const byOpening=new Map();for(const o of openings)byOpening.set(o.id,members.filter(m=>['King stud','Jack stud','Header','Sill','Upper cripple','Lower cripple'].includes(m.type)&&Math.abs((m.x0+m.x1)/2-o.offset)<o.width/2+4*construction(w).studWidth));
  for(const o of openings){const ms=byOpening.get(o.id)||[];if(o.width>0&&o.height>0&&!ms.some(m=>m.type==='Header'))issues.push(`${o.id}: no valid header generated; check header clearance, overlap and opening location.`);if(o.width>0&&o.height>0&&(!ms.some(m=>m.type==='King stud')||!ms.some(m=>m.type==='Jack stud')))issues.push(`${o.id}: king/jack support studs are incomplete.`);const hs=ms.filter(m=>m.type==='Header');for(const h of hs){if(h.x0>o.left-sw+tol||h.x1<o.right+sw-tol)issues.push(`${o.id}: header does not extend at least one stud width beyond the opening on both ends.`)}}
  issues.push(...auditWallJunctionConnections(w,layout,mModel));
  const run=framingRun(w,mModel),len=distance(w.a,w.b);
  return {wallId:w.id,memberCount:members.length,issues:[...new Set(issues)],valid:issues.length===0};
}
function framingWall(){return model.elements.find(e=>e.id===selected[0]&&e.type==='wall')||hostOf(model.elements.find(e=>e.id===selected[0])||{})||model.elements.find(e=>e.type==='wall'&&e.story===activeStory)}
function framingMemberWorld(w,m){const u=sub2(w.b,w.a),len=distance(w.a,w.b)||1,n={x:-u.y/len,y:u.x/len},core=coreGeometry(w),offset=referenceOffset(w)+core.center*(w.flipped?-1:1)+(m.lateralOffset||0),center=x=>({x:w.a.x+u.x*x/len+n.x*offset,y:w.a.y+u.y*x/len+n.y*offset}),a=center(m.x0),b=center(m.x1),half=m.depth/2;return [{x:a.x+n.x*half,y:a.y+n.y*half},{x:b.x+n.x*half,y:b.y+n.y*half},{x:b.x-n.x*half,y:b.y-n.y*half},{x:a.x-n.x*half,y:a.y-n.y*half}]}
function drawWallPanel(){const w=framingWall();if(!w){label('Select a wall to inspect its framing.',width/2,height/2,14);return}const layout=generateWallFraming(w),audit=auditWallFraming(w),len=distance(w.a,w.b),h=heightOf(w),s=Math.min((width-120)/len,(height-185)/h)*scale,ox=width/2-len*s/2+pan.x,oy=height/2+h*s/2+pan.y+30;rect(ox,oy-h*s,len*s,h*s,'#fbfcf8','#c6d3c1');for(const m of layout.members){const isEndCripple = (m.type.includes('cripple') && (hosted(w).some(o => Math.abs(m.x0 - (o.offset - o.width/2)) < 2 || Math.abs(m.x1 - (o.offset + o.width/2)) < 2)));const color=m.type==='Header'?'#b99969':m.type==='Jack stud'?'#e05600':isEndCripple?'#f97316':m.type.includes('junction')||m.type==='Corner pack'?'#86977b':m.type==='King stud'?'#a79975':'#d1be93';rect(ox+m.x0*s,oy-m.z1*s,(m.x1-m.x0)*s,(m.z1-m.z0)*s,color,'#8c84654f',.6)}for(const o of hosted(w)){ctx.setLineDash([3,3]);rect(ox+(o.offset-o.width/2)*s,oy-(o.sill+o.height)*s,o.width*s,o.height*s,null,'#91a491',.7);ctx.setLineDash([]);label(o.id,ox+o.offset*s,oy-(o.sill+o.height/2)*s,10,'#8e9d87')}line({x:ox,y:oy+24},{x:ox+len*s,y:oy+24},'#95a58d',.8);label(`${w.id} · ${Math.round(len).toLocaleString()} × ${Math.round(h).toLocaleString()} mm`,width/2+pan.x,oy+39,10,'#7b8d74');label(`${layout.members.length} members · ${construction(w).spacing} mm O.C. · Sizes from wall construction settings`,width/2,height-34,10,'#8a9b81');if(audit.issues.length){const visible=audit.issues.slice(0,3);visible.forEach((issue,i)=>label('⚠ '+issue,width/2,height-54-i*14,9,'#a47849'));if(audit.issues.length>visible.length)label(`+ ${audit.issues.length-visible.length} more framing issue(s)`,width/2,height-54-visible.length*14,9,'#a47849')}}
function framingCutRows(walls=model.elements.filter(e=>e.type==='wall')){const map=new Map();for(const w of walls)for(const m of generateWallFraming(w).members){const key=[m.wallId,m.type,m.section,Math.round(m.length*10)/10].join('|'),row=map.get(key)||{wallId:w.id,type:m.type,section:m.section,length:Math.round(m.length*10)/10,quantity:0};row.quantity++;map.set(key,row)}return [...map.values()]}
function framingCSV(){return 'Element,Member,Section mm,Length mm,Quantity\n'+allFramingRows().map(r=>[r.wallId,r.type,r.section,r.length,r.quantity].map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\n')}
function wallOpeningHeadPresetControl(w,type,label,key){
  const list=(typeof hosted==='function'?hosted(w):[]).filter(o=>o.type===type);
  if(!list.length)return '';
  const heads=list.map(o=>Math.round((o.sill||0)+o.height));
  const same=heads.every(h=>h===heads[0]);
  const candidates=[1800,2000,2040,2100,2134,2200,2300,2400,2440,2500,2600];
  const selected=!same?'mixed':(candidates.includes(heads[0])?String(heads[0]):'custom');
  const opts=[];
  if(selected==='mixed')opts.push(['mixed','Mixed / individual values']);
  opts.push(['custom','Custom / per opening'],...candidates.map(v=>[String(v),`${v} mm above wall base`]));
  return `${choice(label,key,selected,opts)}<div class="empty-prop">A preset changes all ${type}s hosted on this wall; opening height adjusts from each existing sill.</div>`;
}
function framingProperties(w){
  const c=construction(w);
  const winHead=wallOpeningHeadPresetControl(w,'window','Apply window head level to all windows','windowHeadPreset');
  const doorHead=wallOpeningHeadPresetControl(w,'door','Apply door head level to all doors','doorHeadPreset');
  return `<div class="section-header">WALL CONSTRUCTION</div>${choice('Structure','structure',w.structure||'basic',[['basic','Basic wall'],['composite','Composite wall']])}${w.structure==='composite'?choice('Composite','composite',w.composite||'timber140',Object.entries(WALL_COMPOSITES).map(([id,c])=>[id,c.name])):''}${choice('Reference','reference',w.reference||'center',[['inside','Inside face'],['center','Centerline'],['outside','Outside face'],['coreInside','Core inside'],['coreCenter','Core center'],['coreOutside','Core outside']])}<div class="wall-property-actions"><button class="subtle" data-wall-action="flip">${icon('mirror')} Flip orientation</button></div>${field('Join priority','priority',w.priority??(w.layer==='Exterior Walls'?100:50))}${field('Base offset','baseOffset',w.baseOffset||0,'mm')}${field('Top offset','topOffset',w.topOffset||0,'mm')}${choice('Top level','topStory',w.topStory||'', [['','Home story top'],...model.stories.filter(s=>s.elevation>storyOf(w).elevation).map(s=>[s.id,s.name])])}<div class="section-header">OPENING HEADER LEVELS</div>${winHead}${doorHead}<div class="empty-prop">Head level is measured above the wall base. For custom values, select an individual opening and edit its head level.</div><div class="section-header">TIMBER FRAMING</div>${choice('Generate','framing.enabled',String(c.enabled),[['true','Enabled'],['false','Disabled']])}${choice('L corner','framing.cornerDetail',c.cornerDetail,[['threeStud','Wood Walls - Corner Outside, 3 Stud'],['twoStud','Corner - Outside 2 Stud'],['fourStud','Corner - Outside 4 Stud']])}<div class="junction-detail-label">Internal wall intersection detail</div>${insideJunctionOptionsHtml(c.insideJunctionDetail)}<div class="empty-prop">Choose the through-wall (the wall that continues past the join). The terminating wall is detected automatically. These are framing-layout details; verify fasteners and structural capacity for the project.</div>${c.insideJunctionDetail==='insideBlocking'?field('Blocking spacing','framing.blockingSpacing',c.blockingSpacing,'mm'):''}${field('Stud width','framing.studWidth',c.studWidth,'mm')}${field('Stud depth','framing.studDepth',c.studDepth,'mm')}${field('Spacing O.C.','framing.spacing',c.spacing,'mm')}${field('Top plates','framing.topPlates',c.topPlates)}${field('Bottom plates','framing.bottomPlates',c.bottomPlates)}${field('Plate size','framing.plateThickness',c.plateThickness,'mm')}${choice('Auto-size header depth','framing.autoHeaderDepth',String(c.autoHeaderDepth!==false),[['true','Automatic by opening span'],['false','Use fixed depth below']])}${field('Header depth','framing.headerDepth',c.headerDepth,'mm')}${field('Header plies','framing.headerPlies',c.headerPlies)}<div class="wall-property-actions"><button class="subtle" data-wall-action="cornerDetail">Corner 3-stud detail</button><button class="subtle" data-wall-action="panel">Wall panel</button><button class="subtle" data-wall-action="cutlist">Cut list</button><button class="subtle" data-wall-action="junctionAudit">Check all intersections</button></div><div class="empty-prop">Framing regenerates from this wall and its openings. Member sizes are construction inputs.</div>`;
}
function setWallProperty(w,key,value){if(key.startsWith('framing.')){const k=key.split('.')[1];if(k==='enabled'||k==='autoHeaderDepth')value=value==='true';else if(k==='cornerDetail'||k==='tDetail'){if(!(k==='cornerDetail'?['threeStud','twoStud','fourStud']:['backingStud','blocking']).includes(value))throw Error('Invalid junction detail.')}else if(k==='insideJunctionDetail'&&!['insideBlocking','insideStudFull','insideStudPartial'].includes(value))throw Error('Select one of the three supported internal wall junction details.');else if(k!=='insideJunctionDetail'&&k!=='cornerDetail'&&k!=='tDetail'&&k!=='enabled'&&k!=='autoHeaderDepth'&&(!Number.isFinite(value)||value<=0||value>10000||(k==='spacing'&&value<20)||(k==='studWidth'&&value<10)||(['topPlates','bottomPlates','headerPlies'].includes(k)&&(!Number.isInteger(value)||value>6))))throw Error('Enter valid member sizes, spacing, or plate counts.');if(k==='spacing'&&value<construction(w).studWidth)throw Error('Stud spacing must be at least the stud width.');if(k==='studDepth'&&w.structure==='composite')throw Error('Composite stud depth follows the structural timber core.');if(k==='studWidth'&&value>construction(w).spacing)throw Error('Stud width cannot exceed the spacing.');const updated={...construction(w),[k]:value};if(k==='insideJunctionDetail')updated.tDetail=value==='insideBlocking'?'blocking':'backingStud';if(k==='tDetail')updated.insideJunctionDetail=value==='blocking'?'insideBlocking':'insideStudFull';w.framing=updated;return true}
  if(['structure','composite'].includes(key)){w[key]=value;if(w.structure==='composite'){const preset=WALL_COMPOSITES[w.composite||'timber140'];w.skins=clone(preset.skins);w.thickness=w.skins.reduce((a,s)=>a+s.thickness,0)}return true}return false;
}
function framingRun(w, customModel){const mModel=customModel||(typeof model!=='undefined'?model:(typeof window!=='undefined'?window.model:null));const elems=(mModel?.elements||[]).filter(e=>e.type==='wall'&&e.id!==w.id&&e.story===w.story&&construction(e).enabled);const len=distance(w.a,w.b),c=construction(w),u=sub2(w.b,w.a),unit={x:u.x/len,y:u.y/len};let start=0,end=len;for(const other of elems){const v=sub2(other.b,other.a),vl=distance(other.a,other.b);if(Math.abs((u.x*v.x+u.y*v.y)/(len*vl))>.01)continue;for(const k of ['a','b']){const joinTolerance=(w.thickness+other.thickness)/2+1;const nearEnd=[other.a,other.b].some(p=>distance(p,w[k])<=joinTolerance),hit=segmentDistance(w[k],other.a,other.b);if(!nearEnd&&!(hit.distance<1&&hit.t>.001&&hit.t<.999))continue;const footprint=framingMemberWorld(other,{x0:-10000,x1:vl+10000,depth:construction(other).studDepth}),values=footprint.map(p=>(p.x-w.a.x)*unit.x+(p.y-w.a.y)*unit.y),lo=Math.min(...values),hi=Math.max(...values),through=nearEnd&&w.id.localeCompare(other.id)<0;if(k==='a')start=through?lo:hi;else end=through?hi:lo}}return {start,end}}

if(typeof window!=='undefined'){
  window.generateWallFraming=generateWallFraming;
  window.wallCenterPoint=wallCenterPoint;
  window.wallBase=wallBase;
  window.referenceOffset=referenceOffset;
  window.coreGeometry=coreGeometry;
  window.wallLayers=wallLayers;
  window.framingProperties=framingProperties;
  window.setWallProperty=setWallProperty;
  window.framingCutRows=framingCutRows;
  window.framingCSV=framingCSV;
  window.auditWallFraming=auditWallFraming;
  window.auditAllWallJunctions=auditAllWallJunctions;
  window.wallFramingJunctions=wallFramingJunctions;
  window.insideJunctionLabel=insideJunctionLabel;
  window.insideJunctionOptionsHtml=insideJunctionOptionsHtml;
  window.insideJunctionCenter=insideJunctionCenter;
  window.drawWallPanel=drawWallPanel;
  window.construction=construction;
}

