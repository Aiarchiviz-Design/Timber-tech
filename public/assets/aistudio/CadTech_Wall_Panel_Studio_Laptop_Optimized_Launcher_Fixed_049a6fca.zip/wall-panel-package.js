/*
 * Wall panel package (single metric PDF)
 * --------------------------------------
 * Exports one PDF containing per-storey wall framing plans, individual wall-panel
 * elevations, opening schedules, cut lists, sheathing layouts and a material summary.
 * Model dimensions and timber sizes are displayed in millimetres; areas are in m2
 * and estimated timber volume is in m3. Panel breaks target the longest lawful
 * segment to reduce the panel count while avoiding openings, corners and junctions.
 * Structural design and construction approvals remain subject to engineer/manufacturer review.
 */
(function () {
  const PAGE_W = 792, PAGE_H = 612; // US letter landscape, points
  const MARGIN = 30;
  const MM_PER_IN = 25.4;
  const SHEET_W = 1219.2, SHEET_H = 2438.4; // standard sheet dimensions, mm
  const OSB_THICKNESS_MM = 12; // requested exterior wall sheathing thickness
  const TYPE_ORDER = ['Bottom plate', 'Top plate', 'King stud', 'Trimmer', 'Header', 'Sill', 'Sill cripple', 'Common stud', 'Stud', 'Jack stud',
    'Upper cripple', 'Lower cripple', 'Cripple', 'Corner pack', 'Corner backing stud', 'T-junction studs', 'Block'];
  const FILL = {
    'Bottom plate': [0.62, 0.46, 0.27], 'Top plate': [0.62, 0.46, 0.27],
    'King stud': [0.80, 0.68, 0.42], 'Trimmer': [0.80, 0.68, 0.42], 'Common stud': [0.90, 0.80, 0.55],
    'Header': [0.50, 0.34, 0.18], 'Sill': [0.58, 0.42, 0.24], 'Sill cripple': [0.92, 0.86, 0.66],
    'Block': [0.85, 0.72, 0.45], 'Beam': [0.62, 0.66, 0.74],
  };
  const DEFAULT_FILL = [0.90, 0.85, 0.70];
  const PLAN_FILL = { 'Bottom plate': [0.62, 0.46, 0.27], 'Top plate': [0.62, 0.46, 0.27], Header: [0.50, 0.34, 0.18] };

  // ------------------------------------------------------------ units & names
  /** Display a model dimension as rounded millimetres. The drawings state their units prominently. */
  function fmtMm(value) {
    const n = Number(value);
    if (!Number.isFinite(n)) return '0';
    return String(Math.round(n));
  }
  // Keep the historical internal name as an alias so older integration code does not break.
  const fis = fmtMm;
  const sqm = mm2 => mm2 / 1_000_000;

  /** Read timber cross sections as metric dimensions. Legacy imperial codes are normalized to actual dressed sizes. */
  function sectionDimensions(section) {
    const raw = String(section || '').trim();
    const m = raw.match(/(\d+(?:\.\d+)?)\s*[x×]\s*(\d+(?:\.\d+)?)/i);
    if (m) {
      let a = Number(m[1]), b = Number(m[2]);
      if (a <= 24 && b <= 24) {
        const actualDepth = { 4: 89, 6: 140, 8: 184, 10: 235, 12: 286 };
        return { width: 38, depth: actualDepth[Math.round(b)] || Math.round(b * 25.4) };
      }
      return { width: Math.round(a), depth: Math.round(b) };
    }
    const one = raw.match(/(\d+(?:\.\d+)?)/);
    const depth = one ? Number(one[1]) : 90;
    return { width: 45, depth: Math.round(depth) };
  }
  function metricSectionLabel(section) {
    const d = sectionDimensions(section);
    return `${d.width} x ${d.depth} mm`;
  }
  function timberVolumeM3(rows) {
    return rows.reduce((sum, r) => {
      const d = sectionDimensions(r.section);
      return sum + (d.width * d.depth * Number(r.length || 0) * Number(r.qty || 0)) / 1_000_000_000;
    }, 0);
  }
  const pdfText = s => String(s).replace(/·/g, '-').replace(/×/g, 'x').replace(/[\\()]/g, m => '\\' + m).replace(/[^\x20-\x7E]/g, '?');

  // ------------------------------------------------------------ PDF writer (vector + Helvetica)
  class Page {
    constructor() { this.ops = []; }
    y(v) { return PAGE_H - v; }
    color(c, stroke) { return `${c[0].toFixed(3)} ${c[1].toFixed(3)} ${c[2].toFixed(3)} ${stroke ? 'RG' : 'rg'}`; }
    line(x1, y1, x2, y2, { w = 0.5, c = [0, 0, 0] } = {}) {
      this.ops.push(`${this.color(c, true)} ${w} w ${x1.toFixed(2)} ${this.y(y1).toFixed(2)} m ${x2.toFixed(2)} ${this.y(y2).toFixed(2)} l S`);
    }
    poly(pts, { fill, stroke = [0, 0, 0], w = 0.6 } = {}) {
      if (!pts || pts.length < 2) return;
      let s = `${this.color(stroke, true)} ${w} w ${pts[0][0].toFixed(2)} ${this.y(pts[0][1]).toFixed(2)} m `;
      for (let i = 1; i < pts.length; i++) s += `${pts[i][0].toFixed(2)} ${this.y(pts[i][1]).toFixed(2)} l `;
      s += 'h ';
      if (fill) { s += `${this.color(fill)} `; s += stroke ? 'B' : 'f'; }
      else s += 'S';
      this.ops.push(s);
    }
    /** Fill at 50% opacity (graphics state GS50), no outline. */
    fillAlpha(pts, fill) {
      if (!pts || pts.length < 2) return;
      let s = `q /GS50 gs ${this.color(fill)} ${pts[0][0].toFixed(2)} ${this.y(pts[0][1]).toFixed(2)} m `;
      for (let i = 1; i < pts.length; i++) s += `${pts[i][0].toFixed(2)} ${this.y(pts[i][1]).toFixed(2)} l `;
      this.ops.push(s + 'h f Q');
    }
    /** Hidden-line outline: dashed stroke. */
    dashed(pts, { stroke = [0, 0, 0], w = 0.5, dash = [3, 2] } = {}) {
      if (!pts || pts.length < 2) return;
      let s = `q [${dash.join(' ')}] 0 d ${this.color(stroke, true)} ${w} w ${pts[0][0].toFixed(2)} ${this.y(pts[0][1]).toFixed(2)} m `;
      for (let i = 1; i < pts.length; i++) s += `${pts[i][0].toFixed(2)} ${this.y(pts[i][1]).toFixed(2)} l `;
      this.ops.push(s + 'h S Q');
    }
    rect(x, y, w, h, { fill, stroke = [0, 0, 0], lw = 0.5 } = {}) {
      this.poly([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], { fill, stroke, w: lw });
    }
    /** rot: 0 or 90 (reads upward). align: left | center | right. */
    text(x, y, str, { size = 8, bold = false, align = 'left', c = [0, 0, 0], rot = 0 } = {}) {
      const s = pdfText(str);
      const approx = s.length * size * (bold ? 0.56 : 0.5);
      const font = bold ? 'F2' : 'F1';
      if (rot === 90) { const start = y + (align === 'right' ? approx : align === 'center' ? approx / 2 : 0); this.ops.push(`BT /${font} ${size} Tf ${this.color(c)} 0 1 -1 0 ${x.toFixed(2)} ${this.y(start).toFixed(2)} Tm (${s}) Tj ET`); }
      else { const off = align === 'right' ? -approx : align === 'center' ? -approx / 2 : 0; this.ops.push(`BT /${font} ${size} Tf ${this.color(c)} ${(x + off).toFixed(2)} ${this.y(y).toFixed(2)} Td (${s}) Tj ET`); }
    }
  }

  function buildPdf(pages) {
    const objs = [];
    const add = s => { objs.push(s); return objs.length; };
    add('<< /Type /Catalog /Pages 2 0 R >>');
    add('');
    add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
    add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>');
    const kids = [];
    for (const pg of pages) {
      const content = pg.ops.join('\n');
      const cnum = add(`<< /Length ${content.length} >>\nstream\n${content}\nendstream`);
      const pnum = add(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE_W} ${PAGE_H}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> /ExtGState << /GS50 << /Type /ExtGState /ca 0.5 /CA 0.5 >> >> >> /Contents ${cnum} 0 R >>`);
      kids.push(`${pnum} 0 R`);
    }
    objs[1] = `<< /Type /Pages /Kids [${kids.join(' ')}] /Count ${pages.length} >>`;
    let out = '%PDF-1.4\n';
    const offsets = [];
    objs.forEach((body, i) => { offsets.push(out.length); out += `${i + 1} 0 obj\n${body}\nendobj\n`; });
    const xref = out.length;
    out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
    offsets.forEach(o => { out += String(o).padStart(10, '0') + ' 00000 n \n'; });
    out += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
    return out;
  }

  // ------------------------------------------------------------ model helpers
  const wallLength = w => Math.hypot(w.b.x - w.a.x, w.b.y - w.a.y);
  /** OSB is only applied to walls explicitly identified as exterior/external/outside.
   * Interior, partition and party walls are never counted as exterior sheathing. */
  function isExteriorWall(w) {
    if (!w) return false;
    const descriptor = [w.layer, w.wallType, w.classification, w.category, w.name, w.typeName]
      .filter(Boolean).join(' ');
    if (/(interior|internal|partition|party wall)/i.test(descriptor)) return false;
    if (w.isExternal === true || w.isExterior === true || w.exterior === true || String(w.reference || '').toLowerCase() === 'outside') return true;
    return /(exterior|external|outer\s*wall|outside)/i.test(descriptor);
  }
  const wallsOfStory = (model, storyId) => model.elements.filter(e => e.type === 'wall' && e.story === storyId);
  const openingsOf = (model, wallId) => model.elements.filter(e => (e.type === 'window' || e.type === 'door') && e.host === wallId).sort((p, q) => p.offset - q.offset);

  /** Metric wall-panel break rules:
   *  - target the longest lawful segment to minimize panel count;
   *  - each break gets a full-height end stud on both adjacent panels;
   *  - avoid openings and a 300 mm opening-edge clearance;
   *  - avoid corners, wall ends, and perpendicular wall junctions within 610 mm.
   * The 6000 mm default is configurable through generateWallPanelPackagePdf({panelMaxLengthMm}). */
  const PANEL_MIN_MM = 2400, PANEL_MAX_MM = 6000;
  const TIGHT_GAP_MM = 38.1;
  const OPENING_CLEAR_MM = 300, JUNCTION_CLEAR_MM = 610;
  function panelRules(options = {}) {
    const requestedMin = Number(options.panelMinLengthMm);
    const requestedMax = Number(options.panelMaxLengthMm);
    const min = Number.isFinite(requestedMin) && requestedMin >= 1200 ? Math.round(requestedMin) : PANEL_MIN_MM;
    const max = Number.isFinite(requestedMax) && requestedMax >= min ? Math.min(12000, Math.round(requestedMax)) : PANEL_MAX_MM;
    return { min, max, preferred: max };
  }

  /** Wall-end and junction positions (mm from wall start) where other walls meet this wall. */
  function breakDistances(w, walls) {
    const len = wallLength(w) || 1, u = { x: (w.b.x - w.a.x) / len, y: (w.b.y - w.a.y) / len };
    const ds = new Set([0, Math.round(len)]), tol = (w.thickness || 200) / 2 + 60;
    for (const o of walls) {
      if (o === w) continue;
      for (const p of [o.a, o.b]) {
        const dx = p.x - w.a.x, dy = p.y - w.a.y;
        const along = dx * u.x + dy * u.y, across = Math.abs(-dx * u.y + dy * u.x);
        if (across <= tol && along > 0 && along < len) ds.add(Math.round(along));
      }
    }
    return [...ds].sort((p, q) => p - q);
  }

  /** Zones along a wall where a break may not fall: junctions, wall ends, and each opening plus its clearance. */
  function noBreakZones(w, walls, model) {
    const len = wallLength(w) || 1;
    const zones = [[-1, JUNCTION_CLEAR_MM], [len - JUNCTION_CLEAR_MM, len + 1]];
    for (const d of breakDistances(w, walls)) zones.push([d - JUNCTION_CLEAR_MM, d + JUNCTION_CLEAR_MM]);
    for (const o of openingsOf(model, w.id)) zones.push([o.offset - o.width / 2 - OPENING_CLEAR_MM, o.offset + o.width / 2 + OPENING_CLEAR_MM]);
    return zones;
  }

  /** Panel segments of one wall: { d0, d1 } along the wall, with a double-stud break at every interior d1.
   *  Searches ahead: a break is kept only if the rest of the wall can still be broken to the same rules. */
  function panelSegments(w, walls, model, options = {}) {
    const len = wallLength(w) || 1, zones = noBreakZones(w, walls, model);
    const rules = panelRules(options), minPanel = rules.min, maxPanel = rules.max, preferredPanel = rules.preferred;
    const allowed = d => d > 0 && d < len && !zones.some(([a, z]) => d > a && d < z);
    const memo = new Map();
    const solve = start => {
      if (memo.has(start)) return memo.get(start);
      let r = null;
      if (len - start <= maxPanel) r = [];
      else {
        const lo = start + minPanel, hi = Math.min(start + maxPanel, len - minPanel);
        const pref = start + preferredPanel, cands = [];
        for (let d = lo; d <= hi; d += 25) if (allowed(d)) cands.push(d);
        cands.sort((p, q) => Math.abs(p - pref) - Math.abs(q - pref));
        for (const d of cands) {
          const rest = solve(d);
          if (rest !== null) { r = [d, ...rest]; break; }
        }
      }
      memo.set(start, r);
      return r;
    };
    const breaks = solve(0) || [];        // null: no lawful set of breaks; the run stays whole and is flagged on its sheet
    const cuts = [0, ...breaks, len], out = [];
    for (let i = 0; i + 1 < cuts.length; i++) out.push({ d0: cuts[i], d1: cuts[i + 1] });
    return out;
  }

  /** Panel tags, numbered across the whole project (as on the MiTek sheets): exterior E-n, interior I-n,
   *  party walls PW-n, one number per panel. Pass the same counters for every storey.
   *  Returns wallId -> { segments: [{ d0, d1, label }], range: 'E-1' or 'E-1 to E-3' }. */
  function assignPanelLabels(walls, counters = { E: 0, I: 0, PW: 0 }, model, options = {}) {
    const map = new Map();
    for (const w of walls) {
      const kind = /party/i.test(w.layer || '') ? 'PW' : /interior/i.test(w.layer || '') ? 'I' : 'E';
      const segments = panelSegments(w, walls, model, options).map(sg => { counters[kind] += 1; return { ...sg, label: `${kind}-${counters[kind]}` }; });
      map.set(w.id, { segments, range: segments.length === 1 ? segments[0].label : `${segments[0].label} to ${segments.at(-1).label}` });
    }
    return map;
  }

  /** King studs and trimmers beside each opening, counted from the wall framing (left - right). */
  function kingTrimmerCounts(o, members, sw) {
    const left = o.offset - o.width / 2, right = o.offset + o.width / 2;
    const near = (x, edge, reach) => Math.abs(x - edge) <= reach;
    const cnt = (type, edge, side) => members.filter(m => m.type === type &&
      near((m.x0 + m.x1) / 2, edge, 250) && (side === 'L' ? (m.x0 + m.x1) / 2 <= left + 1 : (m.x0 + m.x1) / 2 >= right - 1)).length;
    const kingL = cnt('King stud', left, 'L'), kingR = cnt('King stud', right, 'R');
    const trimL = cnt('Trimmer', left, 'L') + cnt('Jack stud', left, 'L'), trimR = cnt('Trimmer', right, 'R') + cnt('Jack stud', right, 'R');
    return { king: `${kingL} - ${kingR}`, trim: `${trimL} - ${trimR}` };
  }

  const memberKey = m => [m.type, m.section, Math.round(m.length)].join('|');

  /** Cut list grouped by type, section and length. */
  function cutListFor(members) {
    const groups = new Map();
    for (const m of members) {
      if (/^Beam$/i.test(m.type)) continue; // engineered beam, supplied separately (not lumber)
      const key = memberKey(m);
      if (!groups.has(key)) groups.set(key, { type: m.type, section: m.section, length: Math.round(m.length), qty: 0, key });
      groups.get(key).qty += 1;
    }
    const rank = t => { const i = TYPE_ORDER.indexOf(t); return i < 0 ? TYPE_ORDER.length : i; };
    const rows = [...groups.values()].sort((p, q) => rank(p.type) - rank(q.type) || q.length - p.length);
    const letter = i => (i < 26 ? String.fromCharCode(65 + i) : 'A' + String.fromCharCode(65 + i - 26));
    return rows.map((r, i) => ({ label: letter(i), ...r, sizeLabel: `${metricSectionLabel(r.section)} SPF No.2` }));
  }

  /** Metric lumber volume, calculated from the stated section dimensions and cut length. */
  const volumeOfRowM3 = r => timberVolumeM3([r]);
  const totalVolumeM3 = rows => rows.reduce((sum, r) => sum + volumeOfRowM3(r), 0);

  /** Sheathing: 4x8 OSB in full sheets, cut at the wall ends and top. */
  function sheathingPieces(L, H) {
    const cols = [];
    for (let x = 0; x < L - 1e-3; x += SHEET_W) cols.push(Math.min(SHEET_W, L - x));
    const rows = [];
    for (let z = 0; z < H - 1e-3; z += SHEET_H) rows.push(Math.min(SHEET_H, H - z));
    const groups = new Map();
    for (const c of cols) for (const r of rows) {
      const long = Math.max(c, r), short = Math.min(c, r);
      const key = `${Math.round(long)}x${Math.round(short)}`;
      if (!groups.has(key)) groups.set(key, { length: long, width: short, qty: 0 });
      groups.get(key).qty += 1;
    }
    return [...groups.values()].sort((p, q) => q.qty - p.qty);
  }

  /** Every stud and cripple position along the wall (centre, mm), one per distinct position. */
  function studPositions(members) {
    const xs = [];
    for (const m of members) {
      if (!/stud|cripple/i.test(m.type) || Math.abs(m.z1 - m.z0) < 200) continue;
      xs.push(Math.round((m.x0 + m.x1) / 2));
    }
    return [...new Set(xs)].sort((p, q) => p - q);
  }
  function studSpacing(xs) {
    const gaps = []; for (let i = 1; i < xs.length; i++) { const g = xs[i] - xs[i - 1]; if (g > 100 && g < 800) gaps.push(g); }
    if (!gaps.length) return 406.4;
    gaps.sort((p, q) => p - q);
    return gaps[Math.floor(gaps.length / 2)];
  }

  // ------------------------------------------------------------ shared sheet furniture
  const TB = { x: PAGE_W - 262, y: PAGE_H - 96, w: 232, h: 66 }; // title block (bottom right)

  function planScaleText(s) {
    const paperPerModel = s * (MM_PER_IN / 72); // paper mm per model mm
    return `1 : ${Math.round(1 / paperPerModel / 10) * 10}`;
  }

  /** Writes a table; returns the y after the last row. */
  function drawTable(pg, x, y, headers, colX, rows, { rowH = 11, fontSize = 6.8 } = {}) {
    headers.forEach((h, i) => pg.text(x + colX[i], y, h, { size: fontSize, bold: true, align: colX.align?.[i] || 'left' }));
    pg.line(x, y + 3, x + colX.total, y + 3, { w: 0.5 });
    let yy = y + rowH + 2;
    for (const r of rows) {
      r.forEach((cell, i) => pg.text(x + colX[i], yy, String(cell), { size: fontSize, align: colX.align?.[i] || 'left' }));
      yy += rowH;
    }
    return yy;
  }

  /** Professional title block: project, sheet title and number, scale, date, drawn by, revision. */
  function drawTitleBlock(pg, o) {
    const { x, y, w, h } = TB;
    pg.rect(x, y, w, h, { stroke: [0, 0, 0], lw: 0.9 });
    pg.line(x, y + 16, x + w, y + 16, { w: 0.5 });
    pg.line(x, y + 34, x + w, y + 34, { w: 0.5 });
    pg.line(x, y + 50, x + w, y + 50, { w: 0.5 });
    pg.line(x + w * 0.5, y + 34, x + w * 0.5, y + h, { w: 0.5 });
    pg.line(x + w * 0.75, y + 50, x + w * 0.75, y + h, { w: 0.5 });
    pg.text(x + 4, y + 11, o.project || 'Project', { size: 7.5, bold: true });
    pg.text(x + 4, y + 27, o.title, { size: 8, bold: true });
    const cell = (cx, cy, k, v) => { pg.text(cx + 4, cy + 7, k, { size: 5.5, c: [0.35, 0.35, 0.35] }); pg.text(cx + 4, cy + 14, v, { size: 7 }); };
    cell(x, y + 34, 'SCALE', o.scale);
    cell(x + w * 0.5, y + 34, 'SHEET', o.sheetNo);
    cell(x, y + 50, 'DATE', new Date().toISOString().slice(0, 10));
    cell(x + w * 0.5, y + 50, 'DRAWN BY', 'CadTech');
    cell(x + w * 0.75, y + 50, 'REV', 'A');
  }

  /** Notes block, bottom left of the sheet. */
  function drawNotes(pg, lines, x, y) {
    pg.text(x, y, 'NOTES', { size: 8, bold: true });
    lines.forEach((t, i) => pg.text(x, y + 11 + i * 9, t, { size: 6.5 }));
  }

  // ------------------------------------------------------------ rooms (clear dimensions from the wall layout)
  /** Rooms are the empty regions enclosed by walls. Doors open walls between rooms; windows do not.
      The grid is 50 mm; room size is the clear span between finished faces (grid cells). */
  function detectRooms(walls, openingsByWall, step = 50) {
    if (!walls.length) return [];
    const pts = walls.flatMap(w => [w.a, w.b]);
    const pad = 800;
    const x0 = Math.min(...pts.map(p => p.x)) - pad, y0 = Math.min(...pts.map(p => p.y)) - pad;
    const nx = Math.ceil((Math.max(...pts.map(p => p.x)) + pad - x0) / step);
    const ny = Math.ceil((Math.max(...pts.map(p => p.y)) + pad - y0) / step);
    const wall = new Uint8Array(nx * ny);
    const id = (i, j) => j * nx + i;
    for (const w of walls) {
      const dx = w.b.x - w.a.x, dy = w.b.y - w.a.y, L = Math.hypot(dx, dy) || 1;
      const ux = dx / L, uy = dy / L, t = (w.thickness || 200) / 2 + step / 2;
      const i0 = Math.max(0, Math.floor((Math.min(w.a.x, w.b.x) - t - x0) / step)), i1 = Math.min(nx - 1, Math.ceil((Math.max(w.a.x, w.b.x) + t - x0) / step));
      const j0 = Math.max(0, Math.floor((Math.min(w.a.y, w.b.y) - t - y0) / step)), j1 = Math.min(ny - 1, Math.ceil((Math.max(w.a.y, w.b.y) + t - y0) / step));
      for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
        const px = x0 + (i + 0.5) * step - w.a.x, py = y0 + (j + 0.5) * step - w.a.y;
        const along = px * ux + py * uy, perp = -px * uy + py * ux;
        if (along >= -t && along <= L + t && Math.abs(perp) <= t) wall[id(i, j)] = 1;
      }
    }
    const outside = new Uint8Array(nx * ny);
    const stack = [];
    const seed = (i, j) => { const k = id(i, j); if (!wall[k] && !outside[k]) { outside[k] = 1; stack.push(k); } };
    for (let i = 0; i < nx; i++) { seed(i, 0); seed(i, ny - 1); }
    for (let j = 0; j < ny; j++) { seed(0, j); seed(nx - 1, j); }
    const flood = (start, mark) => {
      const st = [start], cells = [];
      mark[start] = 1;
      while (st.length) {
        const k = st.pop(); cells.push(k);
        const i = k % nx, j = (k - i) / nx;
        for (const [di, dj] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const ii = i + di, jj = j + dj;
          if (ii < 0 || jj < 0 || ii >= nx || jj >= ny) continue;
          const kk = id(ii, jj);
          if (!wall[kk] && !mark[kk] && !outside[kk]) { mark[kk] = 1; st.push(kk); }
        }
      }
      return cells;
    };
    while (stack.length) {
      const k = stack.pop(); const i = k % nx, j = (k - i) / nx;
      for (const [di, dj] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const ii = i + di, jj = j + dj;
        if (ii >= 0 && jj >= 0 && ii < nx && jj < ny) seed(ii, jj);
      }
    }
    const seen = new Uint8Array(nx * ny);
    const rooms = [];
    for (let k = 0; k < nx * ny; k++) {
      if (wall[k] || outside[k] || seen[k]) continue;
      const cells = flood(k, seen);
      if (cells.length * step * step < 1.5e6) continue; // ignore slivers under 1.5 m2
      let mi = Infinity, Mi = -Infinity, mj = Infinity, Mj = -Infinity;
      for (const c of cells) { const i = c % nx, j = (c - i) / nx; mi = Math.min(mi, i); Mi = Math.max(Mi, i); mj = Math.min(mj, j); Mj = Math.max(Mj, j); }
      rooms.push({
        X0: x0 + mi * step, X1: x0 + (Mi + 1) * step, Y0: y0 + mj * step, Y1: y0 + (Mj + 1) * step,
        width: (Mi - mi + 1) * step, depth: (Mj - mj + 1) * step, area: cells.length * step * step / 1e6,
      });
    }
    rooms.sort((p, q) => (q.Y1 - p.Y1) || (p.X0 - q.X0));
    rooms.forEach((r, i) => { r.id = `R${i + 1}`; r.cx = (r.X0 + r.X1) / 2; r.cy = (r.Y0 + r.Y1) / 2; });
    return rooms;
  }

  // ------------------------------------------------------------ label placement (no overlapping text)
  /** Bounding box of a text as drawn by Page.text (rot 90 reads upward; anchor = start of the text). */
  function textBox(x, y, str, size, align, rot, bold) {
    const approx = String(str).length * size * (bold ? 0.56 : 0.5);
    const h = size * 1.15;
    if (rot === 90) {
      const anchor = y + (align === 'right' ? approx : align === 'center' ? approx / 2 : 0);
      return { x0: x - h, x1: x, y0: anchor - approx, y1: anchor };
    }
    const x0 = align === 'right' ? x - approx : align === 'center' ? x - approx / 2 : x;
    return { x0, x1: x0 + approx, y0: y - size * 0.85, y1: y + size * 0.25 };
  }
  const boxOverlap = (a, b) => Math.max(0, Math.min(a.x1, b.x1) - Math.max(a.x0, b.x0)) * Math.max(0, Math.min(a.y1, b.y1) - Math.max(a.y0, b.y0));
  const unionBox = bs => ({ x0: Math.min(...bs.map(b => b.x0)), x1: Math.max(...bs.map(b => b.x1)), y0: Math.min(...bs.map(b => b.y0)), y1: Math.max(...bs.map(b => b.y1)) });
  const boxInside = (b, r) => b.x0 >= r.x0 && b.x1 <= r.x1 && b.y0 >= r.y0 && b.y1 <= r.y1;

  /** Line offsets: horizontal text stacks downward; rotated (reads upward) text stacks to the right, across the text. */
  const lineAnchor = (x, y, l, opt) => (opt.rot === 90 ? [x + (l.dy || 0), y] : [x, y + (l.dy || 0)]);

  /** Places text groups at the candidate spot with the least overlap with other text and with the framing. */
  class LabelPlacer {
    constructor(pg) { this.pg = pg; this.boxes = []; this.obstacles = []; }
    obstacle(b) { this.obstacles.push(b); }
    place(cands, lines, opt = {}) {
      let best = null, bestScore = Infinity;
      for (const [x, y] of cands) {
        const boxes = lines.map(l => { const [lx, ly] = lineAnchor(x, y, l, opt); return textBox(lx, ly, l.t, l.size || 7, opt.align || 'left', opt.rot || 0, l.bold); });
        const bb = unionBox(boxes);
        if (opt.within && !boxInside(bb, opt.within)) continue;
        let s = 0;
        for (const q of this.boxes) s += boxOverlap(bb, q) * 10;
        for (const q of this.obstacles) s += boxOverlap(bb, q) * 0.02;
        if (s < bestScore) { bestScore = s; best = { x, y, bb, boxes }; if (s === 0) break; }
      }
      if (!best) return null;
      if (opt.backing !== false) this.pg.rect(best.bb.x0 - 1.5, best.bb.y0 - 1, best.bb.x1 - best.bb.x0 + 3, best.bb.y1 - best.bb.y0 + 2, { fill: [1, 1, 1], stroke: opt.backing ? [0.55, 0.65, 0.55] : [1, 1, 1], lw: 0.4 });
      for (const l of lines) { const [lx, ly] = lineAnchor(best.x, best.y, l, opt); this.pg.text(lx, ly, l.t, { size: l.size || 7, bold: !!l.bold, align: opt.align || 'left', rot: opt.rot || 0, c: l.c || [0, 0, 0] }); }
      this.boxes.push(...best.boxes);
      return best;
    }
  }

  // ------------------------------------------------------------ 2D framing plan sheet
  // light shades by wall type, like the reference wall layout
  const WALL_PALETTE = {
    exterior: { fill: [0.97, 0.95, 0.84], plate: [0.92, 0.88, 0.70], header: [0.94, 0.84, 0.60], outline: [0.12, 0.62, 0.62] },
    interior: { fill: [0.88, 0.89, 0.98], plate: [0.79, 0.81, 0.96], header: [0.73, 0.75, 0.93], outline: [0.25, 0.30, 0.72] },
    bearing: { fill: [0.99, 0.88, 0.88], plate: [0.96, 0.78, 0.78], header: [0.93, 0.68, 0.68], outline: [0.78, 0.22, 0.22] },
  };
  const OPENING_PALETTE = { window: [0.82, 0.93, 0.99], door: [0.99, 0.94, 0.78] };
  const wallClass = w => (/exterior/i.test(w.layer || '') ? 'exterior' : (w.structural === 'Load-Bearing' ? 'bearing' : 'interior'));
  function memberFill(cls, m) {
    const p = WALL_PALETTE[cls];
    if (/plate/i.test(m.type)) return p.plate;
    if (/header|sill/i.test(m.type)) return p.header;
    return p.fill;
  }
  /** Colour key, top right of the sheet. */
  function drawLegend(pg, x, y) {
    const items = [
      ['Exterior', WALL_PALETTE.exterior.fill, WALL_PALETTE.exterior.outline],
      ['Interior', WALL_PALETTE.interior.fill, WALL_PALETTE.interior.outline],
      ['Load-bearing', WALL_PALETTE.bearing.fill, WALL_PALETTE.bearing.outline],
      ['Window', OPENING_PALETTE.window, [0.1, 0.3, 0.5]],
      ['Door', OPENING_PALETTE.door, [0.5, 0.4, 0.1]],
    ];
    let cx = x;
    for (const [label, fill, edge] of items) {
      pg.rect(cx, y, 9, 7, { fill, stroke: edge, lw: 0.5 });
      pg.text(cx + 12, y + 6, label, { size: 6 });
      cx += 12 + label.length * 3.3 + 12;
    }
  }

  const PLAN_NOTES = [
    '1. ALL DIMENSIONS AND TIMBER SIZES ARE IN mm. Wall lengths are along the wall centreline.',
    '2. Room dimensions are clear, between finished wall faces. Thickness t is shown on each wall (mm).',
    '3. Lumber SPF No.2. Studs, plates and blocking as per the wall panel schedule.',
    '4. Horizontal blocking every 1219 mm from the wall base, between studs (1219, 2438, 3658 mm ...).',
    '5. Openings: W = window, D = door. Opening codes and dimensions are in mm.',
    '6. Panels: E = exterior, I = interior.',
    '7. Structural design pending. Construction layout only.',
  ];

  function drawPlan(pg, storyName, walls, labels, model, members3d, meta = {}, panelOptions = {}) {
    pg.text(MARGIN, 26, '2D WALL FRAMING PLAN', { size: 14, bold: true });
    pg.text(MARGIN, 40, `${storyName}   wall framing and panel layout   ALL DIMENSIONS AND TIMBER SIZES IN mm`, { size: 8 });
    if (!walls.length) { pg.text(MARGIN, 80, 'No walls on this storey.', { size: 10 }); return; }
    const centroid = {
      x: walls.reduce((s, w) => s + (w.a.x + w.b.x) / 2, 0) / walls.length,
      y: walls.reduce((s, w) => s + (w.a.y + w.b.y) / 2, 0) / walls.length,
    };
    const pts = walls.flatMap(w => [w.a, w.b]);
    const pad = 1900;
    const minX = Math.min(...pts.map(p => p.x)) - pad, maxX = Math.max(...pts.map(p => p.x)) + pad;
    const minY = Math.min(...pts.map(p => p.y)) - pad, maxY = Math.max(...pts.map(p => p.y)) + pad;
    const top = 62, bottom = PAGE_H - 178, left = MARGIN + 70, right = PAGE_W - MARGIN - 30;
    const s = Math.min((right - left) / (maxX - minX), (bottom - top) / (maxY - minY)); // pt per mm
    const X = x => left + (x - minX) * s;
    const Y = y => top + (maxY - y) * s; // north up
    const P = p => [X(p.x), Y(p.y)];
    const L = new LabelPlacer(pg);

    // 1. framed members (stud framing plan). Their boxes are obstacles for every label.
    for (const w of walls) {
      const cls = wallClass(w);
      for (const { m, poly } of members3d.get(w.id) || []) {
        const screen = poly.map(P);
        pg.poly(screen, { fill: memberFill(cls, m), stroke: [0.3, 0.2, 0.1], w: 0.3 });
        L.obstacle({ x0: Math.min(...screen.map(q => q[0])), x1: Math.max(...screen.map(q => q[0])), y0: Math.min(...screen.map(q => q[1])), y1: Math.max(...screen.map(q => q[1])) });
      }
    }

    // wall geometry (mm) used for every label and chain
    const geo = walls.map(w => {
      const len = wallLength(w) || 1, u = { x: (w.b.x - w.a.x) / len, y: (w.b.y - w.a.y) / len };
      let n = { x: -u.y, y: u.x };
      const mid = { x: (w.a.x + w.b.x) / 2, y: (w.a.y + w.b.y) / 2 };
      if ((mid.x - centroid.x) * n.x + (mid.y - centroid.y) * n.y < 0) n = { x: -n.x, y: -n.y }; // outward
      const t = w.thickness || 200;
      const exterior = /exterior/i.test(w.layer || '');
      const at = (d, o2) => P({ x: w.a.x + u.x * d + n.x * o2, y: w.a.y + u.y * d + n.y * o2 });
      return { w, len, u, n, t, exterior, at, vertical: Math.abs(u.x) < 0.5 };
    });

    // 3. stacked dimension strings, after the Hereward sheet. Each exterior wall carries three levels, nearest
    // the wall first, each with extension lines and 45-degree architectural ticks at its break points:
    //   level 1: wall ends and junctions only (wall-to-wall runs)
    //   level 2: + the CENTRE of each window and door (openings are dimensioned to their centre only)
    //   level 3: + every panel joint, so each panel length reads straight off the sheet
    // Interior walls carry one level on their outward side (their detailed level, with panel joints).
    const BASE_EXT = 300, BASE_INT = 260, LEVEL_GAP = 460;
    for (const g of geo) {
      const centres = openingsOf(model, g.w.id).map(o => Math.round(o.offset));
      const joints = (labels.get(g.w.id)?.segments || []).map(sg => Math.round(sg.d1));
      const junctions = breakDistances(g.w, walls);
      const levels = g.exterior
        ? [junctions, [...junctions, ...centres], [...junctions, ...centres, ...joints]]
        : [[...junctions, ...centres, ...joints]];
      let prevKey = null;
      levels.forEach((set, k) => {
        const off = g.t / 2 + (g.exterior ? BASE_EXT : BASE_INT) + k * LEVEL_GAP;
        const cuts = [...new Set([0, Math.round(g.len), ...set.map(v => Math.round(v))])]
          .filter(v => v >= 0 && v <= g.len).sort((p, q) => p - q);
        const key = cuts.join(',');
        if (key === prevKey) return;   // a level that adds no new break would only repeat the one before it
        prevKey = key;
        const e0 = g.at(0, off), e1 = g.at(g.len, off);
        pg.line(e0[0], e0[1], e1[0], e1[1], { w: 0.4 });                   // dimension line
        for (const d of cuts) {
          const f = g.at(d, g.t / 2 + 40), q = g.at(d, off + 90);            // extension line back to the wall
          pg.line(f[0], f[1], q[0], q[1], { w: 0.2 });
          const t1 = g.at(d - 40, off - 40), t2 = g.at(d + 40, off + 40);    // architectural tick
          pg.line(t1[0], t1[1], t2[0], t2[1], { w: 0.6 });
        }
        for (let i = 0; i + 1 < cuts.length; i++) {
          if (cuts[i + 1] - cuts[i] < 20) continue;
          const mid = (cuts[i] + cuts[i + 1]) / 2;
          const cands = [off + 130, off + 60, off + 220].map(o => g.at(mid, o));
          L.place(cands, [{ t: fis(cuts[i + 1] - cuts[i]), size: g.exterior ? 6.2 : 5.8, bold: true }], { align: 'center', rot: g.vertical ? 90 : 0 });
        }
      });
    }

    // 4. wall ID, length, thickness and panel tag: each wall gets its own clear spot
    for (const g of geo.filter(x => x.exterior)) {
      const off = g.exterior ? g.t / 2 + 900 : 0;
      const fracs = [0.5, 0.3, 0.7, 0.2, 0.8, 0.12, 0.88, 0.4, 0.6];
      const dists = [off + 760, off + 1000, off + 1240, off + 1480];
      const cands = [];
      for (const d of dists) for (const f of fracs) cands.push(g.at(g.len * f, d));
      const info = labels.get(g.w.id);
      info.segments.forEach((sg, i, all) => {
        if (i < all.length - 1) { // double-stud break: one tick for each of the two panels it separates
          for (const dd of [-30, 30]) {
            const a = g.at(sg.d1 + dd, -(g.t / 2 + 120)), b = g.at(sg.d1 + dd, g.t / 2 + 120);
            pg.line(a[0], a[1], b[0], b[1], { w: 0.5 });
          }
        }
        const mid = (sg.d0 + sg.d1) / 2, sl = sg.d1 - sg.d0, pc = [];
        for (const d of dists) for (const f of [0, -0.2, 0.2, -0.35, 0.35]) pc.push(g.at(mid + sl * f, d));
        L.place(pc, [{ t: sg.label, size: 8.4, bold: true, c: [0.1, 0.25, 0.6] }], { align: 'center', rot: g.vertical ? 90 : 0 });
      });
    }

    // 5. rooms: clear dimensions and area, white backing, placed inside their own room
    const openingsByWall = new Map(walls.map(w => [w.id, openingsOf(model, w.id)]));
    const rooms = detectRooms(walls, openingsByWall);
    for (const r of rooms) {
      const [rx0, ry0] = P({ x: r.X0, y: r.Y0 }), [rx1, ry1] = P({ x: r.X1, y: r.Y1 });
      const rb = { x0: Math.min(rx0, rx1), x1: Math.max(rx0, rx1), y0: Math.min(ry0, ry1), y1: Math.max(ry0, ry1) };
      const cx = (rb.x0 + rb.x1) / 2, cy = (rb.y0 + rb.y1) / 2, W = rb.x1 - rb.x0, H = rb.y1 - rb.y0;
      const cands = [];
      for (const fx of [0.5, 0.3, 0.7]) for (const fy of [0.5, 0.3, 0.7]) cands.push([rb.x0 + W * fx, rb.y0 + H * fy]);
      L.place(cands, [
        { t: r.id, size: 8, bold: true, c: [0.1, 0.35, 0.2] },
        { t: `${fis(r.width)} x ${fis(r.depth)} clear`, size: 6.2, bold: true, dy: 9 },
        { t: `${r.area.toFixed(2)} m2`, size: 6, dy: 17 },
      ], { align: 'center', backing: true, within: { x0: rb.x0 + 2, x1: rb.x1 - 2, y0: rb.y0 + 2, y1: rb.y1 - 2 } });
    }

    // 4. wall ID, length, thickness and panel tag: each wall gets its own clear spot
    for (const g of geo.filter(x => !x.exterior)) {
      const off = g.exterior ? g.t / 2 + 900 : 0;
      const fracs = [0.5, 0.3, 0.7, 0.2, 0.8, 0.12, 0.88, 0.4, 0.6];
      const dists = [g.t / 2 + 300, -(g.t / 2 + 300), g.t / 2 + 560, -(g.t / 2 + 560), g.t / 2 + 820, -(g.t / 2 + 820)];
      const cands = [];
      for (const d of dists) for (const f of fracs) cands.push(g.at(g.len * f, d));
      const info = labels.get(g.w.id);
      info.segments.forEach((sg, i, all) => {
        if (i < all.length - 1) { // double-stud break: one tick for each of the two panels it separates
          for (const dd of [-30, 30]) {
            const a = g.at(sg.d1 + dd, -(g.t / 2 + 120)), b = g.at(sg.d1 + dd, g.t / 2 + 120);
            pg.line(a[0], a[1], b[0], b[1], { w: 0.5 });
          }
        }
        const mid = (sg.d0 + sg.d1) / 2, sl = sg.d1 - sg.d0, pc = [];
        for (const d of dists) for (const f of [0, -0.2, 0.2, -0.35, 0.35]) pc.push(g.at(mid + sl * f, d));
        L.place(pc, [{ t: sg.label, size: 8.4, bold: true, c: [0.1, 0.25, 0.6] }], { align: 'center', rot: g.vertical ? 90 : 0 });
      });
    }

    // 2. openings: W/D code and size, placed beside the opening (outside or inside the wall line).
    // Codes are per type; openings with the same width x height share one code (W1 for every 900x2100 window, etc.)
    // Opening codes are metric and repeat for openings of the same type and size.
    const openingCode = new Map(), codeBySize = new Map(), codeCount = { window: 0, door: 0 };
    const mmCode = mm => String(Math.round(mm));
    for (const o of model.elements.filter(e => (e.type === 'window' || e.type === 'door') && e.host)) {
      const kind = o.type === 'window' ? 'window' : 'door';
      const key = `${kind}|${Math.round(o.width)}x${Math.round(o.height)}`;
      if (!codeBySize.has(key)) {
        codeCount[kind] += 1;
        const nn = String(codeCount[kind]).padStart(2, '0');
        codeBySize.set(key, kind === 'window' ? `W${nn}-${mmCode(o.width)}x${mmCode(o.height)}mm` : `D${nn}`);
      }
      openingCode.set(o, codeBySize.get(key));
    }
    for (const g of geo) {
      for (const o of openingsOf(model, g.w.id)) {
        const c = { x: g.w.a.x + g.u.x * o.offset, y: g.w.a.y + g.u.y * o.offset };
        // Openings: a light fill at 50% transparency across the wall, so the framing shows through it, and the
        // opening's studs as a dashed hidden rectangle (king and jack studs either side of the opening).
        const hw = o.width / 2, ht = g.t / 2, KING = 90;
        const corner = (da, dn) => P({ x: c.x + g.u.x * da + g.n.x * dn, y: c.y + g.u.y * da + g.n.y * dn });
        const tint = o.type === 'window' ? [0.62, 0.84, 0.98] : [0.98, 0.78, 0.6];
        pg.fillAlpha([corner(-hw, ht), corner(hw, ht), corner(hw, -ht), corner(-hw, -ht)], tint);
        const hs = hw + KING;
        pg.dashed([corner(-hs, ht), corner(hs, ht), corner(hs, -ht), corner(-hs, -ht)], { stroke: [0.25, 0.25, 0.25], w: 0.5, dash: [3, 2] });
        const cands = [];
        // Exterior-wall opening labels prefer the room-facing side so they do not sit on
        // the exterior wall's dimension strings. Interior-wall labels retain the balanced
        // inside/outside search order. LabelPlacer then chooses the first non-obstructed spot.
        const sideCandidates = g.exterior ? [-1, 0, 1, -2, 2, -3, 3] : [0, 1, -1, 2, -2, 3, -3];
        for (const along of [0, o.width / 2 + 350, -(o.width / 2 + 350)]) for (const k of sideCandidates) {
          const dd = g.t / 2 + 320 + Math.abs(k) * 260;
          const sgn = k < 0 ? -1 : 1, off2 = k === 0 ? g.t / 2 + 320 : dd;
          cands.push(P({ x: c.x + g.u.x * along + g.n.x * sgn * off2, y: c.y + g.u.y * along + g.n.y * sgn * off2 }));
        }
        L.place(cands, [{ t: openingCode.get(o), size: 7, bold: true, c: [0.45, 0.32, 0.12] }, { t: `${fis(o.width)} x ${fis(o.height)}`, size: 6.2, dy: 9, c: [0.45, 0.32, 0.12] }], { align: 'center', backing: false });
      }
    }

    // 6. overall dimensions outside the building. A one-wall fixture has zero
    // centreline span in one axis; dimension the wall thickness in that axis
    // instead of emitting a misleading "0 overall" callout.
    const xMin = Math.min(...pts.map(p => p.x)), xMax = Math.max(...pts.map(p => p.x));
    const yMin = Math.min(...pts.map(p => p.y)), yMax = Math.max(...pts.map(p => p.y));
    const maxThickness = Math.max(38, ...walls.map(w => Number(w.thickness) || 140));
    const xDegenerate = xMax - xMin < 1;
    const yDegenerate = yMax - yMin < 1;
    const dxMin = xDegenerate ? xMin - maxThickness / 2 : xMin;
    const dxMax = xDegenerate ? xMax + maxThickness / 2 : xMax;
    const dyMin = yDegenerate ? yMin - maxThickness / 2 : yMin;
    const dyMax = yDegenerate ? yMax + maxThickness / 2 : yMax;
    const ovY = bottom + 46;
    pg.line(X(dxMin), ovY, X(dxMax), ovY, { w: 0.6 });
    const xLabel = xDegenerate ? `${fis(dxMax - dxMin)} wall thickness` : `${fis(xMax - xMin)} overall`;
    L.place([[(X(dxMin) + X(dxMax)) / 2, ovY + 10]], [{ t: xLabel, size: 8, bold: true }], { align: 'center' });
    const ovX = left - 56;
    pg.line(ovX, Y(dyMax), ovX, Y(dyMin), { w: 0.6 });
    const yLabel = yDegenerate ? `${fis(dyMax - dyMin)} wall thickness` : `${fis(yMax - yMin)} overall`;
    L.place([[ovX - 6, (Y(dyMax) + Y(dyMin)) / 2]], [{ t: yLabel, size: 8, bold: true }], { align: 'center', rot: 90 });

    // scale, colour key, notes and title block
    drawNotes(pg, PLAN_NOTES, MARGIN, PAGE_H - 116);
    drawTitleBlock(pg, { project: meta.project, title: `2D WALL FRAMING PLAN - ${storyName}`, sheetNo: `WF-${meta.sheet || '01'}`, scale: planScaleText(s) });
    pg.text(MARGIN, PAGE_H - 22, `Rooms detected: ${rooms.length}. Scale ${planScaleText(s)} at letter landscape.`, { size: 6 });
  }

  // ------------------------------------------------------------ elevation sheet with full dimensions
  /** Schematic wall top plan beneath elevation: stud footprints, panel ends and exterior OSB face. */
  function drawWallPlanStrip(pg, ctx) {
    const { w, label, L, members, openings, exteriorWall, osbApplied } = ctx;
    const xMin = MARGIN + 8, xMax = 418, avail = xMax - xMin;
    const thickness = Math.max(1, Number(w.thickness) || 140);
    // Fit each panel length to the same drawing band. The plan is schematic; dimensions remain actual mm.
    const ps = Math.min(avail / Math.max(L, 1), 25 / thickness);
    const drawLength = L * ps, drawDepth = Math.max(8, Math.min(25, thickness * ps));
    const x0 = xMin + (avail - drawLength) / 2;
    const y0 = 444 + (25 - drawDepth) / 2, y1 = y0 + drawDepth;
    pg.text(xMin, 421, 'WALL PLAN / TOP-PLATE & STUD LAYOUT', { size: 7.2, bold: true });
    pg.text(xMax, 421, `PANEL ${label}`, { size: 6.2, bold: true, align: 'right' });
    pg.rect(x0, y0, drawLength, drawDepth, { fill: [0.96, 0.95, 0.90], stroke: [0.2, 0.2, 0.2], lw: 0.7 });
    // Longitudinal plate edges.
    pg.line(x0, y0 + 1, x0 + drawLength, y0 + 1, { w: 0.35, c: [0.45, 0.35, 0.20] });
    pg.line(x0, y1 - 1, x0 + drawLength, y1 - 1, { w: 0.35, c: [0.45, 0.35, 0.20] });
    // Stud and trimmer footprints, projected across the wall thickness.
    for (const m of members.filter(m => /stud|king|jack|corner|junction|break|trimmer/i.test(m.type))) {
      const xa = x0 + Math.max(0, Math.min(L, m.x0)) * ps;
      const xb = x0 + Math.max(0, Math.min(L, m.x1)) * ps;
      const ww = Math.max(0.8, xb - xa);
      if (xb < x0 || xa > x0 + drawLength) continue;
      pg.rect(xa, y0 + 1.3, ww, Math.max(1, drawDepth - 2.6), { fill: FILL[m.type] || [0.78, 0.70, 0.52], stroke: [0.28, 0.22, 0.12], lw: 0.25 });
    }
    // Opening positions appear as dashed projection lines from the elevation below/above the plan cut.
    for (const o of openings || []) {
      const left = x0 + Math.max(0, Math.min(L, o.offset - o.width / 2)) * ps;
      const right = x0 + Math.max(0, Math.min(L, o.offset + o.width / 2)) * ps;
      pg.dashed([[left, y0 - 2], [right, y0 - 2], [right, y1 + 2], [left, y1 + 2]], { stroke: o.type === 'door' ? [0.72, 0.40, 0.18] : [0.20, 0.45, 0.70], w: 0.35, dash: [2, 2] });
    }
    if (exteriorWall && osbApplied) {
      pg.line(x0, w.flipped ? y1 - 0.6 : y0 + 0.6, x0 + drawLength, w.flipped ? y1 - 0.6 : y0 + 0.6, { w: 1.25, c: [0.85, 0.52, 0.05] });
    }
    const dimY = y1 + 8;
    pg.line(x0, dimY, x0 + drawLength, dimY, { w: 0.45 });
    pg.line(x0, dimY - 3, x0, dimY + 3, { w: 0.4 });
    pg.line(x0 + drawLength, dimY - 3, x0 + drawLength, dimY + 3, { w: 0.4 });
    pg.text(x0 + drawLength / 2, dimY + 9, `${fis(L)} mm OVERALL PANEL LENGTH`, { size: 6.0, bold: true, align: 'center' });
    const osbNote = exteriorWall ? (osbApplied ? '12 mm OSB on exterior face' : 'Exterior OSB OFF') : 'Interior wall - OSB not applicable';
    pg.text(xMin, 498, `Wall thickness ${fis(thickness)} mm | ${osbNote} | Schematic plan; depth displayed for clarity.`, { size: 5.7 });
    pg.text(xMin, 507, 'Opening head levels are measured from wall base; confirm header depth, plies and connections by structural design.', { size: 5.4 });
  }

  /** One page per wall panel: elevation, stud and opening dimensions, cutting list, sheathing and title block. */
  function drawPanelPage(pg, ctx) {
    const { w, label, storyName, L, H, members, openings, rows, stud, area, volumeM3, sheets, exteriorWall = false, osbEnabled = true, meta = {}, sheetNo, panelMaxLengthMm = PANEL_MAX_MM } = ctx;
    const osbApplied = Boolean(exteriorWall && osbEnabled);
    pg.text(MARGIN, 26, `Level: ${storyName}`, { size: 12, bold: true });
    pg.text(PAGE_W / 2, 26, 'WALL PANEL ELEVATION + PLAN', { size: 10, align: 'center' });
    pg.text(PAGE_W - MARGIN, 26, `Panel: ${label}`, { size: 14, bold: true, align: 'right' });
    pg.line(MARGIN, 34, PAGE_W - MARGIN, 34, { w: 1 });
    if (L > panelMaxLengthMm + 1) pg.text(PAGE_W / 2, 38, `CHECK: panel exceeds configured maximum ${panelMaxLengthMm} mm; no lawful break point was found. Review opening and junction clearances.`, { size: 6.5, bold: true, align: 'center', c: [0.75, 0.1, 0.1] });
    pg.text(MARGIN, 46, [`Wall ${w.id}`, `Layer ${w.layer || '-'}`, `Panel length ${fis(L)}`, `Wall height ${fis(H)}`, `Thickness ${Math.round(w.thickness || 0)} mm`,
      `Stud spacing ${fis(stud)} mm o.c.`, `Area ${area.toFixed(2)} m2`, `Timber ${volumeM3.toFixed(3)} m3`, `Openings ${openings.length}`].join('     '), { size: 6.6 });

    // elevation box (left): the panel only, scaled to fit the left two-thirds of the page
    const aL = MARGIN + 70, aR = 418, aTop = 88, aBot = 300;
    const s = Math.min((aR - aL) / L, (aBot - aTop) / H);
    const X = x => aL + x * s, Z = z => aBot - z * s;
    pg.text(MARGIN, 80, `Scale 1 : ${Math.round(1 / (s * (MM_PER_IN / 72)) / 10) * 10}  |  ALL DIMENSIONS IN mm`, { size: 7, bold: true });
    pg.rect(X(0), Z(H), L * s, H * s, { fill: osbApplied ? [0.97, 0.95, 0.87] : [0.97, 0.97, 0.97], stroke: [0, 0, 0], lw: 0.9 });
    // Exterior OSB sheet layout is shown as a pale sheet grid behind the timber members.
    // Each displayed rectangle is clipped to this panel's actual width and height.
    if (osbApplied) {
      for (let sx = 0; sx < L - 1e-3; sx += SHEET_W) {
        const sw = Math.min(SHEET_W, L - sx);
        for (let sz = 0; sz < H - 1e-3; sz += SHEET_H) {
          const sh = Math.min(SHEET_H, H - sz);
          pg.rect(X(sx), Z(sz + sh), sw * s, sh * s, {
            fill: [0.98, 0.96, 0.90], stroke: [0.70, 0.65, 0.51], lw: 0.35,
          });
        }
      }
    }
    for (const m of members) {
      const x0 = X(m.x0), x1 = X(m.x1), z0 = Z(m.z1), z1 = Z(m.z0);
      pg.rect(Math.min(x0, x1), Math.min(z0, z1), Math.abs(x1 - x0), Math.abs(z1 - z0), { fill: FILL[m.type] || DEFAULT_FILL, stroke: [0.35, 0.25, 0.1], lw: 0.2 });
    }
    const letterOf = new Map(rows.map(r => [r.key, r.label]));
    for (const m of members) {
      const letter = letterOf.get(memberKey(m));
      const minH = m.type === 'Block' ? 1.2 : 6;
      if (!letter || (m.x1 - m.x0) * s < 5 || (m.z1 - m.z0) * s < minH) continue;
      pg.text(X((m.x0 + m.x1) / 2), Z((m.z0 + m.z1) / 2) - 2.2, letter, { size: 5.5, bold: true, align: 'center' });
    }
    for (const o of openings) {
      const left = o.offset - o.width / 2, sill = o.sill || 0, top = sill + o.height;
      pg.rect(X(left), Z(top), o.width * s, (top - sill) * s, { fill: o.type === 'window' ? [0.72, 0.85, 0.95] : [0.98, 0.95, 0.85], stroke: [0.1, 0.1, 0.4], lw: 0.7 });
      const cx = X(left + o.width / 2), cy = Z((top + sill) / 2);
      pg.text(cx, cy + 2, `${o.id}`, { size: 6.5, bold: true, align: 'center', c: [0.4, 0.28, 0.1] });
      pg.text(cx, cy + 9, `${fis(o.width)} x ${fis(o.height)}`, { size: 5.6, align: 'center' });
      pg.text(cx, cy + 16, `sill ${fis(sill)}  head ${fis(top)}`, { size: 5.4, align: 'center' });
    }
    // height chain (left) and levels (right)
    const blocks = members.filter(m => /block/i.test(m.type));
    const openLevels = [0, H, ...openings.flatMap(o => [o.sill || 0, (o.sill || 0) + o.height])];
    const blockLevels = [0, H, ...blocks.map(m => m.z0)];
    const zc = [...new Set([...openLevels, ...blockLevels].map(v => Math.round(v)))].sort((p, q) => p - q);   // right side levels
    const chain = (x, levels) => {
      const zs = [...new Set(levels.map(v => Math.round(v)))].sort((p, q) => p - q);
      pg.line(x, Z(0), x, Z(H), { w: 0.5 });
      for (let i = 0; i + 1 < zs.length; i++) {
        if (zs[i + 1] - zs[i] < 20) continue;
        pg.line(x - 3, Z(zs[i]), x + 3, Z(zs[i]), { w: 0.3 });
        pg.text(x - 5, (Z(zs[i]) + Z(zs[i + 1])) / 2, fis(zs[i + 1] - zs[i]), { size: 5.8, align: 'right', rot: 90 });
      }
    };
    const bx = X(0) - 14, openX = bx - 22, ox = openX - 22;   // blocking chain next to the wall, opening chain, overall outermost
    chain(bx, blockLevels);
    chain(openX, openLevels);
    pg.line(ox, Z(0), ox, Z(H), { w: 0.6 });
    pg.line(ox - 3, Z(0), ox + 3, Z(0), { w: 0.4 });
    pg.line(ox - 3, Z(H), ox + 3, Z(H), { w: 0.4 });
    pg.text(ox - 6, (Z(0) + Z(H)) / 2, `${fis(H)} OVERALL HEIGHT`, { size: 6.5, bold: true, align: 'center', rot: 90 });
    const rx = X(L) + 14;
    pg.line(rx, Z(0), rx, Z(H), { w: 0.4 });
    let lastRightY = -Infinity;   // levels closer than the label height share one label, so the text never overlaps
    for (const z of zc) {
      pg.line(rx - 3, Z(z), rx + 3, Z(z), { w: 0.3 });
      if (Z(z) - lastRightY < 8) continue;
      pg.text(rx + 5, Z(z) + 2, fis(z), { size: 5.6 });
      lastRightY = Z(z);
    }

    // stud and cripple dimensions below the panel: one tick per position, labels share a row, crowded labels fan out
    const bottomY = aBot, studTop = bottomY + 20, LBL = 5.2, minGap = LBL * 1.7, ELBOW = 10;
    let lastX = -Infinity;
    [...studPositions(members)].sort((p, q) => p - q).forEach(x => {
      const tx = X(x), txt = fis(x);
      pg.line(tx, bottomY, tx, bottomY + 6, { w: 0.25 });
      const lx2 = Math.max(tx + 2, lastX + minGap);
      lastX = lx2;
      if (lx2 - (tx + 2) > 0.5) {
        pg.line(tx, bottomY + 6, tx, bottomY + 11, { w: 0.35 });
        pg.line(tx, bottomY + 11, lx2, studTop, { w: 0.35 });
      } else {
        pg.line(tx, bottomY + 6, tx, studTop, { w: 0.35 });
      }
      pg.text(lx2, studTop + txt.length * LBL * 0.5, txt, { size: LBL, rot: 90 });
    });
    const bandsBottom = studTop + LBL * 4.5 + 4;
    // openings chain (centre-to-edge breaks along the panel)
    const brk = [...new Set([0, ...openings.flatMap(o => [o.offset - o.width / 2, o.offset + o.width / 2]), L].map(v => Math.round(v)))].sort((p, q) => p - q);
    const rowOpen = bandsBottom + 10;
    pg.line(X(0), rowOpen, X(L), rowOpen, { w: 0.5 });
    for (let i = 0; i + 1 < brk.length; i++) {
      if (brk[i + 1] - brk[i] < 20) continue;
      const x1 = X(brk[i]), x2 = X(brk[i + 1]);
      pg.line(x1, rowOpen - 3, x1, rowOpen + 3, { w: 0.3 });
      pg.text((x1 + x2) / 2, rowOpen + 9, fis(brk[i + 1] - brk[i]), { size: 6, align: 'center' });
    }
    pg.line(X(L), rowOpen - 3, X(L), rowOpen + 3, { w: 0.3 });
    const rowOverall = rowOpen + 20;
    pg.line(X(0), rowOverall, X(L), rowOverall, { w: 0.6 });
    pg.line(X(0), rowOverall - 3, X(0), rowOverall + 3, { w: 0.4 });
    pg.line(X(L), rowOverall - 3, X(L), rowOverall + 3, { w: 0.4 });
    pg.text((X(0) + X(L)) / 2, rowOverall + 10, `${fis(L)} OVERALL O/A FRAMING`, { size: 7.5, bold: true, align: 'center' });
    pg.text(MARGIN, rowOverall + 22, 'Stud and cripple positions: member centre, measured from the left end of the panel in mm.', { size: 5.8 });
    drawWallPlanStrip(pg, { w, label, L, members, openings, exteriorWall, osbApplied });

    // cutting list (right column)
    const cx0 = 462;
    pg.text(cx0, 66, 'CUTTING LIST', { size: 8, bold: true });
    const body = rows.map(r => [r.label, r.type, r.sizeLabel, r.qty, fis(r.length), volumeOfRowM3(r).toFixed(4)]);
    const headers = ['Mark', 'Member', 'Size mm', 'Qty', 'Cut mm', 'Vol m3'];
    const colX = [0, 24, 85, 169, 198, 248]; colX.total = 288; colX.align = ['left', 'left', 'left', 'right', 'right', 'right'];
    const rowH = body.length > 22 ? 7.4 : 9;
    const yEnd = drawTable(pg, cx0, 74, headers, colX, body, { rowH, fontSize: 5.6 });
    pg.text(cx0, yEnd + 10, `Total timber volume: ${volumeM3.toFixed(3)} m3`, { size: 6.8, bold: true });
    if (!body.length) pg.text(cx0, 88, 'No framing members.', { size: 7 });

    // Exterior OSB sheathing takeoff (right column, below the cutting list).
    const sy = yEnd + 26;
    let ry;
    if (!exteriorWall) {
      pg.text(cx0, sy, `${OSB_THICKNESS_MM} mm OSB: NOT APPLICABLE - EXTERIOR WALLS ONLY`, { size: 6.4, bold: true });
      ry = sy + 22;
    } else if (!osbEnabled) {
      pg.text(cx0, sy, `${OSB_THICKNESS_MM} mm OSB SHEATHING: OFF`, { size: 6.8, bold: true });
      pg.text(cx0, sy + 10, 'No OSB pieces are included in this panel takeoff.', { size: 5.9 });
      ry = sy + 24;
    } else {
      pg.text(cx0, sy, `${OSB_THICKNESS_MM} mm OSB SHEATHING - EXTERIOR FACE ONLY (SHEET 1219 x 2438 mm)`, { size: 6.4, bold: true });
      const sColX = [0, 84, 155]; sColX.total = 220; sColX.align = ['left', 'left', 'right'];
      drawTable(pg, cx0, sy + 10, ['Cut L mm', 'Cut W mm', 'Qty'], sColX, sheets.map(sh => [fis(sh.length), fis(sh.width), `(${sh.qty})`]), { rowH: 8.5, fontSize: 5.8 });
      ry = sy + 10 + 8.5 * (sheets.length + 1) + 16;
    }
    pg.text(cx0, ry, 'Openings', { size: 8, bold: true });
    if (!openings.length) pg.text(cx0, ry + 10, 'No openings.', { size: 6.2 });
    openings.forEach((o, i) => {
      const left = o.offset - o.width / 2, sill = o.sill || 0;
      pg.text(cx0, ry + 10 + i * 9, `${o.id}  ${o.type}  ${fis(o.width)} x ${fis(o.height)}  sill ${fis(sill)}  head ${fis(sill + o.height)}  left ${fis(left)}`, { size: 5.8 });
    });
    ry += 10 + Math.max(1, openings.length) * 9 + 8;
    if (blocks.length) {
      pg.text(cx0, ry, 'Blocking (horizontal, from base)', { size: 8, bold: true });
      const byZ = new Map();
      for (const m of blocks) { const k = Math.round(m.z0); if (!byZ.has(k)) byZ.set(k, []); byZ.get(k).push(m); }
      [...byZ.entries()].sort((p, q) => p[0] - q[0]).forEach(([z, ms], i) => {
        pg.text(cx0, ry + 10 + i * 9, `Row at ${fis(z)}:  ${ms.length} pc${ms.length > 1 ? 's' : ''}  length ${ms.map(m => fis(m.length)).join(', ')}`, { size: 5.8 });
      });
    }

    drawTitleBlock(pg, { project: meta.project, title: `WALL PANEL ${label} - ${w.id}`, sheetNo, scale: `1 : ${Math.round(1 / (s * (MM_PER_IN / 72)) / 10) * 10}` });
  }

  // ------------------------------------------------------------ main build
  function irelandValue(value, unit = '') {
    return value === undefined || value === null || String(value).trim() === '' ? 'NOT ENTERED' : `${value}${unit ? ` ${unit}` : ''}`;
  }

  function drawRegisterTable(pg, y, headers, secondColumn, rows, { rowH = 12, fontSize = 7 } = {}) {
    const cols = [0, secondColumn];
    cols.total = PAGE_W - 2 * MARGIN;
    cols.align = ['left', 'left'];
    return drawTable(pg, MARGIN, y, headers, cols, rows, { rowH, fontSize });
  }

  /** Preliminary Irish design-basis/load register. Values are user-entered; this page performs no code checks. */
  function buildIrelandDesignBasisPage(model, options = {}) {
    const pg = new Page();
    const sd = model.structuralDesign || {};
    const ie = sd.ireland || {};
    pg.text(MARGIN, 27, 'REPUBLIC OF IRELAND - WALL PANEL DESIGN BASIS & LOAD REGISTER', { size: 13, bold: true });
    pg.text(MARGIN, 43, `Project: ${model.name || 'Project'} | Revision: ${model.revision ?? '--'} | Exterior 12 mm OSB: ${options.exteriorOsbEnabled === false ? 'OFF' : 'ON'} | INPUT REGISTER ONLY - ENGINEER REVIEW REQUIRED`, { size: 7.5 });
    pg.text(MARGIN, 59, 'SITE AND ADOPTED CODE BASIS', { size: 8.5, bold: true, c: [0.10, 0.30, 0.21] });
    const basisRows = [
      ['Site location / town / county / Eircode', irelandValue(ie.siteLocation)],
      ['Building Control Authority / reviewer', irelandValue(ie.authority)],
      ['Confirmed code editions / National Annexes', irelandValue(ie.codeEdition)],
      ['Load combinations / partial factors basis', irelandValue(ie.loadCombinationBasis)],
      ['Site altitude above sea level', irelandValue(ie.siteAltitudeM, 'm AOD')],
      ['Terrain / exposure description', irelandValue(ie.terrainExposure)],
      ['Basic wind velocity vb,0 (site basis)', irelandValue(ie.basicWindVelocityMS, 'm/s')],
    ];
    drawRegisterTable(pg, 72, ['Project input', 'Value entered'], 275, basisRows, { rowH: 12, fontSize: 7 });
    pg.text(MARGIN, 181, 'CHARACTERISTIC ACTIONS / WALL LOAD TRANSFER INPUTS', { size: 8.5, bold: true, c: [0.10, 0.30, 0.21] });
    const actionRows = [
      ['Floor permanent action Gk', irelandValue(ie.floorDeadKNm2, 'kN/m2')],
      ['Floor imposed action Qk', irelandValue(ie.floorImposedKNm2, 'kN/m2')],
      ['Roof permanent action Gk', irelandValue(ie.roofDeadKNm2, 'kN/m2')],
      ['Roof imposed / maintenance action Qk', irelandValue(ie.roofImposedKNm2, 'kN/m2')],
      ['Characteristic ground snow load sk', irelandValue(ie.groundSnowKNm2, 'kN/m2')],
      ['Calculated characteristic roof snow action', irelandValue(ie.roofSnowKNm2, 'kN/m2')],
      ['Net wall wind pressure', irelandValue(ie.windPressureKNm2, 'kN/m2')],
      ['Net wall wind suction', irelandValue(ie.windSuctionKNm2, 'kN/m2')],
      ['Net roof uplift', irelandValue(ie.roofUpliftKNm2, 'kN/m2')],
      ['Wall / top-plate gravity line load', irelandValue(ie.wallGravityLineKNm, 'kN/m')],
      ['Maximum beam / truss point reaction', irelandValue(ie.maxPointReactionKN, 'kN')],
    ];
    drawRegisterTable(pg, 194, ['Action', 'Characteristic input'], 340, actionRows, { rowH: 11, fontSize: 6.7 });
    pg.text(MARGIN, 338, 'TIMBER, SHEATHING AND LATERAL RESISTANCE', { size: 8.5, bold: true, c: [0.10, 0.30, 0.21] });
    const materialRows = [
      ['Timber strength class / product', irelandValue(ie.timberGrade)],
      ['Timber service class', irelandValue(ie.serviceClass)],
      ['Lateral / racking system', irelandValue(ie.lateralSystem)],
      ['OSB class / product declaration', irelandValue(ie.osbGrade)],
      ['OSB thickness', irelandValue(ie.osbThicknessMM, 'mm')],
      ['OSB edge fastener spacing', irelandValue(ie.osbEdgeFixingSpacingMM, 'mm')],
      ['OSB field fastener spacing', irelandValue(ie.osbFieldFixingSpacingMM, 'mm')],
    ];
    drawRegisterTable(pg, 351, ['Design item', 'Value / specification'], 275, materialRows, { rowH: 11, fontSize: 6.7 });
    pg.text(MARGIN, 450, 'CODE BASIS TO CONFIRM FOR THE PROJECT', { size: 8, bold: true, c: [0.10, 0.30, 0.21] });
    pg.text(MARGIN, 463, 'Irish Building Regulations Part A / TGD A; I.S. EN 1990; I.S. EN 1991-1-1; I.S. EN 1991-1-3; I.S. EN 1991-1-4; I.S. EN 1991-1-7;', { size: 6.5 });
    pg.text(MARGIN, 473, 'I.S. EN 1995-1-1 with Irish National Annex; EN 1995-1-2 where fire design applies; EN 338 / EN 14081 for timber; EN 300 / EN 13986 for OSB/panel products.', { size: 6.5 });
    pg.text(MARGIN, 490, 'NOTES / LOAD SOURCES', { size: 7.5, bold: true });
    const note = String(ie.loadNotes || 'No design notes entered.').replace(/\s+/g, ' ').trim();
    const noteLines = note.match(/.{1,145}(?:\s|$)/g) || [];
    noteLines.slice(0, 3).forEach((line, i) => pg.text(MARGIN, 501 + i * 7, line.trim(), { size: 6.2 }));
    pg.line(MARGIN, 526, PAGE_W - MARGIN, 526, { w: 0.6, c: [0.65, 0.35, 0.12] });
    pg.text(MARGIN, 537, 'CAUTION: Blank values are NOT ENTERED, not zero. Load values are project inputs, not values calculated by this software.', { size: 7, bold: true, c: [0.55, 0.20, 0.10] });
    pg.text(MARGIN, 548, 'This page is a design brief only; it does not verify wind/snow actions, load combinations, member sizes, OSB shear, fasteners, anchorage or foundations.', { size: 6.6 });
    pg.text(MARGIN, 558, 'Confirm the applicable Eurocode generation and Irish National Annex editions with NSAI and the project reviewer. A competent structural engineer must verify and approve.', { size: 6.6 });
    pg.text(MARGIN, 583, 'Official references: gov.ie - Technical Guidance Document A; NSAI - Eurocodes in Ireland; NSAI Irish National Annexes for snow actions and timber structures.', { size: 6.2 });
    return pg;
  }

  function buildPackage(model, framingFn, plannerFn, options = {}) {
    const pages = [];
    if (String(model.structuralDesign?.region || '').toUpperCase() === 'IE') pages.push(buildIrelandDesignBasisPage(model, options));
    // Rough openings: every window and door is framed 12.7 mm larger in width and height.
    // The sill stays put; the framed head rises by 12.7 mm.
    const RO_TOL_MM = 12.7;
    const roModel = { ...model, elements: model.elements.map(e => (e.type === 'window' || e.type === 'door')
      ? { ...e, width: e.width + RO_TOL_MM, height: e.height + RO_TOL_MM } : e) };
    const roWall = w => ({ ...w, openings: openingsOf(roModel, w.id) });
    const roFraming = w => framingFn(roWall(w), roModel);
    const stories = (model.stories && model.stories.length ? model.stories : [{ id: 's0', name: 'Level 1' }])
      .filter(s => model.elements.some(e => e.type === 'wall' && e.story === s.id));
    const summary = [];
    const allOpenings = [];
    const osbEnabled = options.exteriorOsbEnabled !== false; // default ON; toggle OFF explicitly with false

    const panelCounters = { E: 0, I: 0, PW: 0 }; // project-wide numbering, continuous across storeys
    for (const story of stories) {
      const walls = wallsOfStory(model, story.id);
      const labels = assignPanelLabels(walls, panelCounters, roModel, options);
      const storyName = story.name || story.id;

      const members3d = new Map();
      for (const w of walls) {
        const ms = ((roFraming(w).members) || []).map(m => ({ m, poly: plannerFn(w, m) })).filter(x => x.poly && x.poly.length >= 4);
        members3d.set(w.id, ms);
      }

      const plan = new Page();
      drawPlan(plan, storyName, walls, labels, model, members3d, { project: model.name || 'Project', sheet: String(stories.indexOf(story) + 1).padStart(2, '0') }, options);
      pages.push(plan);

      for (const w of walls) {
        const info = labels.get(w.id);
        const wallMembers = (roFraming(w).members || []).map(m => ({ ...m }));
        const wallOpenings = openingsOf(roModel, w.id);
        for (const sg of info.segments) {
          const label = sg.label, L = sg.d1 - sg.d0;
          // a stud belongs to the panel its centre falls in; plates are clipped to the panel
          const members = wallMembers
            .filter(m => /plate/i.test(m.type) ? (m.x1 > sg.d0 && m.x0 < sg.d1) : ((m.x0 + m.x1) / 2 >= sg.d0 && (m.x0 + m.x1) / 2 <= sg.d1))
            .map(m => {
              const x0 = Math.max(0, m.x0 - sg.d0), x1 = Math.min(L, m.x1 - sg.d0);
              return { ...m, x0, x1, ...(/plate/i.test(m.type) ? { length: Math.max(0, x1 - x0) } : {}) };   // a plate piece is only as long as its span
            });
          const openings = wallOpenings
            .filter(o => o.offset >= sg.d0 && o.offset <= sg.d1)
            .map(o => ({ ...o, offset: o.offset - sg.d0 }));
          // End studs: every panel edge gets a full-height stud, so each panel stands on its own.
          // A wall corner gets a Corner stud; a panel edge at a break gets a Break stud (one for each panel).
          const tmpl = members.find(m => /^Common stud$/i.test(m.type)) || members.find(m => /stud/i.test(m.type));
          if (tmpl) {
            const tw = tmpl.x1 - tmpl.x0, WL = wallLength(w);
            const hasEnd = atStart => members.some(m => /stud|king|corner|junction|jack/i.test(m.type) && Math.abs(m.z1 - m.z0) > 200 &&
              (atStart ? m.x0 < tw + TIGHT_GAP_MM : m.x1 > L - tw - TIGHT_GAP_MM));
            for (const atStart of [true, false]) {
              if (hasEnd(atStart)) continue;
              const isCorner = atStart ? sg.d0 <= 0.5 : sg.d1 >= WL - 0.5;
              const x0 = atStart ? 0 : L - tw, x1 = atStart ? tw : L;
              members.push({ ...tmpl, type: isCorner ? 'Corner stud' : 'Break stud', x0, x1, length: tmpl.length });
            }
          }
          // Clear gaps under 1.5" (38.1 mm) between two full-height studs are not built: a common stud that
          // sits that close to another stud is redundant, so it is removed. Touching studs (king and jack) stay.
          for (let changed = true; changed;) {
            changed = false;
            const full = members.filter(m => /stud|corner|king|jack|junction|break/i.test(m.type) && Math.abs(m.z1 - m.z0) > 200).sort((a, b) => a.x0 - b.x0);
            for (let i = 0; i + 1 < full.length && !changed; i++) {
              const a = full[i], b = full[i + 1], gap = b.x0 - a.x1;
              if (gap <= 1 || gap >= TIGHT_GAP_MM) continue;
              const victim = /^Common stud$/i.test(b.type) ? b : /^Common stud$/i.test(a.type) ? a : null;
              if (victim) { members.splice(members.indexOf(victim), 1); changed = true; }
            }
          }
          // Blocking runs stud face to stud face: each block is clipped to the clear span between the full-height
          // studs on either side, so it attaches to both.
          const fullStuds = members.filter(m => /stud|corner|king|jack|junction|break/i.test(m.type) && Math.abs(m.z1 - m.z0) > 200);
          for (const b of members.filter(m => /block/i.test(m.type))) {
            const c = (b.x0 + b.x1) / 2;
            const left = fullStuds.filter(q => q.x1 <= c + 1).sort((p1, p2) => p2.x1 - p1.x1)[0];
            const right = fullStuds.filter(q => q.x0 >= c - 1).sort((p1, p2) => p1.x0 - p2.x0)[0];
            if (left) b.x0 = left.x1;
            if (right) b.x1 = right.x0;
            b.length = Math.max(0, b.x1 - b.x0);
          }
          const rows = cutListFor(members);
          allOpenings.push(...openings.map(o => ({ ...o, panel: label, ...kingTrimmerCounts(o, members, w.studWidth || 45) })));
          const area = sqm(L * w.height);
          const stud = studSpacing(studPositions(members));
          const exteriorWall = isExteriorWall(w);
          const sheets = (osbEnabled && exteriorWall) ? sheathingPieces(L, w.height) : [];
          const osbPieces = sheets.reduce((t, x) => t + x.qty, 0);
          const volumeM3 = totalVolumeM3(rows);
          const pg = new Page();
          const configuredMax = panelRules(options).max;
          drawPanelPage(pg, { w, label, storyName, L, H: w.height, members, openings, rows, stud, area, volumeM3, sheets, exteriorWall, osbEnabled, panelMaxLengthMm: configuredMax, meta: { project: model.name || 'Project' }, sheetNo: `EL-${String(stories.indexOf(story) + 1).padStart(2, '0')}-${label}` });
          pages.push(pg);
          summary.push({ label, wallId: w.id, length: L, height: w.height, area, stud, volumeM3, osbPieces, exteriorWall, osbApplied: osbEnabled && exteriorWall, studs: members.filter(m => /stud/i.test(m.type)).length, blocks: members.filter(m => m.type === 'Block').length, openings: openings.length });
        }
      }
    }

    if (allOpenings.length) {
      const sched = new Page();
      sched.text(MARGIN, 30, 'WINDOW & DOOR SCHEDULE - DIMENSIONS IN mm', { size: 14, bold: true });
      const groups = new Map();
      for (const o of allOpenings) {
        const key = [o.type, o.width, o.height, o.sill || 0, o.king, o.trim].join('|');
        if (!groups.has(key)) groups.set(key, { type: o.type, width: o.width, height: o.height, sill: o.sill || 0, king: o.king, trim: o.trim, panels: new Set(), qty: 0, ids: [] });
        const g = groups.get(key); g.qty += 1; g.panels.add(o.panel); g.ids.push(o.id);
      }
      const colX = [0, 36, 118, 178, 236, 292, 340, 396, 446]; colX.total = 600; colX.align = ['left', 'left', 'right', 'right', 'right', 'right', 'center', 'center', 'left'];
      const rows = [...groups.values()].map(g => [g.qty, g.type === 'window' ? 'Window' : 'Door', fis(g.width), fis(g.height), fis(g.sill + g.height), fis(g.sill), g.king, g.trim, `${g.ids.join(', ')}  (${[...g.panels].join(', ')})`]);
      drawTable(sched, MARGIN, 60, ['Qty', 'Type', 'Width', 'Height', 'Head level', 'Sill', 'King (L-R)', 'Trimmer (L-R)', 'IDs (panels)'], colX, rows, { rowH: 13 });
      sched.text(MARGIN, PAGE_H - 30, 'Heights are measured from wall base. Opening schedule dimensions are framed rough openings (nominal opening + 12.7 mm). King studs and trimmers are counted left-right; confirm against structural design.', { size: 7 });
      pages.push(sched);
    }

    if (summary.length) {
      const sum = new Page();
      sum.text(MARGIN, 30, 'WALL PANEL MATERIAL SUMMARY - DIMENSIONS AND TIMBER SIZES IN mm', { size: 12, bold: true });
      const colX = [0, 45, 120, 200, 260, 310, 360, 420, 480, 530]; colX.total = 580; colX.align = ['left', 'left', 'right', 'right', 'right', 'right', 'right', 'right', 'right', 'right'];
      const rows = summary.map(s => [s.label, s.wallId, fis(s.length), fis(s.height), s.area.toFixed(2), s.studs, s.blocks, s.volumeM3.toFixed(3), s.osbPieces, s.openings]);
      const totalVolume = summary.reduce((a, s) => a + s.volumeM3, 0), totalOsbPieces = summary.reduce((a, s) => a + s.osbPieces, 0);
      const y = drawTable(sum, MARGIN, 60, ['Panel', 'Wall', 'Length mm', 'Height mm', 'Area m2', 'Studs', 'Blocks', 'Timber m3', 'OSB pcs', 'Openings'], colX, rows, { rowH: 12 });
      sum.line(MARGIN, y, MARGIN + colX.total, y, { w: 0.5 });
      sum.text(MARGIN, y + 12, `Total: ${summary.length} panels, ${totalVolume.toFixed(3)} m3 timber, ${totalOsbPieces} OSB cut pieces (${osbEnabled ? 'exterior OSB ON' : 'exterior OSB OFF'}).`, { size: 8, bold: true });
      sum.text(MARGIN, y + 26, 'OSB cut-piece quantities are based on 1219 x 2438 mm sheets and gross panel rectangles; allow for openings, offcuts and project waste when ordering. Timber volume is a geometric estimate; confirm design and fabrication requirements before construction.', { size: 6.2 });
      pages.push(sum);
    }
    return { pages, panelCount: summary.length };
  }

  /** Member footprint in world coordinates: the app's own function. */
  function defaultPlanner(w, m) {
    if (typeof window.framingMemberWorld === 'function') return window.framingMemberWorld(w, m);
    if (typeof framingMemberWorld === 'function') return framingMemberWorld(w, m);
    return null;
  }

  /** Public entry: builds the package and downloads one PDF. */
  window.generateWallPanelPackagePdf = function (opts = {}) {
    const model = opts.model || window.model;
    const framingFn = opts.framingFn || window.generateWallFraming;
    const plannerFn = opts.plannerFn || defaultPlanner;
    if (!model || typeof framingFn !== 'function') throw new Error('Model or wall framing generator not available.');
    const { pages, panelCount } = buildPackage(model, framingFn, plannerFn, opts);
    const pdf = buildPdf(pages);
    const blob = new Blob([pdf], { type: 'application/pdf' });
    if (opts.download !== false && typeof document !== 'undefined' && typeof URL !== 'undefined') {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = 'wall-panel-package.pdf';
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 4000);
    }
    return { bytes: pdf, pages: pages.length, panels: panelCount };
  };
  window.wallPanelPackageInternals = { fmtMm, fis, buildPdf, Page, sheathingPieces, cutListFor, timberVolumeM3, totalVolumeM3, sectionDimensions, metricSectionLabel, panelSegments, panelRules, buildPackage, buildIrelandDesignBasisPage, drawWallPlanStrip, studSpacing, studPositions, detectRooms, openingsOf, isExteriorWall };
})();
