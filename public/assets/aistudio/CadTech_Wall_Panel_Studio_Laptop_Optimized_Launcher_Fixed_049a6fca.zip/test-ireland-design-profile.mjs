import assert from 'node:assert/strict';
import fs from 'node:fs';

globalThis.window = globalThis;
globalThis.document = undefined;
(0, eval)(fs.readFileSync(new URL('./wall-panel-package.js', import.meta.url), 'utf8'));
const api = window.wallPanelPackageInternals;
const source = fs.readFileSync(new URL('./framing-plan.js', import.meta.url), 'utf8');
let n = 0;
const ok = message => { n++; console.log(`  ok - ${message}`); };

assert(source.includes("IE:{name:'Ireland (Republic)'"));
assert(source.includes('I.S. EN 1990'));
assert(source.includes('I.S. EN 1991-1-3'));
assert(source.includes('I.S. EN 1991-1-4'));
assert(source.includes('I.S. EN 1995-1-1'));
assert(source.includes('EN 300'));
assert(source.includes('basicWindVelocityMS'));
assert(source.includes('groundSnowKNm2'));
assert(source.includes('windPressureKNm2'));
assert(source.includes('osbEdgeFixingSpacingMM'));
assert(source.includes('site-specific actions'));
ok('Ireland preset includes structural codes, site-specific actions, timber class/service class, OSB and connection inputs');

const wall = { id:'IE-W1', type:'wall', story:'s0', layer:'Exterior Walls', reference:'outside', a:{x:0,y:0}, b:{x:5000,y:0}, height:2700, thickness:200 };
const model = {
  name:'Ireland sample project', revision:3, stories:[{id:'s0',name:'Ground Floor'}], elements:[wall],
  structuralDesign:{region:'IE', jurisdiction:'Ireland (Republic)', standard:'Irish Building Regulations Part A / TGD A + I.S. EN Eurocodes and Irish National Annexes', ireland:{siteLocation:'', authority:'', codeEdition:'', siteAltitudeM:null, terrainExposure:'', basicWindVelocityMS:null}}
};
const framingFn = () => ({members:[]});
const built = api.buildPackage(model, framingFn, () => null, {exteriorOsbEnabled:false});
const pdf = api.buildPdf(built.pages);
assert.equal(built.pages.length, 4); // design-basis page + plan + elevation + material summary
assert(pdf.includes('REPUBLIC OF IRELAND - WALL PANEL DESIGN BASIS & LOAD REGISTER'));
assert(pdf.includes('NOT ENTERED'));
assert(pdf.includes('I.S. EN 1990'));
assert(pdf.includes('I.S. EN 1991-1-3'));
assert(pdf.includes('I.S. EN 1991-1-4'));
assert(pdf.includes('I.S. EN 1995-1-1'));
assert(pdf.includes('Blank values are NOT ENTERED, not zero'));
ok('Ireland wall-panel PDF prepends a design-basis and load-register page without inventing blank site loads');

const noIreland = api.buildPackage({...model, structuralDesign:{region:'US'}}, framingFn, () => null, {exteriorOsbEnabled:false});
assert.equal(noIreland.pages.length, 3);
ok('non-Ireland reports retain their existing page sequence');

const blankPage = api.buildIrelandDesignBasisPage(model);
const blankPdf = api.buildPdf([blankPage]);
assert(blankPdf.includes('NOT ENTERED'));
assert(!blankPdf.includes('115 mph'));
assert(!blankPdf.includes('20 psf'));
ok('Ireland report contains no hidden US wind-load defaults');

console.log(`\n${n} Ireland profile checks passed`);
