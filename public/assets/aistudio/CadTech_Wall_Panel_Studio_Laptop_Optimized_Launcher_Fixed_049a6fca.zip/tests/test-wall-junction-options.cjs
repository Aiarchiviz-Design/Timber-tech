const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const source = fs.readFileSync(path.join(__dirname, '..', 'framing.js'), 'utf8');
const THROUGH = {id:'W-THROUGH',type:'wall',story:'s0',a:{x:0,y:0},b:{x:4000,y:0},thickness:140,height:2700,material:'Timber',reference:'center',framing:{enabled:true,insideJunctionDetail:'insideStudFull'}};
const BRANCH = {id:'W-BRANCH',type:'wall',story:'s0',a:{x:2000,y:70},b:{x:2000,y:2000},thickness:90,height:2700,material:'Timber',reference:'center'};

function makeContext(mode) {
  const walls = JSON.parse(JSON.stringify([THROUGH, BRANCH]));
  walls[0].framing.insideJunctionDetail = mode;
  const model = {stories:[{id:'s0',name:'Ground Floor',elevation:0,height:2700}],elements:walls};
  const ctx = {
    console,
    JOIN_EPS: 1,
    model,
    activeStory:'s0',
    selected:[walls[0].id],
    distance(a,b){return Math.hypot(b.x-a.x,b.y-a.y)},
    sub2(a,b){return {x:a.x-b.x,y:a.y-b.y}},
    lerp(a,b,t){return {x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t}},
    cross2(a,b){return a.x*b.y-a.y*b.x},
    segmentDistance(p,a,b){
      const dx=b.x-a.x,dy=b.y-a.y,l2=dx*dx+dy*dy||1;
      const t=Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/l2));
      const point={x:a.x+dx*t,y:a.y+dy*t};
      return {distance:Math.hypot(p.x-point.x,p.y-point.y),t,point};
    },
    axisIntersection(a,b,c,d){
      const r={x:b.x-a.x,y:b.y-a.y},s={x:d.x-c.x,y:d.y-c.y};
      const den=r.x*s.y-r.y*s.x;if(Math.abs(den)<1e-9)return null;
      const ca={x:c.x-a.x,y:c.y-a.y};
      const t=(ca.x*s.y-ca.y*s.x)/den,sVal=(ca.x*r.y-ca.y*r.x)/den;
      if(t<0||t>1||sVal<0||sVal>1)return null;
      return {t,s:sVal,point:{x:a.x+t*r.x,y:a.y+t*r.y}};
    },
    heightOf(w){return w.height||2700},
    storyOf(w){return model.stories.find(s=>s.id===w.story)||{elevation:0}},
    hosted(w){return model.elements.filter(e=>e.host===w.id)},
    rawWallPoly(){return []},
    choice(label,key,value,options){return `<select data-property="${key}"><option>${value}</option></select>`},
    field(label,key,value,unit){return `<input data-property="${key}" value="${value}">`},
    icon(){return ''},
    clone(value){return JSON.parse(JSON.stringify(value))},
    materials:{Timber:'#ccc'},
    width:800,height:600,scale:1,pan:{x:0,y:0},
    rect(){},line(){},label(){},
    window:null
  };
  ctx.window=ctx;
  vm.createContext(ctx);
  vm.runInContext(source,ctx,{filename:'framing.js'});
  return ctx;
}

for (const mode of ['insideBlocking','insideStudFull','insideStudPartial']) {
  const ctx=makeContext(mode), through=ctx.model.elements[0];
  const junctions=ctx.wallFramingJunctions(through,ctx.model).filter(j=>j.type==='T-junction studs');
  assert.equal(junctions.length,1,`${mode}: must detect one T-junction for an end landing on the wall face`);
  const layout=ctx.generateWallFraming(through,ctx.model);
  assert.equal(layout.issues.length,0,`${mode}: generated layout must not report a junction geometry issue: ${layout.issues.join('; ')}`);
  const returns=layout.members.filter(m=>m.role==='T-junction return stud');
  assert.equal(returns.length,2,`${mode}: must generate two return studs`);
  const backing=layout.members.filter(m=>m.junctionId&&['Horizontal backing','Perpendicular backing stud','Partial inside backing stud'].includes(m.role));
  assert.ok(backing.length>0,`${mode}: must generate the selected backing detail`);
  if(mode==='insideBlocking')assert.ok(backing.every(m=>m.role==='Horizontal backing'));
  if(mode==='insideStudFull')assert.ok(backing.some(m=>m.role==='Perpendicular backing stud'&&m.z1-m.z0>2400));
  if(mode==='insideStudPartial')assert.ok(backing.some(m=>m.role==='Partial inside backing stud'&&m.z1-m.z0>2400));
  const audit=ctx.auditAllWallJunctions(ctx.model);
  assert.equal(audit.reviewCount,0,`${mode}: generated junction should pass detail audit: ${audit.issues.join('; ')}`);
  assert.equal(audit.connections[0].detail,ctx.insideJunctionLabel(mode));
  const html=ctx.framingProperties(through);
  for(const label of ['Blocking','Stud, Full','Stud, Partial'])assert.ok(html.includes(label),`UI selector contains ${label}`);
  assert.ok(html.includes('data-junction-detail="'+mode+'"'),`UI must make ${mode} selectable`);
  console.log(`PASS ${mode}: T-junction detected; 2 return studs; correct backing; audit OK`);
}

// Legacy files keep their previous tDetail option mapped to the current selector.
{
  const ctx=makeContext('insideStudFull');
  const w=ctx.model.elements[0];
  w.framing={enabled:true,tDetail:'blocking'};
  assert.equal(ctx.construction(w).insideJunctionDetail,'insideBlocking');
  assert.equal(ctx.setWallProperty(w,'framing.insideJunctionDetail','insideStudPartial'),true);
  assert.equal(w.framing.insideJunctionDetail,'insideStudPartial');
  assert.equal(w.framing.tDetail,'backingStud');
  console.log('PASS backward compatibility: legacy tDetail mapping and select updates');
}
