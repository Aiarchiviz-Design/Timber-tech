const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const framingSource = fs.readFileSync(path.join(__dirname, '..', 'framing.js'), 'utf8');

/**
 * Load the app's classic-script wall framing engine in an isolated Node VM.
 * This mirrors the small geometry surface provided by app.js in the browser.
 * The custom model remains explicit so import tests cannot accidentally use a
 * stale global model from another project.
 */
function createFramingContext(model) {
  const ctx = {
    console,
    JOIN_EPS: 1,
    model,
    activeStory: model?.stories?.[0]?.id || 's0',
    selected: [],
    distance(a, b) { return Math.hypot((b?.x || 0) - (a?.x || 0), (b?.y || 0) - (a?.y || 0)); },
    sub2(a, b) { return { x: a.x - b.x, y: a.y - b.y }; },
    lerp(a, b, t) { return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t }; },
    cross2(a, b) { return a.x * b.y - a.y * b.x; },
    segmentDistance(p, a, b) {
      const dx = b.x - a.x, dy = b.y - a.y, l2 = dx * dx + dy * dy || 1;
      const t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2));
      const point = { x: a.x + dx * t, y: a.y + dy * t };
      return { distance: Math.hypot(p.x - point.x, p.y - point.y), t, point };
    },
    axisIntersection(a, b, c, d) {
      const r = { x: b.x - a.x, y: b.y - a.y }, s = { x: d.x - c.x, y: d.y - c.y };
      const den = r.x * s.y - r.y * s.x;
      if (Math.abs(den) < 1e-9) return null;
      const ca = { x: c.x - a.x, y: c.y - a.y };
      const t = (ca.x * s.y - ca.y * s.x) / den;
      const sv = (ca.x * r.y - ca.y * r.x) / den;
      if (t < 0 || t > 1 || sv < 0 || sv > 1) return null;
      return { t, s: sv, point: { x: a.x + t * r.x, y: a.y + t * r.y } };
    },
    heightOf(w) { return w.height || 2700; },
    storyOf(w) { return model.stories?.find(s => s.id === w.story) || { elevation: 0 }; },
    hosted(w) { return (model.elements || []).filter(e => e.host === w.id); },
    hostOf(e) { return (model.elements || []).find(w => w.id === e.host); },
    rawWallPoly(w, a, b, offset = 0) {
      const len = Math.hypot(b.x - a.x, b.y - a.y) || 1;
      const half = (w.thickness || 0) / 2 + offset;
      const nx = -(b.y - a.y) / len * half, ny = (b.x - a.x) / len * half;
      return [{ x: a.x + nx, y: a.y + ny }, { x: b.x + nx, y: b.y + ny }, { x: b.x - nx, y: b.y - ny }, { x: a.x - nx, y: a.y - ny }];
    },
    choice(label, key, value) { return `<select data-property="${key}"><option>${value}</option></select>`; },
    field(label, key, value) { return `<input data-property="${key}" value="${value}">`; },
    icon() { return ''; },
    clone(value) { return JSON.parse(JSON.stringify(value)); },
    materials: { Timber: '#ccc' },
    width: 800, height: 600, scale: 1, pan: { x: 0, y: 0 },
    rect() {}, line() {}, label() {},
    window: null
  };
  ctx.window = ctx;
  vm.createContext(ctx);
  vm.runInContext(framingSource, ctx, { filename: 'framing.js' });
  return ctx;
}

module.exports = { createFramingContext };
