"""Dependency-free regression checks for the laptop launcher."""
from __future__ import annotations

import importlib.util
import json
import socket
import tempfile
import threading
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("cadtech_launcher", ROOT / "Run_CadTech_Wall_Panel.py")
assert SPEC and SPEC.loader
launcher = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(launcher)


class HealthHandler(BaseHTTPRequestHandler):
    def do_GET(self):  # noqa: N802 - stdlib API name
        self.send_response(200 if self.path == "/api/health" else 404)
        self.end_headers()
        self.wfile.write(b"ok")

    def log_message(self, *_args):
        pass


class LauncherTests(unittest.TestCase):
    def test_node_version_parser(self):
        self.assertEqual(launcher.parse_version("v22.16.0"), (22, 16, 0))
        self.assertEqual(launcher.parse_version("20.11"), (20, 11, 0))
        self.assertIsNone(launcher.parse_version("not installed"))

    def test_minimum_node_version(self):
        self.assertTrue(launcher.at_least((22, 12, 0), launcher.MIN_NODE))
        self.assertFalse(launcher.at_least((22, 11, 99), launcher.MIN_NODE))

    def test_windows_npm_command_uses_node_cli_for_paths_with_spaces(self):
        # Simulate the standard Windows Node installation layout under a path
        # containing spaces; this reproduces the user's C:\Program Files case.
        with tempfile.TemporaryDirectory(prefix="Node Install With Spaces ") as temp:
            root = Path(temp)
            node = root / "node.exe"
            npm_cli = root / "node_modules" / "npm" / "bin" / "npm-cli.js"
            node.touch()
            npm_cli.parent.mkdir(parents=True)
            npm_cli.write_text("// test fixture\n", encoding="utf-8")
            command = launcher.find_npm(str(node), platform="nt")
            self.assertEqual(command, [str(node), str(npm_cli)])
            self.assertTrue(all('"' not in part for part in command))

    def test_windows_missing_npm_cli_fails_cleanly(self):
        with tempfile.TemporaryDirectory(prefix="Node Install With Spaces ") as temp:
            node = Path(temp) / "node.exe"
            node.touch()
            self.assertIsNone(launcher.find_npm(str(node), platform="nt"))

    def test_npm_is_invoked_as_argument_list_without_shell_requoting(self):
        command = [
            r"C:\Program Files\nodejs\node.exe",
            r"C:\Program Files\nodejs\node_modules\npm\bin\npm-cli.js",
        ]
        with patch.object(launcher.subprocess, "run", return_value=SimpleNamespace(returncode=0)) as run:
            self.assertEqual(launcher.run_npm(command, ["ci", "--no-audit"]), 0)
        run.assert_called_once_with([*command, "ci", "--no-audit"], cwd=str(ROOT), check=False)

    def test_project_files_are_packaged(self):
        for rel in ("package.json", "package-lock.json", "server.ts", "index.html", "RUN_CADTECH_WALL_PANEL.bat"):
            self.assertTrue((ROOT / rel).is_file(), f"Missing launcher dependency: {rel}")

    def test_package_json_matches_lockfile_root(self):
        package = json.loads((ROOT / "package.json").read_text(encoding="utf-8"))
        lock = json.loads((ROOT / "package-lock.json").read_text(encoding="utf-8"))
        for section in ("dependencies", "devDependencies"):
            self.assertEqual(package.get(section, {}), lock["packages"][""][section], f"package-lock root mismatch: {section}")

    def test_local_health_probe(self):
        server = HTTPServer(("127.0.0.1", 0), HealthHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            base = f"http://127.0.0.1:{server.server_port}"
            self.assertTrue(launcher.health_check(base + "/api/health"))
            self.assertFalse(launcher.health_check(base + "/not-health"))
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

    def test_port_reservation_returns_bindable_port(self):
        port = launcher.reserve_port()
        self.assertIsNotNone(port)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.bind(("127.0.0.1", int(port)))


if __name__ == "__main__":
    unittest.main(verbosity=2)
