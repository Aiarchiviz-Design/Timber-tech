import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { createFramingContext } = require('./tests/framing-test-context.cjs');

const framingSource = fs.readFileSync(new URL('./framing.js', import.meta.url), 'utf8');
const packageSource = fs.readFileSync(new URL('./wall-panel-package.js', import.meta.url), 'utf8');

// The legacy analysis module supplied assembly coordinates in metres. Confirm the
// exported report adapter converts them to the current metric panel/elevation package.
globalThis.window = globalThis;
globalThis.document = undefined;
const model = { name: 'adapter base', stories: [{ id: 's0', name: 'Ground Floor', elevation: 0, height: 2700 }], elements: [] };
const ctx = createFramingContext(model);
globalThis.generateWallFraming = (wall, customModel) => ctx.generateWallFraming(wall, customModel || model);
globalThis.framingMemberWorld = (wall, member) => ctx.framingMemberWorld(wall, member);
vm.runInThisContext(packageSource, { filename: 'wall-panel-package.js' });

const { makeMitekWallFramingReport, makeWallFramingReport } = await import('./report.js');
const assembly = { project: 'Legacy Adapter QA', wallAssemblies: [{
  id: 'LEG-W1', name: 'Exterior wall', start: [0, 0, 0], end: [6, 0, 0], heightM: 2.7,
  section: '2x6', layer: 'Exterior Walls', spacingM: 0.4064,
  openings: [{ id: 'LEG-D1', type: 'door', a: 1.1, b: 2.0, sill: 0, head: 2.1 },
    { id: 'LEG-WIN1', type: 'window', a: 3.5, b: 4.7, sill: 0.9, head: 2.1 }]
}] };
const pdf = makeMitekWallFramingReport(assembly, 'Legacy Adapter QA');
assert.equal(typeof pdf, 'string');
assert.ok(pdf.startsWith('%PDF-1.4'));
assert.ok(pdf.includes('WALL PANEL ELEVATION + PLAN'));
assert.ok(pdf.includes('WALL PLAN / TOP-PLATE & STUD LAYOUT'));
assert.ok(pdf.includes('12 mm OSB SHEATHING - EXTERIOR FACE ONLY'));
assert.ok(!pdf.includes('PROFESSIONAL ENGINEER SEAL'));
assert.ok(!pdf.includes('7/16'));
const pdfViaMain = makeWallFramingReport(assembly, 'Legacy Adapter QA');
assert.ok(pdfViaMain.startsWith('%PDF-1.4'));
assert.ok(pdfViaMain.includes('WALL PANEL ELEVATION + PLAN'));
console.log('PASS legacy wall assemblies use current metric panel/elevation/OSB PDF; no hard-coded legacy cutlist or fake engineer seal');
