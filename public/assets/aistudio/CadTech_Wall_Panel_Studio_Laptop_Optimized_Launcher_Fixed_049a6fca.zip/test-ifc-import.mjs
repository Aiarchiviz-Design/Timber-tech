// Verification test for ArchiCAD IFC Import and Framing Synthesis
import { parseSTEP, convertIFCToBIMModel, autoGenerateFramingPipeline } from './ifc-importer.js';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { createFramingContext } = require('./tests/framing-test-context.cjs');

console.log('Testing ArchiCAD IFC Import & Framing Engine...');

// Sample STEP IFC Physical File exported from ArchiCAD (containing walls, slab, and roof)
const sampleIFC = `ISO-10303-21;
HEADER;
FILE_DESCRIPTION(('ViewDefinition [CoordinationView_V2.0]'),'2;1');
FILE_NAME('ArchiCAD_Project.ifc','2026-10-25T10:00:00',('Architect'),('Graphisoft'),'The BIM Server','ArchiCAD 28.0.0','');
FILE_SCHEMA(('IFC2X3'));
ENDSEC;
DATA;
#1=IFCPROJECT('1Project001',#2,'ArchiCAD Villa',$,$,$,$,(#3),#4);
#2=IFCOWNERHISTORY(#5,#6,$,.ADDED.,$,$,$,$);
#3=IFCGEOMETRICREPRESENTATIONCONTEXT($,'Model',3,1.E-05,#7,$);
#4=IFCUNITASSIGNMENT((#8,#9,#10));
#5=IFCPERSON($,$,'User',$,$,$,$,$);
#6=IFCORGANIZATION($,'Graphisoft',$,$,$);
#7=IFCAXIS2PLACEMENT3D(#11,#12,#13);
#8=IFCSIUNIT(*,.LENGTHUNIT.,$,.METRE.);
#9=IFCSIUNIT(*,.PLANEANGLEUNIT.,$,.RADIAN.);
#10=IFCSIUNIT(*,.TIMEUNIT.,$,.SECOND.);
#11=IFCCARTESIANPOINT((0.,0.,0.));
#12=IFCDIRECTION((0.,0.,1.));
#13=IFCDIRECTION((1.,0.,0.));

/* Spatial Hierarchy */
#20=IFCSITE('1Site001',#2,'Site',$,$,#21,$,$,.ELEMENT.,$,$,$,$,$);
#21=IFCLOCALPLACEMENT($,#7);
#22=IFCBUILDING('1Bldg001',#2,'Building',$,$,#23,$,$,.ELEMENT.,$,$,$);
#23=IFCLOCALPLACEMENT(#21,#7);
#24=IFCBUILDINGSTOREY('1Story001',#2,'Ground Floor',$,$,#25,$,$,.ELEMENT.,0.);
#25=IFCLOCALPLACEMENT(#23,#7);
#26=IFCBUILDINGSTOREY('1Story002',#2,'Roof Level',$,$,#27,$,$,.ELEMENT.,3.048);
#27=IFCLOCALPLACEMENT(#23,#28);
#28=IFCAXIS2PLACEMENT3D(#29,#12,#13);
#29=IFCCARTESIANPOINT((0.,0.,3.048));

/* Walls */
#30=IFCWALLSTANDARDCASE('1Wall001',#2,'Exterior Wall North',$,$,#31,#32,'Wall-N');
#31=IFCLOCALPLACEMENT(#25,#33);
#33=IFCAXIS2PLACEMENT3D(#34,#12,#13);
#34=IFCCARTESIANPOINT((0.,0.,0.));
#32=IFCPRODUCTDEFINITIONSHAPE($,$,(#35,#36));
#35=IFCSHAPEREPRESENTATION(#3,'Axis','Curve2D',(#37));
#37=IFCPOLYLINE((#38,#39));
#38=IFCCARTESIANPOINT((0.,0.));
#39=IFCCARTESIANPOINT((12.,0.));
#36=IFCSHAPEREPRESENTATION(#3,'Body','SweptSolid',(#40));
#40=IFCEXTRUDEDAREASOLID(#41,#7,#12,3.048);
#41=IFCRECTANGLEPROFILEDEF(.AREA.,'Wall Profile',#42,12.,0.2);
#42=IFCAXIS2PLACEMENT2D(#43,#44);
#43=IFCCARTESIANPOINT((6.,0.));
#44=IFCDIRECTION((1.,0.));

#50=IFCWALLSTANDARDCASE('1Wall002',#2,'Exterior Wall East',$,$,#51,#52,'Wall-E');
#51=IFCLOCALPLACEMENT(#25,#53);
#53=IFCAXIS2PLACEMENT3D(#54,#12,#55);
#54=IFCCARTESIANPOINT((12.,0.,0.));
#55=IFCDIRECTION((0.,1.,0.));
#52=IFCPRODUCTDEFINITIONSHAPE($,$,(#56));
#56=IFCSHAPEREPRESENTATION(#3,'Axis','Curve2D',(#57));
#57=IFCPOLYLINE((#58,#59));
#58=IFCCARTESIANPOINT((0.,0.));
#59=IFCCARTESIANPOINT((8.,0.));

#60=IFCWALLSTANDARDCASE('1Wall003',#2,'Exterior Wall South',$,$,#61,#62,'Wall-S');
#61=IFCLOCALPLACEMENT(#25,#63);
#63=IFCAXIS2PLACEMENT3D(#64,#12,#13);
#64=IFCCARTESIANPOINT((12.,8.,0.));
#62=IFCPRODUCTDEFINITIONSHAPE($,$,(#65));
#65=IFCSHAPEREPRESENTATION(#3,'Axis','Curve2D',(#66));
#66=IFCPOLYLINE((#67,#68));
#67=IFCCARTESIANPOINT((0.,0.));
#68=IFCCARTESIANPOINT((-12.,0.));

#70=IFCWALLSTANDARDCASE('1Wall004',#2,'Exterior Wall West',$,$,#71,#72,'Wall-W');
#71=IFCLOCALPLACEMENT(#25,#73);
#73=IFCAXIS2PLACEMENT3D(#74,#12,#55);
#74=IFCCARTESIANPOINT((0.,8.,0.));
#72=IFCPRODUCTDEFINITIONSHAPE($,$,(#75));
#75=IFCSHAPEREPRESENTATION(#3,'Axis','Curve2D',(#76));
#76=IFCPOLYLINE((#77,#78));
#77=IFCCARTESIANPOINT((0.,0.));
#78=IFCCARTESIANPOINT((0.,-8.));

/* Floor Slab */
#80=IFCSLAB('1Slab001',#2,'Floor Slab',$,$,#81,#82,'Slab-01',.FLOOR.);
#81=IFCLOCALPLACEMENT(#25,#7);
#82=IFCPRODUCTDEFINITIONSHAPE($,$,(#83));
#83=IFCSHAPEREPRESENTATION(#3,'Body','SweptSolid',(#84));
#84=IFCEXTRUDEDAREASOLID(#85,#7,#12,0.2);
#85=IFCARBITRARYCLOSEDPROFILEDEF(.AREA.,'Slab Contour',#86);
#86=IFCPOLYLINE((#87,#88,#89,#90,#87));
#87=IFCCARTESIANPOINT((0.,0.));
#88=IFCCARTESIANPOINT((12.,0.));
#89=IFCCARTESIANPOINT((12.,8.));
#90=IFCCARTESIANPOINT((0.,8.));

/* Roof */
#100=IFCROOF('1Roof001',#2,'Main Hip Roof',$,$,#101,#102,'Roof-01',.HIP.);
#101=IFCLOCALPLACEMENT(#27,#7);
#102=IFCPRODUCTDEFINITIONSHAPE($,$,(#103));
#103=IFCSHAPEREPRESENTATION(#3,'Body','Brep',(#104));
#104=IFCEXTRUDEDAREASOLID(#85,#7,#12,1.8);

/* Openings, Doors & Windows */
#110=IFCOPENINGELEMENT('1Open001',#2,'Entrance Door Opening',$,$,#111,#112,'Open-01');
#111=IFCLOCALPLACEMENT(#31,#113);
#113=IFCAXIS2PLACEMENT3D(#114,#12,#13);
#114=IFCCARTESIANPOINT((3.0,0.,0.));
#112=IFCPRODUCTDEFINITIONSHAPE($,$,(#115));
#115=IFCSHAPEREPRESENTATION(#3,'Body','SweptSolid',(#116));
#116=IFCEXTRUDEDAREASOLID(#117,#7,#12,2.1);
#117=IFCRECTANGLEPROFILEDEF(.AREA.,'Door Profile',#42,1.0,0.2);
#120=IFCRELVOIDSELEMENT('1Void001',#2,$,$,#30,#110);
#130=IFCDOOR('1Door001',#2,'Main Entrance Door 1000x2100',$,$,#111,$,'Door-01',2.1,1.0);
#140=IFCRELFILLSELEMENT('1Fill001',#2,$,$,#110,#130);

#150=IFCOPENINGELEMENT('1Open002',#2,'Wide Window Opening',$,$,#151,#152,'Open-02');
#151=IFCLOCALPLACEMENT(#61,#153);
#153=IFCAXIS2PLACEMENT3D(#154,#12,#13);
#154=IFCCARTESIANPOINT((6.0,0.,0.9));
#152=IFCPRODUCTDEFINITIONSHAPE($,$,(#155));
#155=IFCSHAPEREPRESENTATION(#3,'Body','SweptSolid',(#156));
#156=IFCEXTRUDEDAREASOLID(#157,#7,#12,1.5);
#157=IFCRECTANGLEPROFILEDEF(.AREA.,'Window Profile',#42,1.8,0.2);
#160=IFCRELVOIDSELEMENT('1Void002',#2,$,$,#60,#150);
#170=IFCWINDOW('1Win001',#2,'Wide Window 1800x1500',$,$,#151,$,'Win-01',1.5,1.8);
#180=IFCRELFILLSELEMENT('1Fill002',#2,$,$,#150,#170);

ENDSEC;
END-ISO-10303-21;`;

// 1. Test STEP parsing
const entities = parseSTEP(sampleIFC);
console.log(`Parsed ${entities.size} STEP entities.`);
if (entities.size < 25) throw new Error(`Expected at least 25 entities, got ${entities.size}`);

// 2. Test BIM model conversion
const { model, stats } = convertIFCToBIMModel(sampleIFC, 'ArchiCAD Sample Villa', { codeStandard: 'IRC_2021', spacing: 406.4 });
console.log('Conversion stats:', stats);

if (stats.wallsCount !== 4) throw new Error(`Expected 4 walls, got ${stats.wallsCount}`);
if (stats.slabsCount !== 1) throw new Error(`Expected 1 slab, got ${stats.slabsCount}`);
if (stats.roofsCount !== 1) throw new Error(`Expected 1 roof, got ${stats.roofsCount}`);
if (stats.storiesCount !== 2) throw new Error(`Expected 2 stories, got ${stats.storiesCount}`);
if (stats.openingsCount !== 2) throw new Error(`Expected 2 openings, got ${stats.openingsCount}`);
if (stats.doorsCount !== 1) throw new Error(`Expected 1 door, got ${stats.doorsCount}`);
if (stats.windowsCount !== 1) throw new Error(`Expected 1 window, got ${stats.windowsCount}`);

console.log('Checking converted elements:');
const wall1 = model.elements.find(e => e.type === 'wall');
console.log('Sample wall:', wall1.id, 'Start:', wall1.a, 'End:', wall1.b, 'Thickness:', wall1.thickness, 'Height:', wall1.height, 'Code:', wall1.framing.codeStandard);
if (wall1.thickness !== 200 || wall1.height !== 3048 || wall1.framing.codeStandard !== 'IRC_2021') throw new Error('Wall configuration mismatch');

const door1 = model.elements.find(e => e.type === 'door');
console.log('Sample door:', door1.id, 'Host:', door1.host, 'Width:', door1.width, 'Height:', door1.height, 'Sill:', door1.sill);
if (door1.width !== 1000 || door1.height !== 2100 || door1.sill !== 0) throw new Error('Door dimensions mismatch');

const window1 = model.elements.find(e => e.type === 'window');
console.log('Sample window:', window1.id, 'Host:', window1.host, 'Width:', window1.width, 'Height:', window1.height, 'Sill:', window1.sill);
if (window1.width !== 1800 || window1.height !== 1500 || window1.sill !== 900) throw new Error('Window dimensions mismatch');

const slab1 = model.elements.find(e => e.type === 'slab');
console.log('Sample slab:', slab1.id, 'Points count:', slab1.points.length, 'Thickness:', slab1.thickness);
if (slab1.points.length !== 4) throw new Error('Slab points count mismatch');

const roof1 = model.elements.find(e => e.type === 'roof');
console.log('Sample roof:', roof1.id, 'Points count:', roof1.points.length, 'Pitch:', roof1.pitch, 'Framing:', roof1.roofFraming.system);
if (roof1.pitch < 15 || roof1.roofFraming.system !== 'trusses') throw new Error('Roof configuration mismatch');

// 3. Test the same wall generator used by the browser before aggregating IFC takeoff.
// This previously skipped wall generation in Node and misleadingly reported zero members.
const framingContext = createFramingContext(model);
const framingResults = autoGenerateFramingPipeline(model, {
  generateWallFraming: framingContext.generateWallFraming,
});
console.log('Framing pipeline takeoff:', framingResults.takeoff);
if (framingResults.wallFramingCount !== 4) throw new Error('Wall framing count mismatch');
if (framingResults.wallFramingGeneratedCount !== 4) throw new Error(`Expected framing generation on all 4 walls, got ${framingResults.wallFramingGeneratedCount}`);
if (framingResults.wallLayouts.length !== 4 || framingResults.wallLayouts.some(layout => layout.status !== 'generated' || layout.memberCount <= 0)) {
  throw new Error('Every imported wall must have a generated member layout and an auditable member count');
}
if (framingResults.wallFramingIssueCount !== 0) throw new Error(`Expected no sample wall framing issues, got ${framingResults.wallFramingIssueCount}`);
if (framingResults.takeoff.totalMembers <= 0) throw new Error('Wall framing takeoff must contain generated members');
if (framingResults.takeoff.topPlates <= 0 || framingResults.takeoff.bottomPlates <= 0) throw new Error('Wall plate takeoff is incomplete');
if (framingResults.takeoff.headers < 1) throw new Error('Expected a door/window header in the generated wall framing takeoff');
if (framingResults.takeoff.wallIssues > 0) throw new Error(`IFC wall framing produced ${framingResults.takeoff.wallIssues} issue(s)`);
if (framingResults.floorJoistsCount < 1) throw new Error('Floor joists count mismatch');
if (framingResults.roofTrussesCount < 1) throw new Error('Roof trusses count mismatch');

// Missing browser generator must be explicit and must not masquerade as a zero-member successful takeoff.
const withoutGenerator = autoGenerateFramingPipeline(structuredClone(model), {});
if (withoutGenerator.wallLayouts.length !== 4 || withoutGenerator.wallLayouts.some(layout => layout.status !== 'not-generated')) {
  throw new Error('Missing wall generator must be visible in the audit status for every wall');
}
if (withoutGenerator.wallFramingIssueCount < 4 || withoutGenerator.messages.length === 0) {
  throw new Error('Missing wall generator must emit actionable warnings instead of silent zero takeoff');
}

console.log('✓ ArchiCAD IFC import, opening framing, member takeoff, missing-generator warning, floor and roof pipeline tests passed successfully!');

