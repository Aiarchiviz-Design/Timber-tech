# Report exports: PDF instead of CSV (wall, floor, roof truss)

Shared writer: `pdf-writer.js` (ES module, also `window.CadPdf` for the classic scripts). It turns report tables, including the CSV the app already builds, into landscape PDF: wrapped cells, sized columns, headers repeated on each page, title block and page numbers. `index.html` loads it as a module.

## Converted to PDF on the live page
- Export menu > Timber framing cut list (`timber-framing-cut-list.pdf`), also the publish menu cut list.
- Export menu > Element schedule (walls, floors, roofs) (`courtyard-house-schedule.pdf`).
- Truss optimization review (`atelier-truss-optimization-review.pdf`).

## Converted in code, not on the live page
`advanced-ui.js` has PDF export calls for the EWP floor reports, whole-building takeoff, load path, wall panels, floor framing and load alignment. That file is not loaded by `index.html` (it is imported only by `assembly-app.js`, which nothing loads), and it imports names that do not exist in the source (`WEB_STYLES`, `shapeWeb`, `parametricRoof`, `dxfSegments`, `exportDXF`). These buttons will not appear until that chain is repaired.

## Still CSV (building-level, outside the wall/floor/truss scope)
Job-wide BOM, building QA, hardware schedule, installation sequence, change impact, support nodes, regeneration history, documentation objects, sheet index.

## Not wired to any button
`wallScheduleCSV`, `wallQACSV`, `takeoffSummaryCSV`, `cutListCSV`, `takeoffByTrussCSV`, `verifiedReactionsCSV`. They have no export control, so they have no PDF export either.

Tests: `node test-wall-floor-truss-pdf.mjs` (7 tests).
