import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const app = fs.readFileSync(new URL('./app.js', import.meta.url), 'utf8');
const framing = fs.readFileSync(new URL('./framing.js', import.meta.url), 'utf8');
const packageJs = fs.readFileSync(new URL('./wall-panel-package.js', import.meta.url), 'utf8');
assert(app.includes("choice('Wall height preset','wallHeightPreset'"));
assert(app.includes("choice('Head height preset','openingHeadPreset'"));
assert(app.includes("key==='windowHeadPreset'||key==='doorHeadPreset'"));
assert(framing.includes("choice('Auto-size header depth','framing.autoHeaderDepth'"));
assert(framing.includes('wallOpeningHeadPresetControl'));
console.log('  ok - editable wall height and per-opening header/head-level preset controls are present');

globalThis.window = globalThis;
(0, eval)(framing);
const testWall = {id:'W-height',type:'wall',material:'Timber',thickness:140,a:{x:0,y:0},b:{x:4000,y:0},framing:{enabled:true,studWidth:45,studDepth:140,spacing:400,plateThickness:45,topPlates:2,bottomPlates:1,headerDepth:190,headerPlies:2,autoHeaderDepth:true}};
window.setWallProperty(testWall,'framing.autoHeaderDepth','false');
assert.equal(testWall.framing.autoHeaderDepth,false);
window.setWallProperty(testWall,'framing.headerDepth',240);
assert.equal(testWall.framing.headerDepth,240);
window.setWallProperty(testWall,'framing.autoHeaderDepth','true');
assert.equal(testWall.framing.autoHeaderDepth,true);
console.log('  ok - auto/fixed header-depth mode changes are stored on the wall framing settings');

// Build a sample wall panel PDF and assert the plan strip and dimensioned elevation render.
globalThis.window = globalThis;
globalThis.document = undefined;
(0, eval)(packageJs);
const api = window.wallPanelPackageInternals;
const wall = { id:'W1', type:'wall', story:'s0', layer:'Exterior Walls', isExternal:true, a:{x:0,y:0}, b:{x:4200,y:0}, height:2700, thickness:140 };
const window1 = { id:'WIN1', type:'window', host:'W1', type:'window', offset:1400, width:1200, height:1200, sill:800 };
const door1 = { id:'D1', type:'door', host:'W1', offset:3300, width:850, height:2100, sill:0 };
const model = { name:'Height Options Test', stories:[{id:'s0',name:'Ground'}], elements:[wall,window1,door1] };
const framingFn = () => ({ members:[
  {id:'bp',type:'Bottom plate',section:'45 x 140',length:4200,x0:0,x1:4200,z0:0,z1:45},
  {id:'tp',type:'Top plate',section:'45 x 140',length:4200,x0:0,x1:4200,z0:2610,z1:2700},
  {id:'s1',type:'Common stud',section:'45 x 140',length:2700,x0:0,x1:45,z0:0,z1:2700},
  {id:'s2',type:'King stud',section:'45 x 140',length:2700,x0:800,x1:845,z0:0,z1:2700},
  {id:'h1',type:'Header',section:'90 x 190',length:1300,x0:750,x1:2050,z0:2000,z1:2190,headerDepth:190},
  {id:'s3',type:'Common stud',section:'45 x 140',length:2700,x0:4155,x1:4200,z0:0,z1:2700},
] });
const built = api.buildPackage(model, framingFn, () => null, { exteriorOsbEnabled:true });
const pdf = api.buildPdf(built.pages);
assert(pdf.includes('WALL PANEL ELEVATION + PLAN'));
assert(pdf.includes('WALL PLAN / TOP-PLATE & STUD LAYOUT'));
assert(pdf.includes('4200 mm OVERALL PANEL LENGTH'));
assert(pdf.includes('Wall thickness 140 mm'));
console.log('  ok - panel PDF includes the wall elevation and a dimensioned plan view beneath it');
