import fs from 'fs';
import vm from 'vm';
import assert from 'assert';

const nodes = new Map(), ctx = new Proxy({}, { get: () => () => {} });
function node(s) {
  if (!nodes.has(s)) nodes.set(s, {
    style: {}, dataset: {}, value: "0",
    classList: { add(){}, remove(){}, toggle(){ return false; }, contains(){ return false; } },
    querySelectorAll: () => [], querySelector: () => null, insertAdjacentHTML(){},
    addEventListener(){}, getContext: () => ctx, getBoundingClientRect: () => ({ width: 0, height: 0 }),
    children: [], close(){}, showModal(){}, click(){}
  });
  return nodes.get(s);
}
const box = {
  document: { body: node("body"), querySelector: node, querySelectorAll: () => [], addEventListener(){}, createElement: node },
  ResizeObserver: class { observe(){} },
  devicePixelRatio: 1, console, setTimeout, clearTimeout, URL, Blob, Math, Number, String, Array, Object, Set, Map, Infinity, NaN, assert
};
box.window = box;
vm.createContext(box);

for (const f of ["joins.js","framing.js","camera.js","advanced.js","trim.js","editing.js","roof-footprint.js","roof.js","truss-joints.js","hip-trusses.js","roof-framing.js","app.js"]) {
  vm.runInContext(fs.readFileSync(f, "utf8"), box);
}

const run = s => vm.runInContext(s, box);
run("render=()=>{};properties=()=>{};navigator=()=>{};toast=()=>{};let sampleProject=clone(model);");

// 1. Verify courtyard house with asymmetric wings
run(`
var roof = {
  id: "R-COURTYARD",
  type: "roof",
  story: "s0",
  layer: "Structure",
  points: [
    { x: 0, y: 0 },
    { x: 13000, y: 0 },
    { x: 13000, y: 5700 },
    { x: 8500, y: 5700 },
    { x: 8500, y: 3400 },
    { x: 4700, y: 3400 },
    { x: 4700, y: 9000 },
    { x: 0, y: 9000 }
  ],
  pitch: 25,
  height: 3000,
  overhang: 609.6,
  thickness: 200,
  roofType: "hip",
  roofFraming: { system: "trusses", spacing: 600, hipSetback: 1828.8, wingDirection: "branch" }
};
var framing = generateRoofFraming(roof);
var assemblies = roofPlanAssemblies(framing.members);

const hc05 = assemblies.find(a => a.tag === "HC-05");
const hc06 = assemblies.find(a => a.tag === "HC-06");
const hc03 = assemblies.find(a => a.tag === "HC-03");
const hc04 = assemblies.find(a => a.tag === "HC-04");

function angleDeg(a) {
  const dx = a.b.x - a.a.x, dy = a.b.y - a.a.y;
  return Math.atan2(Math.abs(dy), Math.abs(dx)) * 180 / Math.PI;
}

// Angles must be 45 degrees, matching the roof hip
assert.strictEqual(Math.round(angleDeg(hc03)), 45, "HC-03 angle in left wing must be 45 deg");
assert.strictEqual(Math.round(angleDeg(hc04)), 45, "HC-04 angle in left wing must be 45 deg");
assert.strictEqual(Math.round(angleDeg(hc05)), 45, "HC-05 angle in right wing must be 45 deg");
assert.strictEqual(Math.round(angleDeg(hc06)), 45, "HC-06 angle in right wing must be 45 deg");

// HC-05 and HC-06 must start at the exterior eave corners
assert(Math.abs(hc05.a.x - 13609.6) < 1, "HC-05 start x matches eave corner 13609.6");
assert(Math.abs(hc05.a.y - 6309.6) < 1, "HC-05 start y matches eave corner 6309.6");
assert(Math.abs(hc06.a.x - 7890.4) < 1, "HC-06 start x matches eave corner 7890.4");
assert(Math.abs(hc06.a.y - 6309.6) < 1, "HC-06 start y matches eave corner 6309.6");

console.log("PASS: Courtyard asymmetric branch wing hip truss angles & corner placement verified.");
`);
