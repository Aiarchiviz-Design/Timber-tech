import React from 'react';
import { createRoot, Root } from 'react-dom/client';
import App from './App';
import { TrussElevationView } from './components/TrussElevationView';
import { TrussStructure, TimberSection } from './types/trussElevation';
import { createSampleFinkTruss, createTR003Truss, recalculateTrussMembers } from './services/trussStressEngine';
import './index.css';

// Mount standalone app if #root element is present
const rootEl = document.getElementById('root');
if (rootEl) {
  createRoot(rootEl).render(<App />);
}

// Global bridge for BIM CAD interface integration
declare global {
  interface Window {
    openTrussElevationModal: (initialTruss?: TrussStructure) => void;
    mountTrussElevationViewTab: (container: HTMLElement) => void;
    renderTrussElevationView: (container: HTMLElement, truss: TrussStructure, onUpdate?: (memberId: string, section: TimberSection) => void) => Root;
    createSampleFinkTruss: () => TrussStructure;
    createTR003Truss: () => TrussStructure;
  }
}

let activeModalRoot: Root | null = null;
let activeTabRoot: Root | null = null;

function ModalTrussWrapper({ initialTruss }: { initialTruss?: TrussStructure }) {
  const [truss, setTruss] = React.useState<TrussStructure>(initialTruss || createTR003Truss());

  const handleUpdateMember = (memberId: string, section: TimberSection) => {
    setTruss(prev => {
      const updated = recalculateTrussMembers({
        ...prev,
        members: prev.members.map(m => m.id === memberId ? { ...m, section } : m),
      });
      return updated;
    });
  };

  return (
    <div className="w-full max-w-6xl mx-auto h-[80vh]">
      <TrussElevationView initialTruss={truss} onUpdateMemberSection={handleUpdateMember} />
    </div>
  );
}

window.createSampleFinkTruss = createSampleFinkTruss;
window.createTR003Truss = createTR003Truss;

window.openTrussElevationModal = function(initialTruss?: TrussStructure) {
  const modal = document.getElementById('modal') as HTMLDialogElement | null;
  const title = document.getElementById('modal-title');
  const body = document.getElementById('modal-body');

  if (title) title.textContent = '2D Roof Truss Elevation & Stress Inspector';
  if (body) {
    body.innerHTML = '<div id="truss-elevation-modal-mount" class="w-full h-full"></div>';
    const mountEl = document.getElementById('truss-elevation-modal-mount');
    if (mountEl) {
      if (activeModalRoot) {
        try { activeModalRoot.unmount(); } catch (_) {}
      }
      activeModalRoot = createRoot(mountEl);
      activeModalRoot.render(<ModalTrussWrapper initialTruss={initialTruss} />);
    }
  }

  if (modal && typeof modal.showModal === 'function') {
    modal.showModal();
  }
};

window.mountTrussElevationViewTab = function(container: HTMLElement) {
  if (!activeTabRoot) {
    activeTabRoot = createRoot(container);
  }
  activeTabRoot.render(<TrussElevationView />);
};

window.renderTrussElevationView = function(
  container: HTMLElement,
  truss: TrussStructure,
  onUpdate?: (memberId: string, section: TimberSection) => void
) {
  const root = createRoot(container);
  root.render(<TrussElevationView initialTruss={truss} onUpdateMemberSection={onUpdate} />);
  return root;
};
