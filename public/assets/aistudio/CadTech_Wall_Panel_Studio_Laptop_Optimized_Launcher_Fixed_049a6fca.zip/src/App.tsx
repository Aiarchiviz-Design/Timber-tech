/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { TrussElevationView } from './components/TrussElevationView';
import { TrussStructure, TimberSection, TimberGrade } from './types/trussElevation';
import {
  STANDARD_TIMBER_GRADES,
  COMMON_WOOD_SECTIONS,
  createSampleFinkTruss,
  recalculateTrussMembers,
  getSectionSuggestions,
  create20TrussesCatalog,
} from './services/trussStressEngine';

// Predefined structural roof trusses
function createSampleHoweTruss(): TrussStructure {
  const span = 9.75; // 32'-0"
  const pitchDeg = 22.6; // 5/12 pitch
  const height = (span / 2) * Math.tan((pitchDeg * Math.PI) / 180);
  const sec2x6 = COMMON_WOOD_SECTIONS[1];
  const sec2x4 = COMMON_WOOD_SECTIONS[0];
  const grade = STANDARD_TIMBER_GRADES.NO2_SPF;

  const nodes = [
    { id: 1, x: 0, y: 0, type: 'heel_left' },
    { id: 2, x: span * 0.25, y: 0, type: 'bottom_chord_panel' },
    { id: 3, x: span * 0.5, y: 0, type: 'bottom_chord_center' },
    { id: 4, x: span * 0.75, y: 0, type: 'bottom_chord_panel' },
    { id: 5, x: span, y: 0, type: 'heel_right' },
    { id: 6, x: span * 0.25, y: height * 0.5, type: 'top_chord_panel' },
    { id: 7, x: span * 0.5, y: height, type: 'apex_ridge' },
    { id: 8, x: span * 0.75, y: height * 0.5, type: 'top_chord_panel' },
  ];

  const members = [
    {
      id: 'TC-1', startNodeId: 1, endNodeId: 6, type: 'top_chord' as const,
      length: Math.hypot(nodes[5].x - nodes[0].x, nodes[5].y - nodes[0].y),
      axialForce: -22.5, axialStress: 4.23, allowableStress: 12.8,
      slendernessRatio: 52, capacityKN: 68.0, utilization: 0.76, status: 'SAFE' as const, governingCheck: 'Combined' as const,
      section: sec2x6, grade,
    },
    {
      id: 'TC-2', startNodeId: 6, endNodeId: 7, type: 'top_chord' as const,
      length: Math.hypot(nodes[6].x - nodes[5].x, nodes[6].y - nodes[5].y),
      axialForce: -18.2, axialStress: 3.42, allowableStress: 12.8,
      slendernessRatio: 52, capacityKN: 68.0, utilization: 0.62, status: 'SAFE' as const, governingCheck: 'Combined' as const,
      section: sec2x6, grade,
    },
    {
      id: 'TC-3', startNodeId: 7, endNodeId: 8, type: 'top_chord' as const,
      length: Math.hypot(nodes[7].x - nodes[6].x, nodes[7].y - nodes[6].y),
      axialForce: -18.2, axialStress: 3.42, allowableStress: 12.8,
      slendernessRatio: 52, capacityKN: 68.0, utilization: 0.62, status: 'SAFE' as const, governingCheck: 'Combined' as const,
      section: sec2x6, grade,
    },
    {
      id: 'TC-4', startNodeId: 8, endNodeId: 5, type: 'top_chord' as const,
      length: Math.hypot(nodes[4].x - nodes[7].x, nodes[4].y - nodes[7].y),
      axialForce: -22.5, axialStress: 4.23, allowableStress: 12.8,
      slendernessRatio: 52, capacityKN: 68.0, utilization: 0.76, status: 'SAFE' as const, governingCheck: 'Combined' as const,
      section: sec2x6, grade,
    },
    {
      id: 'BC-1', startNodeId: 1, endNodeId: 2, type: 'bottom_chord' as const,
      length: nodes[1].x - nodes[0].x,
      axialForce: 20.8, axialStress: 3.91, allowableStress: 16.6,
      slendernessRatio: 86, capacityKN: 88.3, utilization: 0.48, status: 'SAFE' as const, governingCheck: 'Tension' as const,
      section: sec2x6, grade,
    },
    {
      id: 'BC-2', startNodeId: 2, endNodeId: 3, type: 'bottom_chord' as const,
      length: nodes[2].x - nodes[1].x,
      axialForce: 16.4, axialStress: 3.08, allowableStress: 16.6,
      slendernessRatio: 43, capacityKN: 88.3, utilization: 0.41, status: 'SAFE' as const, governingCheck: 'Tension' as const,
      section: sec2x6, grade,
    },
    {
      id: 'BC-3', startNodeId: 3, endNodeId: 4, type: 'bottom_chord' as const,
      length: nodes[3].x - nodes[2].x,
      axialForce: 16.4, axialStress: 3.08, allowableStress: 16.6,
      slendernessRatio: 43, capacityKN: 88.3, utilization: 0.41, status: 'SAFE' as const, governingCheck: 'Tension' as const,
      section: sec2x6, grade,
    },
    {
      id: 'BC-4', startNodeId: 4, endNodeId: 5, type: 'bottom_chord' as const,
      length: nodes[4].x - nodes[3].x,
      axialForce: 20.8, axialStress: 3.91, allowableStress: 16.6,
      slendernessRatio: 86, capacityKN: 88.3, utilization: 0.48, status: 'SAFE' as const, governingCheck: 'Tension' as const,
      section: sec2x6, grade,
    },
    {
      id: 'W-V1', startNodeId: 2, endNodeId: 6, type: 'web_strut' as const,
      length: nodes[5].y - nodes[1].y,
      axialForce: -4.8, axialStress: 1.42, allowableStress: 11.2,
      slendernessRatio: 54, capacityKN: 37.8, utilization: 0.38, status: 'SAFE' as const, governingCheck: 'Compression' as const,
      section: sec2x4, grade,
    },
    {
      id: 'W-V2', startNodeId: 3, endNodeId: 7, type: 'king_post' as const,
      length: nodes[6].y - nodes[2].y,
      axialForce: 6.2, axialStress: 1.83, allowableStress: 16.6,
      slendernessRatio: 68, capacityKN: 56.1, utilization: 0.33, status: 'SAFE' as const, governingCheck: 'Tension' as const,
      section: sec2x4, grade,
    },
    {
      id: 'W-V3', startNodeId: 4, endNodeId: 8, type: 'web_strut' as const,
      length: nodes[7].y - nodes[3].y,
      axialForce: -4.8, axialStress: 1.42, allowableStress: 11.2,
      slendernessRatio: 54, capacityKN: 37.8, utilization: 0.38, status: 'SAFE' as const, governingCheck: 'Compression' as const,
      section: sec2x4, grade,
    },
    {
      id: 'W-D1', startNodeId: 1, endNodeId: 6, type: 'web_strut' as const,
      length: Math.hypot(nodes[5].x - nodes[0].x, nodes[5].y - nodes[0].y),
      axialForce: 7.4, axialStress: 2.19, allowableStress: 16.6,
      slendernessRatio: 72, capacityKN: 56.1, utilization: 0.36, status: 'SAFE' as const, governingCheck: 'Tension' as const,
      section: sec2x4, grade,
    },
    {
      id: 'W-D2', startNodeId: 3, endNodeId: 6, type: 'web_strut' as const,
      length: Math.hypot(nodes[5].x - nodes[2].x, nodes[5].y - nodes[2].y),
      axialForce: -7.2, axialStress: 2.13, allowableStress: 10.2,
      slendernessRatio: 74, capacityKN: 34.5, utilization: 0.51, status: 'SAFE' as const, governingCheck: 'Compression' as const,
      section: sec2x4, grade,
    },
    {
      id: 'W-D3', startNodeId: 3, endNodeId: 8, type: 'web_strut' as const,
      length: Math.hypot(nodes[7].x - nodes[2].x, nodes[7].y - nodes[2].y),
      axialForce: -7.2, axialStress: 2.13, allowableStress: 10.2,
      slendernessRatio: 74, capacityKN: 34.5, utilization: 0.51, status: 'SAFE' as const, governingCheck: 'Compression' as const,
      section: sec2x4, grade,
    },
    {
      id: 'W-D4', startNodeId: 5, endNodeId: 8, type: 'web_strut' as const,
      length: Math.hypot(nodes[4].x - nodes[7].x, nodes[4].y - nodes[7].y),
      axialForce: 7.4, axialStress: 2.19, allowableStress: 16.6,
      slendernessRatio: 72, capacityKN: 56.1, utilization: 0.36, status: 'SAFE' as const, governingCheck: 'Tension' as const,
      section: sec2x4, grade,
    },
  ];

  return recalculateTrussMembers({
    id: 'TR-002',
    tag: 'TR-002',
    name: 'Howe Roof Truss (32\'-0" Span, 5/12 Pitch)',
    type: 'howe',
    role: 'Common',
    span,
    height,
    pitch: pitchDeg,
    overhang: 0.45,
    spacing: 0.6,
    baseElevation: 2.7,
    nodes,
    members,
    maxUtilization: 0.76,
    maxDeflection: 7.1,
    allowableDeflection: 27.0,
    reactionLeft: 14.8,
    reactionRight: 14.8,
    integrityStatus: 'PASS',
  });
}

function createSampleGirderTruss(): TrussStructure {
  const span = 8.53; // 28'-0"
  const pitchDeg = 20.89; // 4.58/12 pitch
  const height = (span / 2) * Math.tan((pitchDeg * Math.PI) / 180);
  const sec3ply2x8 = COMMON_WOOD_SECTIONS[8]; // 3-2x8 (3-ply girder)
  const sec2ply2x6 = COMMON_WOOD_SECTIONS[5]; // 2-2x6
  const grade = STANDARD_TIMBER_GRADES.DFL_NO1;

  const nodes = [
    { id: 1, x: 0, y: 0, type: 'heel_left' },
    { id: 2, x: span * 0.333, y: 0, type: 'girder_jack_carrier_1' },
    { id: 3, x: span * 0.5, y: 0, type: 'girder_center' },
    { id: 4, x: span * 0.667, y: 0, type: 'girder_jack_carrier_2' },
    { id: 5, x: span, y: 0, type: 'heel_right' },
    { id: 6, x: span * 0.25, y: height * 0.5, type: 'top_chord_panel' },
    { id: 7, x: span * 0.5, y: height, type: 'apex_ridge' },
    { id: 8, x: span * 0.75, y: height * 0.5, type: 'top_chord_panel' },
  ];

  const members = [
    {
      id: 'GTC-1', startNodeId: 1, endNodeId: 6, type: 'top_chord' as const,
      length: Math.hypot(nodes[5].x - nodes[0].x, nodes[5].y - nodes[0].y),
      axialForce: -46.2, axialStress: 2.20, allowableStress: 14.5,
      slendernessRatio: 42, capacityKN: 304.0, utilization: 0.52, status: 'SAFE' as const, governingCheck: 'Combined' as const,
      section: sec3ply2x8, grade,
    },
    {
      id: 'GTC-2', startNodeId: 6, endNodeId: 7, type: 'top_chord' as const,
      length: Math.hypot(nodes[6].x - nodes[5].x, nodes[6].y - nodes[5].y),
      axialForce: -38.5, axialStress: 1.83, allowableStress: 14.5,
      slendernessRatio: 42, capacityKN: 304.0, utilization: 0.44, status: 'SAFE' as const, governingCheck: 'Combined' as const,
      section: sec3ply2x8, grade,
    },
    {
      id: 'GTC-3', startNodeId: 7, endNodeId: 8, type: 'top_chord' as const,
      length: Math.hypot(nodes[7].x - nodes[6].x, nodes[7].y - nodes[6].y),
      axialForce: -38.5, axialStress: 1.83, allowableStress: 14.5,
      slendernessRatio: 42, capacityKN: 304.0, utilization: 0.44, status: 'SAFE' as const, governingCheck: 'Combined' as const,
      section: sec3ply2x8, grade,
    },
    {
      id: 'GTC-4', startNodeId: 8, endNodeId: 5, type: 'top_chord' as const,
      length: Math.hypot(nodes[4].x - nodes[7].x, nodes[4].y - nodes[7].y),
      axialForce: -46.2, axialStress: 2.20, allowableStress: 14.5,
      slendernessRatio: 42, capacityKN: 304.0, utilization: 0.52, status: 'SAFE' as const, governingCheck: 'Combined' as const,
      section: sec3ply2x8, grade,
    },
    {
      id: 'GBC-1', startNodeId: 1, endNodeId: 2, type: 'bottom_chord' as const,
      length: nodes[1].x - nodes[0].x,
      axialForce: 42.4, axialStress: 2.02, allowableStress: 18.4,
      slendernessRatio: 78, capacityKN: 386.0, utilization: 0.38, status: 'SAFE' as const, governingCheck: 'Tension' as const,
      section: sec3ply2x8, grade,
    },
    {
      id: 'GBC-2', startNodeId: 2, endNodeId: 3, type: 'bottom_chord' as const,
      length: nodes[2].x - nodes[1].x,
      axialForce: 36.8, axialStress: 1.75, allowableStress: 18.4,
      slendernessRatio: 39, capacityKN: 386.0, utilization: 0.33, status: 'SAFE' as const, governingCheck: 'Tension' as const,
      section: sec3ply2x8, grade,
    },
    {
      id: 'GBC-3', startNodeId: 3, endNodeId: 4, type: 'bottom_chord' as const,
      length: nodes[3].x - nodes[2].x,
      axialForce: 36.8, axialStress: 1.75, allowableStress: 18.4,
      slendernessRatio: 39, capacityKN: 386.0, utilization: 0.33, status: 'SAFE' as const, governingCheck: 'Tension' as const,
      section: sec3ply2x8, grade,
    },
    {
      id: 'GBC-4', startNodeId: 4, endNodeId: 5, type: 'bottom_chord' as const,
      length: nodes[4].x - nodes[3].x,
      axialForce: 42.4, axialStress: 2.02, allowableStress: 18.4,
      slendernessRatio: 78, capacityKN: 386.0, utilization: 0.38, status: 'SAFE' as const, governingCheck: 'Tension' as const,
      section: sec3ply2x8, grade,
    },
    {
      id: 'GW-1', startNodeId: 2, endNodeId: 6, type: 'web_strut' as const,
      length: Math.hypot(nodes[5].x - nodes[1].x, nodes[5].y - nodes[1].y),
      axialForce: -14.6, axialStress: 1.37, allowableStress: 12.5,
      slendernessRatio: 52, capacityKN: 133.0, utilization: 0.41, status: 'SAFE' as const, governingCheck: 'Compression' as const,
      section: sec2ply2x6, grade,
    },
    {
      id: 'GW-2', startNodeId: 3, endNodeId: 6, type: 'web_tie' as const,
      length: Math.hypot(nodes[5].x - nodes[2].x, nodes[5].y - nodes[2].y),
      axialForce: 19.8, axialStress: 1.86, allowableStress: 18.4,
      slendernessRatio: 74, capacityKN: 195.8, utilization: 0.36, status: 'SAFE' as const, governingCheck: 'Tension' as const,
      section: sec2ply2x6, grade,
    },
    {
      id: 'GW-3', startNodeId: 3, endNodeId: 8, type: 'web_tie' as const,
      length: Math.hypot(nodes[7].x - nodes[2].x, nodes[7].y - nodes[2].y),
      axialForce: 19.8, axialStress: 1.86, allowableStress: 18.4,
      slendernessRatio: 74, capacityKN: 195.8, utilization: 0.36, status: 'SAFE' as const, governingCheck: 'Tension' as const,
      section: sec2ply2x6, grade,
    },
    {
      id: 'GW-4', startNodeId: 4, endNodeId: 8, type: 'web_strut' as const,
      length: Math.hypot(nodes[7].x - nodes[3].x, nodes[7].y - nodes[3].y),
      axialForce: -14.6, axialStress: 1.37, allowableStress: 12.5,
      slendernessRatio: 52, capacityKN: 133.0, utilization: 0.41, status: 'SAFE' as const, governingCheck: 'Compression' as const,
      section: sec2ply2x6, grade,
    },
  ];

  return recalculateTrussMembers({
    id: 'GIRDER-01',
    tag: 'GIRDER-01',
    name: 'Heavy Duty Hip Girder Truss (3-Ply 2x8 Chords)',
    type: 'hip_girder',
    role: 'Girder',
    span,
    height,
    pitch: pitchDeg,
    overhang: 0.45,
    spacing: 0.6,
    baseElevation: 2.7,
    nodes,
    members,
    maxUtilization: 0.52,
    maxDeflection: 5.4,
    allowableDeflection: 23.7,
    reactionLeft: 34.2,
    reactionRight: 34.2,
    integrityStatus: 'PASS',
  });
}

export default function App() {
  const [trussCatalog, setTrussCatalog] = useState<{ [id: string]: TrussStructure }>(() => create20TrussesCatalog());
  const [activeTrussId, setActiveTrussId] = useState<string>('TR-01');
  const [selectedGradeId, setSelectedGradeId] = useState<string>('NO2_SPF');

  const currentTruss = trussCatalog[activeTrussId] || Object.values(trussCatalog)[0];

  const handleUpdateMember = (memberId: string, section: TimberSection) => {
    setTrussCatalog(prev => {
      const target = prev[activeTrussId] || Object.values(prev)[0];
      if (!target) return prev;
      const updatedTruss = recalculateTrussMembers({
        ...target,
        members: target.members.map(m => (m.id === memberId ? { ...m, section } : m)),
      });
      return { ...prev, [target.tag]: updatedTruss };
    });
  };

  const handleGradeChange = (gradeKey: string) => {
    setSelectedGradeId(gradeKey);
    const newGrade = STANDARD_TIMBER_GRADES[gradeKey];
    if (!newGrade) return;

    setTrussCatalog(prev => {
      const target = prev[activeTrussId] || Object.values(prev)[0];
      if (!target) return prev;
      const updatedTruss = recalculateTrussMembers({
        ...target,
        members: target.members.map(m => ({ ...m, grade: newGrade })),
      });
      return { ...prev, [target.tag]: updatedTruss };
    });
  };

  const handleOptimizeAll = () => {
    setTrussCatalog(prev => {
      const nextCatalog: { [id: string]: TrussStructure } = {};
      for (const [id, target] of Object.entries(prev)) {
        const optimizedMembers = target.members.map(m => {
          const suggestions = getSectionSuggestions(m, target);
          const optimal = suggestions.find(s => s.type === 'OPTIMAL') || suggestions.find(s => s.type === 'PASSING') || suggestions[0];
          return { ...m, section: optimal.section };
        });
        nextCatalog[id] = recalculateTrussMembers({ ...target, members: optimizedMembers });
      }
      return nextCatalog;
    });
  };

  return (
    <div className="min-h-screen bg-slate-100/70 p-4 md:p-6 text-slate-800 font-sans">
      <div className="max-w-7xl mx-auto space-y-4">
        {/* Top Control Bar */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-teal-600 text-white font-black flex items-center justify-center text-sm shadow-xs">
              TR
            </div>
            <div>
              <h1 className="text-base font-bold text-slate-900 leading-tight">
                2D Roof Truss Elevation & Stress Inspector
              </h1>
              <p className="text-xs text-slate-500">
                ASD / NDS / Eurocode 5 column stability, combined bending, and Gang-Nail plate connection engine
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            {/* Truss Selector */}
            <label className="text-xs font-semibold text-slate-600 flex items-center gap-1.5">
              <span>Truss:</span>
              <select
                value={activeTrussId}
                onChange={e => setActiveTrussId(e.target.value)}
                className="text-xs font-medium px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800 cursor-pointer shadow-2xs max-w-[200px]"
              >
                {Object.values(trussCatalog).map(t => (
                  <option key={t.tag} value={t.tag}>
                    {t.tag} — {t.name.split('(')[0].trim()} ({t.span.toFixed(1)}m span)
                  </option>
                ))}
              </select>
            </label>

            {/* Timber Grade */}
            <label className="text-xs font-semibold text-slate-600 flex items-center gap-1.5">
              <span>Grade:</span>
              <select
                value={selectedGradeId}
                onChange={e => handleGradeChange(e.target.value)}
                className="text-xs font-medium px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white text-slate-800 cursor-pointer shadow-2xs"
              >
                <option value="NO2_SPF">#2 SPF / CLS (Standard)</option>
                <option value="DFL_NO1">Douglas Fir-Larch #1 (Heavy Duty)</option>
                <option value="C24">C24 Structural Timber (EN 338)</option>
              </select>
            </label>

            <button
              type="button"
              onClick={handleOptimizeAll}
              className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold cursor-pointer transition-colors shadow-xs flex items-center gap-1"
            >
              <span>⚡</span> Auto-Size All 20 Trusses
            </button>
          </div>
        </div>

        {/* Standalone React Truss Elevation Component */}
        <TrussElevationView
          key={currentTruss?.tag || activeTrussId}
          truss={currentTruss}
          trussesCatalog={trussCatalog}
          onUpdateMemberSection={handleUpdateMember}
        />

        {/* Structural Design Basis & Member Schedule Table */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Member Stress Schedule & ASD Capacity Register</h2>
              <p className="text-xs text-slate-500">
                Detailed member-by-member breakdown with Euler critical stress, column stability $C_p$, and in-plane bending interaction
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <span className="text-slate-600">
                Total Members: <b className="text-slate-900">{currentTruss.members.length}</b>
              </span>
              <span className="text-slate-600">
                Bearing $R_L$: <b className="text-emerald-700">{currentTruss.reactionLeft.toFixed(1)} kN</b>
              </span>
              <span className="text-slate-600">
                Bearing $R_R$: <b className="text-emerald-700">{currentTruss.reactionRight.toFixed(1)} kN</b>
              </span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                  <th className="py-2 px-3">Tag</th>
                  <th className="py-2 px-3">Type</th>
                  <th className="py-2 px-3">Wood Section</th>
                  <th className="py-2 px-3">Grade</th>
                  <th className="py-2 px-3">Length</th>
                  <th className="py-2 px-3">Axial Force N</th>
                  <th className="py-2 px-3">Actual Stress</th>
                  <th className="py-2 px-3">Capacity $N_{"{allow}"}$</th>
                  <th className="py-2 px-3">Slenderness $\lambda$</th>
                  <th className="py-2 px-3">Governing</th>
                  <th className="py-2 px-3">D/C Ratio</th>
                  <th className="py-2 px-3 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {currentTruss.members.map(m => {
                  const isSafe = m.utilization <= 1.0;
                  return (
                    <tr key={m.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-2 px-3 font-mono font-bold text-slate-900">{m.id}</td>
                      <td className="py-2 px-3 capitalize text-slate-600">{m.type.replace('_', ' ')}</td>
                      <td className="py-2 px-3 font-semibold text-slate-800">{m.section.nominalName}</td>
                      <td className="py-2 px-3 text-slate-500">{m.grade.species.split(' ')[0]}</td>
                      <td className="py-2 px-3 text-slate-700">{m.length.toFixed(2)} m</td>
                      <td className={`py-2 px-3 font-semibold ${m.axialForce >= 0 ? 'text-red-600' : 'text-blue-600'}`}>
                        {m.axialForce >= 0 ? `+${m.axialForce.toFixed(1)} kN (T)` : `${m.axialForce.toFixed(1)} kN (C)`}
                      </td>
                      <td className="py-2 px-3 text-slate-700">{m.axialStress.toFixed(2)} MPa</td>
                      <td className="py-2 px-3 font-medium text-slate-800">{m.capacityKN.toFixed(1)} kN</td>
                      <td className="py-2 px-3 font-mono text-slate-600">{m.slendernessRatio}</td>
                      <td className="py-2 px-3 text-slate-600">{m.governingCheck}</td>
                      <td className="py-2 px-3">
                        <div className="flex items-center gap-1.5">
                          <div className="w-16 bg-slate-200 h-2 rounded-full overflow-hidden">
                            <div
                              className={`h-full ${isSafe ? 'bg-emerald-500' : 'bg-rose-500'}`}
                              style={{ width: `${Math.min(100, m.utilization * 100)}%` }}
                            />
                          </div>
                          <span className="font-bold text-[11px] text-slate-700">
                            {(m.utilization * 100).toFixed(0)}%
                          </span>
                        </div>
                      </td>
                      <td className="py-2 px-3 text-right">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                            isSafe ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {isSafe ? 'PASS' : 'FAIL'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
