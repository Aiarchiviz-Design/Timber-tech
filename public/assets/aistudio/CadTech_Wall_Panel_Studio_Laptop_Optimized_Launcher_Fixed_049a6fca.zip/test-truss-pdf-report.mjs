// Unit test for Timber Truss PDF Report Generation
import { generateTrussPDFReport } from './report.js';

console.log('Testing Timber Truss PDF Engineering & Material Report Generation...');

const result = generateTrussPDFReport();

if (!result || !result.pdfBytes || result.pdfBytes.length === 0) {
  console.error('FAILED: PDF Report generation returned invalid result.');
  process.exit(1);
}

console.log('PDF Report generated successfully!');
console.log(`- Trusses Analyzed: ${result.assembly.trusses.length}`);
console.log(`- Jurisdiction: ${result.settings.jurisdiction}`);
console.log(`- Peak Utilization Ratio: ${result.assembly.trusses[0].analysis.ratio}`);

console.log('✓ Timber Truss PDF Engineering Report test passed successfully!');
