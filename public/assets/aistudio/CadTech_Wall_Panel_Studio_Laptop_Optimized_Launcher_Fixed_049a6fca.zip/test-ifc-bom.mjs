// Automated test for IFC Wall Framing Bill of Materials (BOM) Generator
import { parseSTEP, convertIFCToBIMModel } from './ifc-importer.js';
import { generateIFCWallBOM, ifcWallBOMToCSV, ifcWallBOMHTML } from './takeoff.js';

console.log('Testing IFC Wall Framing BOM Generator...');

// Sample IFC ISO-10303-21 STEP physical file containing walls, slab, roof, door, window
const sampleIFC = `ISO-10303-21;
HEADER;
FILE_DESCRIPTION(('ViewDefinition [CoordinationView_V2.0]'),'2;1');
FILE_NAME('ArchiCAD_Villa_BOM.ifc','2026-10-25T10:00:00',('Architect'),('Graphisoft'),'The BIM Server','ArchiCAD 28.0.0','');
FILE_SCHEMA(('IFC2X3'));
ENDSEC;
DATA;
#1=IFCPROJECT('1Project001',#2,'ArchiCAD Villa BOM',$,$,$,$,(#3),#4);
#2=IFCOWNERHISTORY(#5,#6,$,.ADDED.,$,$,$,$);
#3=IFCGEOMETRICREPRESENTATIONCONTEXT($,'Model',3,1.E-05,#7,$);
#4=IFCUNITASSIGNMENT((#8,#9,#10));
#5=IFCPERSON($,$,'User',$,$,$,$,$);
#6=IFCORGANIZATION($,'Graphisoft',$,$,$);
#7=IFCAXIS2PLACEMENT3D(#11,#12,#13);
#8=IFCSIUNIT(*,.LENGTHUNIT.,$,.METRE.);
#9=IFCSIUNIT(*,.PLANEANGLEUNIT.,$,.RADIAN.);
#10=IFCSIUNIT(*,.TIMEUNIT.,$,.SECOND.);
#11=IFCCARTESIANPOINT((0.,0.,0.));
#12=IFCDIRECTION((0.,0.,1.));
#13=IFCDIRECTION((1.,0.,0.));

#20=IFCSITE('1Site001',#2,'Site',$,$,#21,$,$,.ELEMENT.,$,$,$,$,$);
#21=IFCLOCALPLACEMENT($,#7);
#22=IFCBUILDING('1Bldg001',#2,'Building',$,$,#23,$,$,.ELEMENT.,$,$,$);
#23=IFCLOCALPLACEMENT(#21,#7);
#24=IFCBUILDINGSTOREY('1Story001',#2,'Ground Floor',$,$,#25,$,$,.ELEMENT.,0.);
#25=IFCLOCALPLACEMENT(#23,#7);

#30=IFCWALLSTANDARDCASE('1Wall001',#2,'Exterior Wall North',$,$,#31,#32,'Wall-N');
#31=IFCLOCALPLACEMENT(#25,#33);
#33=IFCAXIS2PLACEMENT3D(#34,#12,#13);
#34=IFCCARTESIANPOINT((0.,0.,0.));
#32=IFCPRODUCTDEFINITIONSHAPE($,$,(#35));
#35=IFCSHAPEREPRESENTATION(#3,'Axis','Curve2D',(#37));
#37=IFCPOLYLINE((#38,#39));
#38=IFCCARTESIANPOINT((0.,0.));
#39=IFCCARTESIANPOINT((12.,0.));

#50=IFCWALLSTANDARDCASE('1Wall002',#2,'Exterior Wall East',$,$,#51,#52,'Wall-E');
#51=IFCLOCALPLACEMENT(#25,#53);
#53=IFCAXIS2PLACEMENT3D(#54,#12,#55);
#54=IFCCARTESIANPOINT((12.,0.,0.));
#55=IFCDIRECTION((0.,1.,0.));
#52=IFCPRODUCTDEFINITIONSHAPE($,$,(#56));
#56=IFCSHAPEREPRESENTATION(#3,'Axis','Curve2D',(#57));
#57=IFCPOLYLINE((#58,#59));
#58=IFCCARTESIANPOINT((0.,0.));
#59=IFCCARTESIANPOINT((8.,0.));

#60=IFCWALLSTANDARDCASE('1Wall003',#2,'Exterior Wall South',$,$,#61,#62,'Wall-S');
#61=IFCLOCALPLACEMENT(#25,#63);
#63=IFCAXIS2PLACEMENT3D(#64,#12,#13);
#64=IFCCARTESIANPOINT((12.,8.,0.));
#62=IFCPRODUCTDEFINITIONSHAPE($,$,(#65));
#65=IFCSHAPEREPRESENTATION(#3,'Axis','Curve2D',(#66));
#66=IFCPOLYLINE((#67,#68));
#67=IFCCARTESIANPOINT((0.,0.));
#68=IFCCARTESIANPOINT((-12.,0.));

#70=IFCWALLSTANDARDCASE('1Wall004',#2,'Exterior Wall West',$,$,#71,#72,'Wall-W');
#71=IFCLOCALPLACEMENT(#25,#73);
#73=IFCAXIS2PLACEMENT3D(#74,#12,#55);
#74=IFCCARTESIANPOINT((0.,8.,0.));
#72=IFCPRODUCTDEFINITIONSHAPE($,$,(#75));
#75=IFCSHAPEREPRESENTATION(#3,'Axis','Curve2D',(#76));
#76=IFCPOLYLINE((#77,#78));
#77=IFCCARTESIANPOINT((0.,0.));
#78=IFCCARTESIANPOINT((0.,-8.));

#110=IFCOPENINGELEMENT('1Open001',#2,'Entrance Door Opening',$,$,#111,#112,'Open-01');
#111=IFCLOCALPLACEMENT(#31,#113);
#113=IFCAXIS2PLACEMENT3D(#114,#12,#13);
#114=IFCCARTESIANPOINT((3.0,0.,0.));
#112=IFCPRODUCTDEFINITIONSHAPE($,$,(#115));
#115=IFCSHAPEREPRESENTATION(#3,'Body','SweptSolid',(#116));
#116=IFCEXTRUDEDAREASOLID(#117,#7,#12,2.1);
#117=IFCRECTANGLEPROFILEDEF(.AREA.,'Door Profile',#,1.0,0.2);
#120=IFCRELVOIDSELEMENT('1Void001',#2,$,$,#30,#110);
#130=IFCDOOR('1Door001',#2,'Main Entrance Door 1000x2100',$,$,#111,$,'Door-01',2.1,1.0);
#140=IFCRELFILLSELEMENT('1Fill001',#2,$,$,#110,#130);

#150=IFCOPENINGELEMENT('1Open002',#2,'Wide Window Opening',$,$,#151,#152,'Open-02');
#151=IFCLOCALPLACEMENT(#61,#153);
#153=IFCAXIS2PLACEMENT3D(#154,#12,#13);
#154=IFCCARTESIANPOINT((6.0,0.,0.9));
#152=IFCPRODUCTDEFINITIONSHAPE($,$,(#155));
#155=IFCSHAPEREPRESENTATION(#3,'Body','SweptSolid',(#156));
#156=IFCEXTRUDEDAREASOLID(#157,#7,#12,1.5);
#157=IFCRECTANGLEPROFILEDEF(.AREA.,'Window Profile',#,1.8,0.2);
#160=IFCRELVOIDSELEMENT('1Void002',#2,$,$,#60,#150);
#170=IFCWINDOW('1Win001',#2,'Wide Window 1800x1500',$,$,#151,$,'Win-01',1.5,1.8);
#180=IFCRELFILLSELEMENT('1Fill002',#2,$,$,#150,#170);

ENDSEC;
END-ISO-10303-21;`;

// 1. Convert IFC to BIM Model
const { model, stats } = convertIFCToBIMModel(sampleIFC, 'ArchiCAD Sample Villa', { codeStandard: 'IRC_2021', spacing: 406.4 });
console.log(`Converted model with ${stats.wallsCount} walls and ${stats.openingsCount} openings.`);

// 2. Generate IFC Wall Framing BOM
const bom = generateIFCWallBOM(model);
console.log('Generated IFC Wall BOM Totals:', bom.totals);

// Verification assertions
if (bom.walls.length !== 4) throw new Error(`Expected 4 walls in BOM, got ${bom.walls.length}`);
if (bom.totals.wallsCount !== 4) throw new Error(`Expected totals.wallsCount === 4, got ${bom.totals.wallsCount}`);
if (bom.totals.openingsCount !== 2) throw new Error(`Expected totals.openingsCount === 2, got ${bom.totals.openingsCount}`);

if (bom.totals.studs.common <= 0) throw new Error('Expected common studs count > 0');
if (bom.totals.studs.king <= 0) throw new Error('Expected king studs count > 0');
if (bom.totals.studs.jack <= 0) throw new Error('Expected jack studs count > 0');
if (bom.totals.studs.total <= 0) throw new Error('Expected total studs count > 0');

if (bom.totals.plates.topPlateLinealFt <= 0) throw new Error('Expected top plate lineal feet > 0');
if (bom.totals.plates.bottomPlateLinealFt <= 0) throw new Error('Expected bottom plate lineal feet > 0');

console.log('Header Schedule length:', bom.headerSchedule.length);
if (bom.headerSchedule.length !== 2) throw new Error(`Expected 2 headers in schedule, got ${bom.headerSchedule.length}`);

const doorHeader = bom.headerSchedule.find(h => h.clearSpanMm === 1000);
console.log('Door Header:', doorHeader);
if (!doorHeader || doorHeader.depthMm !== 140) throw new Error('Door header span depth mismatch (expected 140mm depth for <=1219mm span)');

const winHeader = bom.headerSchedule.find(h => h.clearSpanMm === 1800);
console.log('Window Header:', winHeader);
if (!winHeader || winHeader.depthMm !== 184) throw new Error('Window header span depth mismatch (expected 184mm depth for <=1829mm span)');

console.log('Stock Lumber Ordering:', bom.stockOrdering);
if (bom.stockOrdering.length === 0) throw new Error('Expected non-empty stock lumber ordering list');

console.log('Hardware Schedule items count:', bom.hardware.length);
if (bom.hardware.length < 4) throw new Error('Expected hardware schedule items');

// 3. Test CSV export
const csv = ifcWallBOMToCSV(bom);
console.log('CSV Preview (first 300 chars):\n', csv.slice(0, 300));
if (!csv.includes('IFC WALL FRAMING BILL OF MATERIALS & TAKEOFF')) throw new Error('CSV missing title header');
if (!csv.includes('LINTEL / HEADER SCHEDULE')) throw new Error('CSV missing header schedule section');

// 4. Test HTML export
const html = ifcWallBOMHTML(bom);
console.log('HTML Preview (first 250 chars):\n', html.slice(0, 250));
if (!html.includes('IFC Wall Framing Bill of Materials (BOM)')) throw new Error('HTML missing title');

console.log('✓ IFC Wall Framing BOM Generator test passed successfully!');
