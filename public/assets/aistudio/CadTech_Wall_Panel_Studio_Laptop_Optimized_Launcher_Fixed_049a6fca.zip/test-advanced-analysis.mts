import assert from 'node:assert';
import { columnCp, columnFcE, beamCL, pinJointedAxial, analyzeTruss, advInputFromTruss, SPF_NO2 } from './src/services/trussAdvancedAnalysis.ts';
import { createSampleFinkTruss } from './src/services/trussStressEngine.ts';

let n = 0; const ok = (msg: string) => { n++; console.log('  ok -', msg); };

// 1. NDS 3.7.1: when FcE = Fc*, r = 1 and Cp = (2/1.6) - sqrt((2/1.6)^2 - 1/0.8) = 0.6910
{
  const cp = columnCp(10, 10);
  assert(Math.abs(cp - 0.691) < 0.001, `Cp = ${cp}`);
  ok(`column Cp known value (r=1): ${cp.toFixed(4)}`);
}
// 2. Cp falls as slenderness rises, and is 1 for very stocky members
{
  const stocky = columnCp(10, 1e6), slender = columnCp(10, 0.5);
  assert(stocky > 0.99 && slender < stocky, 'Cp monotonic');
  ok(`Cp monotonic: stocky ${stocky.toFixed(3)}, slender ${slender.toFixed(3)}`);
}
// 3. Euler stress: FcE = 0.822*Emin/(le/d)^2
{
  const f = columnFcE(10, 10);
  assert(Math.abs(f - 0.822 * 10 / 100) < 1e-12);
  ok('Euler buckling stress formula');
}
// 4. Lateral stability CL = 1 for short, well-braced beams
{
  const cl = beamCL(6.03, 3517, 1, 3.5, 1.5); // SPF No.2 2x4, Fb* ~ 6 MPa, Emin 510k psi, 1 in unbraced
  assert(cl > 0.99 && cl <= 1, `CL = ${cl}`);
  ok(`CL ~1 for braced beam (${cl.toFixed(3)})`);
}
// 5. Pin-jointed triangle: apex load P=10 kN, span 4 m, apex 2 m. Each rafter 7.07 kN compression, tie 5 kN tension.
{
  const nodes = [{ id: 1, x: 0, y: 0 }, { id: 2, x: 4000, y: 0 }, { id: 3, x: 2000, y: 2000 }];
  const EA = 1e6;
  const f = pinJointedAxial(nodes, [{ a: 1, b: 2, EA }, { a: 1, b: 3, EA }, { a: 2, b: 3, EA }], { 3: [0, -10000] }, 1, 2);
  assert(Math.abs(f[0] - 5000) < 1, `tie = ${f[0]}`);
  assert(Math.abs(f[1] + 7071.07) < 2, `rafter = ${f[1]}`);
  assert(Math.abs(f[2] + 7071.07) < 2, `rafter2 = ${f[2]}`);
  ok(`triangle: tie ${f[0].toFixed(0)} N (+T), rafters ${f[1].toFixed(0)} N (-C)`);
}
// 6. Full analysis of the app's sample Fink truss: finite results, load balance, deflection reported
{
  const truss = createSampleFinkTruss() as any;
  const inp = advInputFromTruss(truss);
  const r = analyzeTruss(inp);
  assert(r.members.length === truss.members.length);
  for (const m of r.members) {
    for (const v of Object.values(m.ratios)) assert(Number.isFinite(v as number), `${m.id} ratio not finite`);
    assert(Number.isFinite(m.governing.ratio));
  }
  // load balance: reactions sum to total D + S on the top and bottom chords (horizontal projection = span)
  const span = inp.spanMm / 1000, sp = inp.spacingMm / 1000;
  const expectedDS = ((15 + 20) * 0.0478803 * sp * span + 5 * 0.0478803 * sp * span) * 1000;
  const got = r.reactionsN.left + r.reactionsN.right;
  assert(Math.abs(got - expectedDS) / expectedDS < 0.02, `reactions ${got} vs expected ${expectedDS.toFixed(0)}`);
  ok(`reaction balance D+S: ${got} N vs ${expectedDS.toFixed(0)} N`);
  ok(`deflection live ${r.deflection.liveMm} mm (limit ${r.deflection.liveLimitMm}), total ${r.deflection.totalMm} mm (limit ${r.deflection.totalLimitMm})`);
  ok(`members checked: ${r.members.length}, overall ${r.overall}, unstable=${r.unstable}`);
  assert(SPF_NO2.Fc === 1150);
}
console.log(`\n${n} checks passed`);
