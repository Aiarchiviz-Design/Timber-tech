import assert from 'node:assert/strict';
import fs from 'node:fs';

globalThis.window = globalThis;
globalThis.document = undefined;
(0, eval)(fs.readFileSync(new URL('./wall-panel-package.js', import.meta.url), 'utf8'));
const api = window.wallPanelPackageInternals;
let n = 0;
const ok = (message) => { n++; console.log(`  ok - ${message}`); };

// Metric output formatting and timber-size normalization.
assert.equal(api.fmtMm(3048), '3048');
assert.equal(api.fmtMm(1219.2), '1219');
ok('dimensions display as rounded millimetres');
assert.deepEqual(api.sectionDimensions('45 × 90'), { width: 45, depth: 90 });
assert.equal(api.metricSectionLabel('45 × 90'), '45 x 90 mm');
assert.deepEqual(api.sectionDimensions('2x4'), { width: 38, depth: 89 });
ok('metric timber sections stay metric and legacy 2x4 normalizes to 38 x 89 mm');
assert(Math.abs(api.timberVolumeM3([{ section: '45 × 90', length: 1000, qty: 1 }]) - 0.00405) < 1e-10);
ok('timber volume is estimated from metric section dimensions and millimetre lengths');

// OSB sheet layout stays in mm and covers the wall area exactly.
const sheets = api.sheathingPieces(10200, 3048);
const totalSheets = sheets.reduce((sum, row) => sum + row.qty, 0);
assert.equal(totalSheets, 9 * 2);
ok(`metric sheathing layout computes ${totalSheets} pieces for a 10200 x 3048 mm wall`);
const area = sheets.reduce((sum, row) => sum + row.qty * row.length * row.width, 0);
assert(Math.abs(area - 10200 * 3048) < 1);
ok('sheathing pieces cover the stated wall area exactly');

const wall = {
  id: 'W1', type: 'wall', story: 's0', layer: 'exterior',
  a: { x: 0, y: 0 }, b: { x: 14000, y: 0 }, height: 2700, thickness: 90,
};
const opening = { id: 'WIN1', type: 'window', host: 'W1', offset: 7000, width: 1200, height: 1200, sill: 900 };
const model = { name: 'Metric panel test', stories: [{ id: 's0', name: 'Ground' }], elements: [wall, opening] };
const segments = api.panelSegments(wall, [wall], model);
assert(segments.length >= 3);
assert(segments.every(segment => segment.d1 - segment.d0 <= 6000 + 1));
assert(segments.every(segment => segment.d1 - segment.d0 >= 2400 - 1));
const openingNoBreakStart = opening.offset - opening.width / 2 - 300;
const openingNoBreakEnd = opening.offset + opening.width / 2 + 300;
assert(segments.slice(0, -1).every(segment => {
  const d = segment.d1;
  return d <= openingNoBreakStart || d >= openingNoBreakEnd;
}));
ok(`longest-lawful panel splitting creates ${segments.length} panels and keeps breaks clear of the opening`);
const tighter = api.panelSegments(wall, [wall], model, { panelMaxLengthMm: 4500 });
assert(tighter.length > segments.length);
ok('panel maximum is configurable and a smaller maximum generates more panels');
const tenMetreWall = { ...wall, b: { x: 10000, y: 0 } };
const tenMetreModel = { ...model, elements: [tenMetreWall] };
const reducedCount = api.panelSegments(tenMetreWall, [tenMetreWall], tenMetreModel);
const legacyCount = api.panelSegments(tenMetreWall, [tenMetreWall], tenMetreModel, { panelMaxLengthMm: 4877 });
assert.equal(reducedCount.length, 2);
assert.equal(legacyCount.length, 3);
ok('6000 mm default reduces a 10000 mm straight wall from three panels to two');

const framingFn = () => ({ members: [
  { id: 'bp', type: 'Bottom plate', section: '45 × 90', length: 14000, x0: 0, x1: 14000, z0: 0, z1: 45 },
  { id: 'tp', type: 'Top plate', section: '45 × 90', length: 14000, x0: 0, x1: 14000, z0: 2655, z1: 2700 },
  { id: 's1', type: 'Common stud', section: '45 × 90', length: 2700, x0: 0, x1: 45, z0: 0, z1: 2700 },
  { id: 's2', type: 'Common stud', section: '45 × 90', length: 2700, x0: 5000, x1: 5045, z0: 0, z1: 2700 },
  { id: 's3', type: 'Common stud', section: '45 × 90', length: 2700, x0: 10000, x1: 10045, z0: 0, z1: 2700 },
] });
const built = api.buildPackage(model, framingFn, () => null);
assert.equal(built.panelCount, segments.length);
const pdf = api.buildPdf(built.pages);
assert(pdf.startsWith('%PDF-1.4'));
assert(pdf.includes('ALL DIMENSIONS AND TIMBER SIZES IN mm'));
assert(pdf.includes('45 x 90 mm SPF No.2'));
assert(!pdf.includes('feet-inches'));
assert(!pdf.includes('sq ft'));
assert(!pdf.includes('board feet'));
assert(!pdf.includes('7/16'));
assert(!pdf.includes('2x4'));
assert(pdf.includes('12 mm OSB SHEATHING - EXTERIOR FACE ONLY'));
assert(pdf.includes('OSB pcs'));
assert(pdf.includes('exterior OSB ON'));
ok(`PDF builds with ${built.panelCount} panels and metric dimensions, timber sizes, areas, volumes, and exterior OSB ON`);

// The OFF option must omit sheathing layout and reset exterior OSB takeoff quantity to zero.
const builtOsbOff = api.buildPackage(model, framingFn, () => null, { exteriorOsbEnabled: false });
const pdfOsbOff = api.buildPdf(builtOsbOff.pages);
assert(pdfOsbOff.includes('12 mm OSB SHEATHING: OFF'));
assert(!pdfOsbOff.includes('12 mm OSB SHEATHING - EXTERIOR FACE ONLY'));
assert(pdfOsbOff.includes('0 OSB cut pieces'));
assert(pdfOsbOff.includes('exterior OSB OFF'));
ok('OSB OFF removes the sheet grid/schedule and reports zero OSB cut pieces');

// Interior walls must never receive exterior OSB even when the project toggle is ON.
const interiorWall = { ...wall, id: 'W2', layer: 'Interior Walls' };
assert.equal(api.isExteriorWall(interiorWall), false);
const interiorModel = { name: 'Interior-only test', stories: [{ id: 's0', name: 'Ground' }], elements: [interiorWall] };
const builtInterior = api.buildPackage(interiorModel, framingFn, () => null, { exteriorOsbEnabled: true });
const pdfInterior = api.buildPdf(builtInterior.pages);
assert(pdfInterior.includes('NOT APPLICABLE - EXTERIOR WALLS ONLY'));
assert(!pdfInterior.includes('12 mm OSB SHEATHING - EXTERIOR FACE ONLY'));
assert(pdfInterior.includes('0 OSB cut pieces'));
assert(pdfInterior.includes('exterior OSB ON'));
ok('OSB ON affects exterior walls only; interior wall panel quantities remain zero');

// PDF xref must point at the actual cross-reference table.
const startXref = Number(pdf.match(/startxref\n(\d+)/)?.[1]);
assert(Number.isFinite(startXref));
assert.equal(pdf.slice(startXref, startXref + 4), 'xref');
ok('PDF structure and cross-reference offsets are valid');
console.log(`\n${n} checks passed`);
