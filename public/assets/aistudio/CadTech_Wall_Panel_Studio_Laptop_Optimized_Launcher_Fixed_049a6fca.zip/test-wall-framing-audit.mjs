import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { createRequire } from 'node:module';
import { writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { createFramingContext } = require('./tests/framing-test-context.cjs');
const here = path.dirname(fileURLToPath(import.meta.url));
const framingSource = fs.readFileSync(new URL('./framing.js', import.meta.url), 'utf8');
const packageSource = fs.readFileSync(new URL('./wall-panel-package.js', import.meta.url), 'utf8');

function makeModel() {
  const wall = {
    id: 'W-EXT-01', type: 'wall', story: 's0', layer: 'Exterior Walls', isExternal: true,
    material: 'Timber', reference: 'center', a: { x: 0, y: 0 }, b: { x: 6000, y: 0 },
    height: 2700, thickness: 140,
    framing: { enabled: true, studWidth: 45, studDepth: 140, spacing: 406.4, plateThickness: 45,
      topPlates: 2, bottomPlates: 1, headerDepth: 190, headerPlies: 2, autoHeaderDepth: true,
      cornerDetail: 'threeStud', tDetail: 'backingStud', insideJunctionDetail: 'insideStudFull', blockingSpacing: 1219.2 }
  };
  const door = { id: 'D-01', type: 'door', host: wall.id, offset: 1200, width: 900, height: 2100, sill: 0 };
  const window = { id: 'WIN-01', type: 'window', host: wall.id, offset: 4200, width: 1200, height: 1200, sill: 900 };
  return { name: 'Wall Framing QA Sample', stories: [{ id: 's0', name: 'Ground Floor', elevation: 0, height: 2700 }], elements: [wall, door, window] };
}

const model = makeModel();
const ctx = createFramingContext(model);
const wall = model.elements[0];
const layout = ctx.generateWallFraming(wall, model);
assert.ok(layout.members.length > 20, `Expected real framing members, got ${layout.members.length}`);
assert.equal(layout.issues.length, 0, layout.issues.join('; '));
for (const m of layout.members) {
  for (const key of ['x0', 'x1', 'z0', 'z1', 'length', 'depth']) assert.ok(Number.isFinite(m[key]), `${m.type} has invalid ${key}`);
  assert.ok(m.x0 >= -0.1 && m.x1 <= 6000.1 && m.x1 > m.x0, `${m.type} horizontal bounds invalid: ${m.x0}-${m.x1}`);
  assert.ok(m.z0 >= -0.1 && m.z1 <= 2700.1 && m.z1 > m.z0, `${m.type} vertical bounds invalid: ${m.z0}-${m.z1}`);
}
const count = type => layout.members.filter(m => m.type.toLowerCase() === type.toLowerCase()).length;
assert.ok(count('Top plate') >= 2);
assert.ok(count('Bottom plate') >= 1);
assert.ok(count('Header') === 2, `Expected a header for both openings, got ${count('Header')}`);
assert.ok(count('King stud') >= 4);
assert.ok(count('Jack stud') >= 4);
assert.ok(layout.members.some(m => /cripple/i.test(m.type)), 'Expected cripple framing around window');
console.log(`PASS real wall framing: ${layout.members.length} members; two openings; headers, kings, jacks, plates, cripples present; all member bounds are finite/in-wall`);

// Auto header depth should fit the available opening headspace; fixed depth must be respected.
const nearTopModel = makeModel();
nearTopModel.elements[1].height = 2500;
const nearTopCtx = createFramingContext(nearTopModel);
const autoLayout = nearTopCtx.generateWallFraming(nearTopModel.elements[0], nearTopModel);
const header = autoLayout.members.find(m => m.type === 'Header' && m.headerDepth !== undefined);
assert.ok(header, `Auto header was not generated: ${autoLayout.issues.join('; ')}`);
assert.ok(header.headerDepth <= 110 + 0.1, `Auto header should fit in available 110 mm, got ${header.headerDepth}`);
assert.ok(header.z1 <= 2610 + 0.1);
console.log('PASS automatic header depth respects available height beneath top plates');

const fixedModel = makeModel();
fixedModel.elements[0].framing.autoHeaderDepth = false;
fixedModel.elements[0].framing.headerDepth = 190;
fixedModel.elements[1].height = 2500;
const fixedCtx = createFramingContext(fixedModel);
const fixedLayout = fixedCtx.generateWallFraming(fixedModel.elements[0], fixedModel);
assert.ok(fixedLayout.issues.some(s => s.includes('fixed header depth 190 mm does not fit')));
assert.equal(fixedLayout.members.filter(m => m.type === 'Header').length, 1, 'Only the other opening should still receive a header');
console.log('PASS fixed header depth is not silently overridden when it cannot fit');

// Invalid and overlapping openings must be flagged, never silently framed as valid.
const invalidModel = makeModel();
invalidModel.elements[1].offset = 6500;
const invalidCtx = createFramingContext(invalidModel);
const invalidLayout = invalidCtx.generateWallFraming(invalidModel.elements[0], invalidModel);
assert.ok(invalidLayout.issues.some(s => s.includes('extends beyond its host wall')));
assert.ok(invalidLayout.members.length > 0, 'Valid wall framing should remain when one opening is invalid');
const overlapModel = makeModel();
overlapModel.elements[1].offset = 3000;
overlapModel.elements[1].width = 1500;
overlapModel.elements[2].offset = 3500;
overlapModel.elements[2].width = 1500;
const overlapCtx = createFramingContext(overlapModel);
const overlapLayout = overlapCtx.generateWallFraming(overlapModel.elements[0], overlapModel);
assert.ok(overlapLayout.issues.some(s => s.includes('overlaps another opening')));
assert.equal(overlapLayout.members.filter(m => m.type === 'Header').length, 0);
console.log('PASS invalid and overlapping openings are flagged and conflicting opening members are omitted');

// Build a real metric PDF package using generated framing, not fabricated sample members.
globalThis.window = globalThis;
globalThis.document = undefined;
vm.runInThisContext(framingSource, { filename: 'framing.js' });
vm.runInThisContext(packageSource, { filename: 'wall-panel-package.js' });
const api = globalThis.wallPanelPackageInternals;
const built = api.buildPackage(model, (w, customModel) => ctx.generateWallFraming(w, customModel || model), (w, m) => ctx.framingMemberWorld(w, m), { exteriorOsbEnabled: true, osbThicknessMm: 12 });
assert.ok(built.panelCount >= 1);
const pageText = built.pages.flatMap(p => p.ops).join('\n');
assert.ok(pageText.includes('2D WALL FRAMING PLAN'));
assert.ok(!/\(0 overall\) Tj/.test(pageText), 'Single-wall plan must not label a zero-width/height overall dimension');
assert.ok(pageText.includes('140 wall thickness'), 'Single-wall plan should dimension the degenerate axis using wall thickness');
assert.ok(pageText.includes('WALL PANEL ELEVATION + PLAN'));
assert.ok(pageText.includes('WALL PLAN / TOP-PLATE & STUD LAYOUT'));
assert.ok(pageText.includes('WINDOW & DOOR SCHEDULE - DIMENSIONS IN mm'));
assert.ok(pageText.includes('12 mm OSB SHEATHING - EXTERIOR FACE ONLY'));
const pdf = api.buildPdf(built.pages);
assert.ok(pdf.startsWith('%PDF-1.4'));
const xref = Number(pdf.match(/startxref\n(\d+)/)?.[1]);
assert.equal(pdf.slice(xref, xref + 4), 'xref');
const qaPdf = path.join(here, 'WALL_FRAMING_QA_SAMPLE.pdf');
writeFileSync(qaPdf, Buffer.from(pdf, 'binary'));
console.log(`PASS wall report package: ${built.panelCount} panels, ${built.pages.length} pages; elevation, plan, opening schedule, 12 mm exterior OSB, and PDF xref validated`);
console.log(`QA sample PDF written to ${qaPdf}`);

// Multi-wall room regression: all four walls must generate framing, 8 m walls
// must split into the longest compliant panel lengths, and layout/elevations must
// all be included in the same construction PDF.
function roomWall(id, a, b) {
  return { id, type: 'wall', story: 's0', layer: 'Exterior Walls', isExternal: true, material: 'Timber', reference: 'center', a, b, height: 2700, thickness: 140,
    framing: { enabled: true, studWidth: 45, studDepth: 140, spacing: 406.4, plateThickness: 45, topPlates: 2, bottomPlates: 1,
      headerDepth: 190, headerPlies: 2, autoHeaderDepth: true, cornerDetail: 'threeStud', tDetail: 'backingStud', insideJunctionDetail: 'insideStudFull', blockingSpacing: 1219.2 } };
}
const roomWalls = [
  roomWall('W-S', { x: 0, y: 0 }, { x: 6000, y: 0 }),
  roomWall('W-E', { x: 6000, y: 0 }, { x: 6000, y: 8000 }),
  roomWall('W-N', { x: 6000, y: 8000 }, { x: 0, y: 8000 }),
  roomWall('W-W', { x: 0, y: 8000 }, { x: 0, y: 0 })
];
const roomOpenings = [
  { id: 'D-ROOM', type: 'door', host: 'W-S', offset: 1200, width: 900, height: 2100, sill: 0 },
  { id: 'WIN-ROOM', type: 'window', host: 'W-N', offset: 3000, width: 1200, height: 1200, sill: 900 }
];
const roomModel = { name: 'Four Wall Room QA', stories: [{ id: 's0', name: 'Ground Floor', elevation: 0, height: 2700 }], elements: [...roomWalls, ...roomOpenings] };
const roomCtx = createFramingContext(roomModel);
for (const roomWallItem of roomWalls) {
  const wallLayout = roomCtx.generateWallFraming(roomWallItem, roomModel);
  assert.ok(wallLayout.members.length > 10, `${roomWallItem.id} failed to generate real framing`);
  assert.equal(wallLayout.issues.length, 0, `${roomWallItem.id}: ${wallLayout.issues.join('; ')}`);
}
const roomBuilt = api.buildPackage(roomModel, (w, m) => roomCtx.generateWallFraming(w, m || roomModel), (w, m) => roomCtx.framingMemberWorld(w, m), { exteriorOsbEnabled: true, osbThicknessMm: 12 });
assert.ok(roomBuilt.panelCount >= 6, `Expected panelization of four walls plus 8 m sides, got ${roomBuilt.panelCount}`);
assert.ok(roomBuilt.pages.length >= 9, `Expected a combined plan, wall elevations, opening schedule and summary; got ${roomBuilt.pages.length} pages`);
const roomPageText = roomBuilt.pages.flatMap(p => p.ops).join('\n');
assert.ok(roomPageText.includes('2D WALL FRAMING PLAN'));
assert.ok(roomPageText.includes('WALL PANEL ELEVATION + PLAN'));
assert.ok(roomPageText.includes('WALL PLAN / TOP-PLATE & STUD LAYOUT'));
assert.ok(roomPageText.includes('W-S') && roomPageText.includes('W-N'));
assert.ok(roomPageText.includes('12 mm OSB SHEATHING - EXTERIOR FACE ONLY'));
const roomPdf = api.buildPdf(roomBuilt.pages);
const roomPdfPath = path.join(here, 'WALL_FRAMING_QA_ROOM_SAMPLE.pdf');
writeFileSync(roomPdfPath, Buffer.from(roomPdf, 'binary'));
console.log(`PASS multi-wall room: ${roomWalls.length} walls framed with no issues; ${roomBuilt.panelCount} panels and ${roomBuilt.pages.length} combined PDF pages; written ${roomPdfPath}`);
