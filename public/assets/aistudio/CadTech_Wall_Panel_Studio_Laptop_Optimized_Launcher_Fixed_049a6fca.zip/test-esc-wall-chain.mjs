// Unit test for Esc escaping and continuous wall drafting

console.log('Testing Esc Key Escaping & Continuous Wall Chaining...');

// Verify logic structures
const points = [];
const p1 = { x: 0, y: 0 };
const p2 = { x: 5000, y: 0 };

// Simulate 1st wall placement
points.push(p1);
points.push(p2);

if (points.length === 2) {
  // Placed 1st wall from p1 to p2
  // Automatically chain 2nd wall starting from endpoint p2
  const b = points[1];
  const chainedPoints = [{ ...b }];
  console.log('1st Wall Placed. Chained start point for 2nd Wall:', chainedPoints[0]);

  if (chainedPoints.length === 1 && chainedPoints[0].x === 5000 && chainedPoints[0].y === 0) {
    console.log('✓ Continuous wall chaining logic verified!');
  } else {
    console.error('FAILED: Chained start point mismatch.');
    process.exit(1);
  }
}

// Simulate pressing Esc
let activeTool = 'wall';
let activePoints = [{ x: 5000, y: 0 }];

function handleEscape() {
  activePoints = [];
  activeTool = 'select';
}

handleEscape();

if (activePoints.length === 0 && activeTool === 'select') {
  console.log('✓ Esc key escaping logic verified!');
} else {
  console.error('FAILED: Esc key did not reset tool/points.');
  process.exit(1);
}

console.log('✓ All CAD drafting interaction tests passed successfully!');
