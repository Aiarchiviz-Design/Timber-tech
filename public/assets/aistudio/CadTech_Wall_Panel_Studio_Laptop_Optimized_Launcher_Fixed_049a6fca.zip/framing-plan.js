/* Ireland-aware wall-panel design brief. This records inputs; it is not a code-compliance solver. */
const DESIGN_REGIONS={
  US:{name:'United States',standard:'Adopted IBC / ASCE 7 / NDS edition for the project'},
  CA:{name:'Canada',standard:'NBCC / CSA O86 plus applicable provincial/territorial adoption'},
  AU:{name:'Australia',standard:'NCC / AS 1720.1 and applicable AS 1684 edition'},
  UK:{name:'United Kingdom',standard:'UK Building Regulations / applicable UK National Annexes'},
  IE:{name:'Ireland (Republic)',standard:'Irish Building Regulations Part A / TGD A + applicable I.S. EN Eurocodes and Irish National Annexes'}
};
const IRELAND_DESIGN_REFERENCES=[
  {title:'Technical Guidance Document A — Structure',url:'https://www.gov.ie/en/department-of-housing-local-government-and-heritage/publications/technical-guidance-document-a-structure/'},
  {title:'NSAI — Eurocodes in Ireland and 2nd-generation adoption updates',url:'https://www.nsai.ie/standards/sectors/construction-standards/the-eurocodes/'},
  {title:'Irish National Annex to EN 1991-1-3 — Snow loads',url:'https://shop.standards.ie/en-ie/standards/na-a2-2020-to-i-s-en-1991-1-3-2003-a1-2015-883849_saig_nsai_nsai_2905467/'},
  {title:'Irish National Annex to EN 1995-1-1 — Timber structures',url:'https://shop.standards.ie/en-ie/standards/na-a1-to-i-s-en-1995-1-1-2005-874304_saig_nsai_nsai_3074180/'}
];
const IE_FIELDS=[
  ['siteLocation','Site location / town / county / Eircode','text',''],
  ['authority','Building Control Authority / project reviewer','text',''],
  ['codeEdition','Confirmed code editions / project specification','text',''],
  ['loadCombinationBasis','Load combinations / partial-factor basis','select',''],
  ['siteAltitudeM','Site altitude above sea level','number','m AOD'],
  ['terrainExposure','Terrain / exposure description','select',''],
  ['basicWindVelocityMS','Basic wind velocity vb,0 (site basis)','number','m/s'],
  ['floorDeadKNm2','Floor permanent action (Gk)','number','kN/m²'],
  ['floorImposedKNm2','Floor imposed action (Qk; use category noted)','number','kN/m²'],
  ['roofDeadKNm2','Roof permanent action (Gk)','number','kN/m²'],
  ['roofImposedKNm2','Roof imposed / maintenance action (Qk)','number','kN/m²'],
  ['groundSnowKNm2','Characteristic ground snow load sk (site basis)','number','kN/m²'],
  ['roofSnowKNm2','Calculated characteristic roof snow action','number','kN/m²'],
  ['windPressureKNm2','Net wall wind pressure (incl. pressure coefficients)','number','kN/m²'],
  ['windSuctionKNm2','Net wall wind suction / uplift','number','kN/m²'],
  ['roofUpliftKNm2','Net roof uplift for load path / anchorage','number','kN/m²'],
  ['wallGravityLineKNm','Wall / top-plate gravity line load','number','kN/m'],
  ['maxPointReactionKN','Maximum beam / truss point reaction at wall','number','kN'],
  ['timberGrade','Timber strength class','select',''],
  ['serviceClass','Timber service class per EN 1995-1-1','select',''],
  ['osbGrade','OSB product class / DoP','select',''],
  ['osbThicknessMM','Exterior OSB thickness','number','mm'],
  ['osbEdgeFixingSpacingMM','OSB edge fastener spacing (engineered value)','number','mm'],
  ['osbFieldFixingSpacingMM','OSB field fastener spacing (engineered value)','number','mm'],
  ['lateralSystem','Lateral / racking resistance system','select',''],
  ['loadNotes','Load sources, occupancy category, combinations, exclusions and engineer notes','textarea','']
];
function safeDesignRegion(region){return DESIGN_REGIONS[region]?region:'US'}
function ieFormValue(d,key){const v=d?.[key];return v===undefined||v===null?'':String(v)}
function fieldHTML([key,label,type,unit],d){
  const id='ie-'+key,val=esc(ieFormValue(d,key));
  if(type==='textarea')return `<label class="ie-field wide">${label}<textarea id="${id}" rows="3" placeholder="Record source, assumptions, N/A items and reviewer notes">${val}</textarea></label>`;
  if(type==='select'){
    let opts=[];
    if(key==='terrainExposure')opts=[['','Select site terrain / exposure'],['Urban / suburban','Urban / suburban'],['Open country','Open country'],['Coastal / exposed','Coastal / exposed'],['Complex terrain / orography','Complex terrain / orography'],['Other / project-specific assessment','Other / project-specific assessment']];
    if(key==='loadCombinationBasis')opts=[['','Select / confirm basis'],['I.S. EN 1990 + Irish National Annex (edition to be confirmed)','I.S. EN 1990 + Irish National Annex'],['Project-specific engineer-designed combination schedule attached','Engineer-designed combination schedule attached'],['Not yet defined','Not yet defined']];
    if(key==='timberGrade')opts=[['','Select verified grade'],['C14','C14'],['C16','C16'],['C18','C18'],['C24','C24'],['C30','C30'],['Other / engineered timber','Other / engineered timber']];
    if(key==='serviceClass')opts=[['','Select service class'],['1','Service Class 1'],['2','Service Class 2'],['3','Service Class 3']];
    if(key==='osbGrade')opts=[['','Select product declaration'],['OSB/3','OSB/3 — verify DoP/application'],['OSB/4','OSB/4 — verify DoP/application'],['Other / not specified','Other / not specified']];
    if(key==='lateralSystem')opts=[['','Select designed lateral system'],['OSB/structural sheathing diaphragm','OSB / structural sheathing diaphragm'],['Diagonal bracing','Diagonal bracing'],['Designed timber moment/braced frame','Designed timber moment/braced frame'],['Mixed / engineered system','Mixed / engineered system'],['Not yet designed','Not yet designed']];
    return `<label class="ie-field">${label}<select id="${id}">${opts.map(([v,t])=>`<option value="${esc(v)}" ${String(v)===String(ieFormValue(d,key))?'selected':''}>${esc(t)}</option>`).join('')}</select></label>`;
  }
  const step=type==='number'?(key.includes('SpacingMM')||key==='osbThicknessMM'?'1':'0.01'):undefined;
  return `<label class="ie-field">${label}<span class="ie-input-row"><input id="${id}" type="${type}" ${type==='number'?'min="0" step="'+step+'"':''} value="${val}" placeholder="${type==='number'?'Enter site-calculated value':'Enter project value'}">${unit?`<small>${unit}</small>`:''}</span></label>`;
}
function currentIrelandData(){
  const defaults={osbThicknessMM:12};
  return {...defaults,...(model.structuralDesign?.ireland||{})};
}
function ieMissingInputs(d){
  const keys=[
    ['siteLocation','Site location'],['authority','Building Control Authority / reviewer'],['codeEdition','Confirmed code editions'],['loadCombinationBasis','Load combinations / partial-factor basis'],['siteAltitudeM','Site altitude above sea level'],
    ['terrainExposure','Wind terrain / exposure basis'],['basicWindVelocityMS','Basic wind velocity basis'],
    ['floorDeadKNm2','Floor permanent action (or N/A)'],['floorImposedKNm2','Floor imposed action (or N/A)'],
    ['roofDeadKNm2','Roof permanent action'],['roofImposedKNm2','Roof imposed action (or N/A)'],
    ['groundSnowKNm2','Ground snow action'],['roofSnowKNm2','Roof snow action'],
    ['windPressureKNm2','Wall wind pressure'],['windSuctionKNm2','Wall wind suction'],['roofUpliftKNm2','Roof uplift'],
    ['wallGravityLineKNm','Wall gravity line load / explicit N/A'],['maxPointReactionKN','Maximum point reaction / explicit N/A'],
    ['timberGrade','Verified timber strength class'],['serviceClass','Timber service class'],['lateralSystem','Lateral / racking system']
  ];
  const missing=keys.filter(([k])=>d[k]===undefined||d[k]===null||String(d[k]).trim()==='').map(([,label])=>label);
  const osbOn=document.querySelector('#wall-osb-toggle')?.checked!==false;
  if(osbOn){for(const [k,label] of [['osbGrade','OSB product class / DoP'],['osbEdgeFixingSpacingMM','OSB edge fastener spacing'],['osbFieldFixingSpacingMM','OSB field fastener spacing']])if(d[k]===undefined||d[k]===null||String(d[k]).trim()==='')missing.push(label)}
  return missing;
}
function designValue(d,key,unit=''){const v=d?.[key];return v===undefined||v===null||String(v).trim()===''?'NOT ENTERED':`${v}${unit?` ${unit}`:''}`}
function wallDesignStatus(w){
  const generated=generateWallFraming(w),region=safeDesignRegion(model.structuralDesign?.region||'US');
  return {wallId:w.id,region,standard:DESIGN_REGIONS[region].standard,status:'Design inputs required — no structural verification',geometryIssues:generated.issues,
    required:['Adopted code edition / National Annex','Site-specific wind and snow actions','Floor / roof gravity actions and reactions','Timber grade and service class','Bracing / diaphragm design','Hold-downs, anchors and connection capacities','Foundation / bearing verification'],
    checks:['Stud axial load, buckling and combined actions','Headers, lintels and bearing','Wind load path and overturning','Racking / shear wall and diaphragm','OSB panel grade, layout and fasteners','Connections, hold-downs and anchorage']};
}
function saveStructuralDesignForm(){
  const region=safeDesignRegion($('#design-region')?.value||model.structuralDesign?.region||'US');
  const previous=model.structuralDesign||{};
  const ie=currentIrelandData();
  for(const [key,,type] of IE_FIELDS){
    const el=$('ie-'+key);if(!el)continue;
    if(type==='number')ie[key]=el.value.trim()===''?null:Number(el.value);
    else ie[key]=el.value;
  }
  const next={...previous,region,jurisdiction:DESIGN_REGIONS[region].name,standard:DESIGN_REGIONS[region].standard,ireland:ie,designStatus:'INPUTS REQUIRED — engineer verification needed',updatedAt:new Date().toISOString()};
  commit(()=>{model.structuralDesign=next},false);
  updateIrelandStatus();
}
function updateIrelandStatus(){
  const box=$('ie-input-status');if(!box)return;
  const isIE=$('#design-region')?.value==='IE';if(!isIE){box.style.display='none';return;}
  box.style.display='block';const missing=ieMissingInputs(currentIrelandData());
  box.innerHTML=`<strong>${missing.length?`Design brief incomplete — ${missing.length} input(s) need attention`:'Inputs captured — engineering verification still required'}</strong><p>${missing.length?`Items not entered: ${missing.slice(0,7).map(esc).join('; ')}${missing.length>7?' …':''}. Enter a project value or document N/A/assumptions in the notes.`:'The key fields have values. This is not a pass/fail calculation or a compliance certificate.'}</p>`;
}
function designPanelsDialog(){
  const region=safeDesignRegion(model.structuralDesign?.region||'US'),ie=currentIrelandData(),rows=model.elements.filter(w=>w.type==='wall').map(w=>wallDesignStatus(w));
  const regionOptions=Object.entries(DESIGN_REGIONS).map(([id,r])=>`<option value="${id}" ${id===region?'selected':''}>${esc(r.name)} · ${esc(r.standard)}</option>`).join('');
  const standards=`<ul class="ie-standards"><li><b>I.S. EN 1990</b> — basis of structural design, reliability and load combinations with Irish National Annex.</li><li><b>I.S. EN 1991-1-1</b> — self-weight, densities and imposed actions.</li><li><b>I.S. EN 1991-1-3</b> — snow actions and Irish National Annex.</li><li><b>I.S. EN 1991-1-4</b> — wind actions and Irish National Annex.</li><li><b>I.S. EN 1991-1-7</b> — accidental actions where applicable.</li><li><b>I.S. EN 1995-1-1</b> — timber member, stability and connection design with Irish National Annex; EN 1995-1-2 for fire where applicable.</li><li><b>EN 338 / EN 14081</b> — timber strength class / structural timber product requirements.</li><li><b>EN 300 / EN 13986</b> — OSB panel classification and wood-based panels for construction; verify product DoP and intended use.</li><li><b>Irish Building Regulations</b> — Part A / TGD A; also check Parts B, C, D, F and L where applicable to the building and wall build-up.</li></ul>`;
  openModal('Wall panel structural design · Codes, loads & design inputs',`
    <div class="ie-design-layout">
      <label class="ie-field wide"><b>Project design region</b><select id="design-region">${regionOptions}</select></label>
      <div class="ie-note"><b>Important:</b> this workflow stores the design basis and project load inputs; it does not compute Irish wind/snow actions or certify member, bracing, OSB-fixing, connection or foundation capacity. Do not use a generated panel layout as proof of code compliance.</div>
      <div id="ie-design-panel" style="${region==='IE'?'':'display:none;'}">
        <h3>Republic of Ireland — structural design basis</h3>
        <div class="ie-note">Use the applicable Irish-adopted editions and National Annexes confirmed for this project. NSAI's published plan dated 19 January 2026 said Ireland intended a consolidated adoption of the second-generation Eurocodes by the end of Q1 2027, with first-generation Eurocodes scheduled for European withdrawal on 30 March 2028. Re-check NSAI and the project Building Control Authority at appointment / design freeze; do not mix generations.</div>
        <details open><summary>1. Project location and adopted standards</summary><div class="ie-fields">${IE_FIELDS.slice(0,7).map(f=>fieldHTML(f,ie)).join('')}</div></details>
        <details open><summary>2. Gravity, snow and wind actions (characteristic inputs)</summary><p class="ie-small">Enter values from the project-specific action assessment. Units are metric; leave blank until established. Use the notes to record occupancy category, exposure, pressure coefficients, load source and any non-applicable actions.</p><div class="ie-fields">${IE_FIELDS.slice(7,18).map(f=>fieldHTML(f,ie)).join('')}</div></details>
        <details open><summary>3. Timber, OSB, bracing and connections</summary><div class="ie-fields">${IE_FIELDS.slice(18).map(f=>fieldHTML(f,ie)).join('')}</div></details>
        <details><summary>4. Ireland code and regulatory checklist</summary>${standards}</details>
        <div id="ie-input-status" class="ie-status" role="status"></div>
        <div class="ie-reference"><b>Official reference links</b><br>${IRELAND_DESIGN_REFERENCES.map(r=>`<a href="${r.url}" target="_blank" rel="noopener noreferrer">${esc(r.title)}</a>`).join(' · ')}</div>
      </div>
      <div id="other-region-note" class="ie-note" style="${region==='IE'?'display:none;':''}">For other regions, select the adopted local code and National Annex, enter site-specific actions, and obtain local structural review. The wall layout engine does not replace a jurisdiction-specific calculation.</div>
      <h3>Wall geometry / verification status</h3>
      <div class="modal-copy">${rows.length} wall elements found. All are shown as awaiting structural verification; geometry status is not a structural pass.</div>
      <div class="ie-table-wrap"><table class="design-table"><thead><tr><th>Wall</th><th>Design status</th><th>Geometry check</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.wallId)}</td><td>${esc(r.status)}</td><td>${r.geometryIssues.length?esc(r.geometryIssues.join('; ')):'No geometry issues reported'}</td></tr>`).join('')}</tbody></table></div>
      <div class="modal-actions"><button id="design-save" class="primary">Save design inputs</button><button id="design-report" class="subtle">Export design brief JSON</button></div>
    </div>`);
  const dlg=$('#modal'),body=$('#modal-body');if(dlg){dlg.style.width='min(1120px, 96vw)';dlg.style.maxWidth='96vw';dlg.style.maxHeight='92vh';}if(body){body.style.maxHeight='calc(92vh - 95px)';body.style.overflowY='auto';}
  const regionEl=$('design-region');if(regionEl)regionEl.onchange=()=>{saveStructuralDesignForm();$('#modal')?.close?.();designPanelsDialog()};
  for(const [key,,type] of IE_FIELDS){const el=$('ie-'+key);if(el)el.addEventListener('change',saveStructuralDesignForm)}
  bindClick('#design-save',()=>{saveStructuralDesignForm();toast('Design basis and load inputs saved in the BIM project. Structural verification is still required.')});
  bindClick('#design-report',()=>{
    saveStructuralDesignForm();const currentRegion=safeDesignRegion(model.structuralDesign?.region||'US');
    const report={format:'cadtech-wall-panel-design-brief',formatVersion:1,project:model.name,revision:model.revision,region:currentRegion,jurisdiction:DESIGN_REGIONS[currentRegion].name,standard:DESIGN_REGIONS[currentRegion].standard,projectDesignInputs:model.structuralDesign,wallStatus:model.elements.filter(w=>w.type==='wall').map(w=>wallDesignStatus(w)),codeReferences:currentRegion==='IE'?IRELAND_DESIGN_REFERENCES:[],limitations:['No wind/snow action calculation is performed by this design-brief screen.','No timber, header, OSB shear, fastener, hold-down, connection, anchorage or foundation capacity is certified.','Check applicable code editions, National Annexes, project-specific actions, and local Building Control requirements.'],exportedAt:new Date().toISOString()};
    download('wall-panel-design-brief-'+currentRegion.toLowerCase()+'.json',JSON.stringify(report,null,2),'application/json');
  });
  updateIrelandStatus();
}

function framingPlanMembers(){return model.elements.filter(w=>w.type==='wall'&&w.story===activeStory&&shown(w)).flatMap(w=>generateWallFraming(w).members.map(m=>({wall:w,member:m,polygon:framingMemberWorld(w,m)})))}
function drawFramingPlan(){const members=framingPlanMembers(),walls=model.elements.filter(w=>w.type==='wall'&&w.story===activeStory&&shown(w));for(const w of walls){const run=framingRun(w),color=selected.includes(w.id)?'#287655':'#7760b7';poly(framingMemberWorld(w,{x0:run.start,x1:run.end,depth:construction(w).studDepth}).map(p2),null,color,1.2);const p=p2(lerp(w.a,w.b,.5));label(w.id,p.x,p.y-15,10,'#426b53')}const footprints=new Set();for(const {wall:w,member:m,polygon:ps} of members){if(['Top plate','Bottom plate'].includes(m.type))continue;const key=w.id+ps.map(p=>`${Math.round(p.x)},${Math.round(p.y)}`).join('|');if(footprints.has(key))continue;footprints.add(key);const points=ps.map(p2),color=selected.includes(w.id)?'#287655':'#7760b7';poly(points,null,color,.9);if(!['Header','Sill','T-junction blocking'].includes(m.type)){line(points[0],points[2],color,.7);line(points[1],points[3],color,.7)}}for(const w of walls)for(const o of hosted(w)){const p=p2(openingPoint(o));label(o.id,p.x,p.y+19,8,'#8c7350')}

label('TIMBER CORE · CROSSED STUDS LINKED TO 3D AND CUT LIST',width/2,height-45,9,'#748b76');label('Structural design pending · construction layout only',width/2,height-27,10,'#aa7957')}
