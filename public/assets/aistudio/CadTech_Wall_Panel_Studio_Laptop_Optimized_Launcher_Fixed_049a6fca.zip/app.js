var $=window.$||(s=>document.querySelector(s)), $$=window.$$||(s=>[...document.querySelectorAll(s)]);
const bindClick = (sel, fn) => { const el = typeof sel === 'string' ? $(sel) : sel; if (el) el.onclick = fn; return el; };
const bindChange = (sel, fn) => { const el = typeof sel === 'string' ? $(sel) : sel; if (el) el.onchange = fn; return el; };
function toast(s){const t=$('#toast');if(t){t.textContent=s;t.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove('show'),2800)}}
const paths={
  select:'M5 3l12 9-6 1-3 6z',
  marquee:'M3 4h4v2H5v2H3V4zm14 0h4v4h-2V6h-2V4zM3 16h2v2h2v2H3v-4zm16 2h-2v2h4v-4h-2v2zM9 4h6v2H9V4zm0 14h6v2H9v-2zm-6-7h2v4H3v-4zm16 0h2v4h-2v-4z',
  wall:'M3 6l14-3v14L3 20z M7 6v12 M11 5v12 M15 4v12',
  door:'M4 20V4h3v16 M7 4a13 13 0 0113 13H7',
  window:'M3 7h18v10H3z M8 7v10 M16 7v10 M3 12h18',
  skylight:'M4 5l16 3v11l-16-3V5zm3 3.5l10 1.9v6.7l-10-1.9v-6.7z',
  roof:'M2 14L12 4l10 10 M5 12v8h14v-8 M12 4v10',
  shell:'M3 16c4-8 14-8 18 0M3 16l4 4c4-7 10-7 14 0l-4-4',
  beam:'M3 7l14-4 4 3-14 4z M3 7v10l4 4V10 M7 21l14-4V6',
  column:'M7 5l5-3 5 3v14l-5 3-5-3z M7 5l5 3 5-3 M12 8v14',
  slab:'M2 10l10-6 10 6-10 6z M2 10v4l10 6 10-6v-4 M12 16v4',
  stair:'M3 19h4v-3h4v-3h4v-3h4V7h2M3 19v3h18v-3',
  railing:'M3 6h18M3 18h18M5 6v12M9 6v12M13 6v12M17 6v12M21 6v12',
  curtainwall:'M3 4h18v16H3zm6 0v16m6-16v16M3 10h18M3 16h18',
  morph:'M4 18l5-12 11 3-5 12zM9 6l6 6m0 0l-1 6m1-6l5-3',
  mesh:'M3 17l6-6 6 4 6-9v12H3zM9 11l6 7M15 15l-6 4',
  zone:'M3 3h6 M15 3h6v6 M21 15v6h-6 M9 21H3v-6 M3 9V3 M9 9h6v6H9z',
  object:'M4 7h16v10H4zm2 10v3m12-3v3M4 11h16',
  dimension:'M4 3v18 M20 3v18 M4 12h16 M2 14l4-4 M18 14l4-4',
  leveldim:'M12 2l6 10h-5v10h-2V12H6zm0 4.5L8.5 10h7z',
  radialdim:'M12 21a9 9 0 119-9m-9 0l7-5m-3-1h4v4',
  angledim:'M4 20h16M4 20l12-14m-3 8a6 6 0 014 3',
  text:'M4 4h16 M12 4v16 M8 20h8',
  label:'M4 4h10l5 5v11H4zm9 0v5h5M7 11h6M7 15h8',
  fill:'M4 4h16v16H4zm3 3l10 10m-10 0l10-10M4 12h16M12 4v16',
  line:'M4 19L20 3 M2 19h4 M18 3h4',
  arc:'M3 19a15 15 0 0117-15 M1 19h4 M20 2v4',
  polyline:'M3 17l6-12 7 13 5-7 M2 17h2 M8 5h2 M15 18h2 M20 11h2',
  spline:'M3 17c4-12 8 14 12-2s4 6 6 1',
  section:'M3 3v18h18 M3 12h7V6h8v14 M8 10l4 4 M16 4l4 4',
  elevation:'M3 20h18 M5 20V9l7-6 7 6v11 M9 20v-7h6v7',
  detail:'M12 2a10 10 0 100 20 10 10 0 000-20zm-1 5h2v6h-2zm0 8h2v2h-2z',
  changemarker:'M12 3l9 16H3zm0 5v5m0 2v2',
  grid:'M4 4h16v16H4zm0 8h16M12 4v16M2 12a2 2 0 100-4 2 2 0 000 4zm10-10a2 2 0 10-4 0 2 2 0 004 0z',
  wallend:'M3 7h10a4 4 0 014 4 4 4 0 01-4 4H3zm15 1v6',
  cornerwin:'M3 3v15h15M3 10h8v8M10 3v8',
  lamp:'M12 3a6 6 0 00-6 6c0 2.5 2 4 3 5v2h6v-2c1-1 3-2.5 3-5a6 6 0 00-6-6zm-3 17h6v1H9z',
  camera:'M4 7h16v12H4zm3-3h10l2 3H5zm5 7a3 3 0 100 6 3 3 0 000-6z',
  pipette:'M19 3l2 2-2 2-2-2zm-3 3l2 2-9 9-4 1 1-4zm-7 9l2 2',
  syringe:'M18 4l2 2-3 3 1 1-2 2-1-1-4 4-2-2 4-4-1-1 2-2 1 1zM7 15l-4 4v1h1l4-4z',
  cube:'M3 7l9-5 9 5v10l-9 5-9-5z M3 7l9 5 9-5 M12 12v10',
  plan:'M3 3h18v18H3z M3 12h8V3 M11 12h10 M11 16v5',
  building:'M4 21V6h9v15 M13 10h7v11 M2 21h20 M7 9h3 M7 13h3 M7 17h3 M16 13h1 M16 17h1',
  save:'M4 3h13l3 3v15H4z M7 3v6h9V3 M8 21v-7h8v7',
  open:'M3 7h7l2 3h9v10H3z M3 10h18',
  export:'M12 15V3 M8 7l4-4 4 4 M4 13v7h16v-7',
  undo:'M7 4l-4 4 4 4 M3 8h10a7 7 0 010 14',
  redo:'M17 4l4 4-4 4 M21 8H11a7 7 0 000 14',
  move:'M12 2v20 M2 12h20 M9 5l3-3 3 3 M9 19l3 3 3-3 M5 9l-3 3 3 3 M19 9l3 3-3 3',
  copy:'M8 8h13v13H8z M16 8V3H3v13h5',
  rotate:'M4 8a9 9 0 111 10 M4 3v5h5',
  mirror:'M12 2v20 M3 6l6 6-6 6z M21 6l-6 6 6 6z',
  trash:'M3 6h18 M9 6V3h6v3 M5 6l1 15h12l1-15 M10 10v7 M14 10v7',
  snap:'M5 3v9a7 7 0 0014 0V3h-4v9a3 3 0 01-6 0V3z M5 7h4 M15 7h4',
  fit:'M3 9V3h6 M15 3h6v6 M21 15v6h-6 M9 21H3v-6',
  help:'M21 12a9 9 0 11-18 0 9 9 0 0118 0 M9 8a3 3 0 015 2c-1 1-2 1-2 3 M12 17h.01',
  layers:'M2 8l10-6 10 6-10 6z M2 12l10 6 10-6 M2 16l10 6 10-6',
  plus:'M12 5v14 M5 12h14',minus:'M5 12h14',
  hand:'M8 12V5a2 2 0 014 0v7 M12 5a2 2 0 014 0v7 M16 7a2 2 0 014 0v8c0 4-3 7-7 7-3 0-4-1-6-4l-4-5a2 2 0 013-2l2 2V7a2 2 0 014 0',
  link:'M10 14l4-4 M8 16l-2 2a4 4 0 01-6-6l5-5a4 4 0 016 0 M16 8l2-2a4 4 0 016 6l-5 5a4 4 0 01-6 0',
  table:'M3 3h18v18H3z M3 9h18 M3 15h18 M9 3v18',
  eye:'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12 M15 12a3 3 0 11-6 0 3 3 0 016 0',
  close:'M5 5l14 14 M19 5L5 19',
  circle:'M21 12a9 9 0 11-18 0 9 9 0 0118 0 M12 10v4 M10 12h4',
  rectangle:'M3 5h18v14H3z',
  coordinate:'M3 12h18 M12 3v18 M12 7a5 5 0 100 10 5 5 0 000-10z',
  target:'M12 2v4 M12 18v4 M2 12h4 M18 12h4 M12 6a6 6 0 100 12 6 6 0 000-12z'
};
function icon(name){return `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="${paths[name]||paths.cube}"/></svg>`}
function icons(root=document){root.querySelectorAll('[data-icon]').forEach(e=>{if(!e.querySelector('.icon'))e.insertAdjacentHTML('afterbegin',icon(e.dataset.icon))})}icons();
const toolGroups=[
  ['SELECT',
    ['select','Arrow','V'],
    ['marquee','Marquee','M']
  ],
  ['DESIGN',
    ['wall','Wall','W'],
    ['door','Door','D'],
    ['window','Window','N'],
    ['skylight','Skylight','K'],
    ['roof','Roof','R'],
    ['shell','Shell','H'],
    ['beam','Beam','B'],
    ['column','Column','C'],
    ['slab','Slab','F'],
    ['stair','Stair','S'],
    ['railing','Railing','J'],
    ['curtainwall','Curtain Wall','U'],
    ['morph','Morph','X'],
    ['mesh','Mesh','Y'],
    ['zone','Zone','Z'],
    ['object','Object','O']
  ],
  ['DOCUMENT',
    ['dimension','Dimension','Q'],
    ['leveldim','Level Dim',''],
    ['radialdim','Radial Dim',''],
    ['angledim','Angle Dim',''],
    ['text','Text','T'],
    ['label','Label',''],
    ['fill','Fill / Hatch','I'],
    ['line','Line','L'],
    ['arc','Arc / Circle','A'],
    ['polyline','Polyline','P'],
    ['spline','Spline',''],
    ['section','Section Marker',''],
    ['elevation','Elevation Marker',''],
    ['detail','Detail Marker',''],
    ['changemarker','Change Marker','']
  ],
  ['MORE',
    ['grid','Grid Element','G'],
    ['wallend','Wall End',''],
    ['cornerwin','Corner Window',''],
    ['lamp','Lamp',''],
    ['camera','Camera','']
  ]
];
$('#tools').innerHTML=toolGroups.map(([label,...ts])=>(label?`<div class="tool-group-label">${label}</div>`:'')+ts.map(([id,name,key])=>`<button class="tool ${id==='select'?'active':''}" data-tool="${id}" title="${name}${key?' · '+key:''}">${icon(id)}${name}<span class="shortcut">${key}</span></button>`).join('')).join('');
var clone=window.clone||(x=>JSON.parse(JSON.stringify(x))), distance=window.distance||((a,b)=>Math.hypot(a.x-b.x,a.y-b.y)), lerp=window.lerp||((a,b,t)=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t})), esc=window.esc||(s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])));
var layers=[{name:'Exterior Walls',color:'#537e69',visible:true},{name:'Interior Walls',color:'#8b9c82',visible:true},{name:'Structure',color:'#aaab8f',visible:true},{name:'Annotations',color:'#b7bcae',visible:true}];
var model={version:1,name:'Courtyard House',stories:[{id:'s0',name:'Ground floor',elevation:0,height:3048},{id:'s1',name:'First floor',elevation:3048,height:3048},{id:'s2',name:'Roof level',elevation:6096,height:1800}],elements:[],revision:0};
function wall(id,a,b,layer='Exterior Walls'){return {id,type:'wall',a:{x:a[0],y:a[1]},b:{x:b[0],y:b[1]},story:'s0',height:3048,followStory:true,thickness:layer==='Interior Walls'?120:200,material:'Timber',layer}}
model.elements=[wall('W-001',[0,0],[13000,0]),wall('W-002',[13000,0],[13000,9000]),wall('W-003',[13000,9000],[0,9000]),wall('W-004',[0,9000],[0,0]),wall('W-005',[4700,0],[4700,9000],'Interior Walls'),wall('W-006',[0,4800],[4700,4800],'Interior Walls'),wall('W-007',[4700,3400],[13000,3400],'Interior Walls'),wall('W-008',[8500,0],[8500,3400],'Interior Walls'),wall('W-009',[8500,3400],[8500,5700],'Interior Walls'),wall('W-010',[8500,5700],[13000,5700],'Interior Walls'),{id:'S-001',type:'slab',points:[{x:0,y:0},{x:13000,y:0},{x:13000,y:9000},{x:0,y:9000}],story:'s0',thickness:200,material:'Concrete',layer:'Structure'},
{id:'N-001',type:'window',host:'W-001',offset:2300,width:2000,height:1500,sill:900,story:'s0',material:'Glass',layer:'Exterior Walls'},{id:'N-002',type:'window',host:'W-001',offset:10700,width:2000,height:1500,sill:900,story:'s0',material:'Glass',layer:'Exterior Walls'},{id:'N-003',type:'window',host:'W-002',offset:1600,width:1800,height:1500,sill:900,story:'s0',material:'Glass',layer:'Exterior Walls'},{id:'N-004',type:'window',host:'W-002',offset:7400,width:2400,height:2100,sill:450,story:'s0',material:'Glass',layer:'Exterior Walls'},{id:'N-005',type:'window',host:'W-003',offset:5000,width:3000,height:2100,sill:450,story:'s0',material:'Glass',layer:'Exterior Walls'},{id:'N-006',type:'window',host:'W-004',offset:1900,width:1800,height:1500,sill:900,story:'s0',material:'Glass',layer:'Exterior Walls'},
{id:'D-001',type:'door',host:'W-003',offset:11200,width:1000,height:2200,sill:0,story:'s0',material:'Oak',layer:'Exterior Walls'},...['W-005','W-006','W-007','W-008','W-009'].map((host,i)=>({id:`D-00${i+2}`,type:'door',host,offset:[6500,3500,6100,1500,1100][i],width:900,height:2200,sill:0,story:'s0',material:'Oak',layer:'Interior Walls'})),
{id:'R-001',type:'roof',story:'s0',layer:'Structure',points:[{x:0,y:0},{x:13000,y:0},{x:13000,y:5700},{x:8500,y:5700},{x:8500,y:3400},{x:4700,y:3400},{x:4700,y:9000},{x:0,y:9000}],pitch:25,height:3048,overhang:450,thickness:200,roofType:'hip',roofFraming:{system:'trusses',spacing:600,hipSetback:1828.8,wingDirection:'branch',webPattern:'Auto',width:38,depth:89,webDepth:40,heel:150,panelCount:0,girderPlies:2}}];
for(const w of model.elements.filter(e=>e.type==='wall'&&e.layer==='Exterior Walls'))w.reference='outside';
model.elements=model.elements.filter(e=>e.type!=='object');
var selected=['W-003'],activeStory='s0',view='plan',tool='select',snap=true,grid=true,sectionCut=false,transparent=false,scale=1,pan={x:0,y:0},orbit=-.7,tilt=.62,points=[],hover=null,drag=null,space=false,editing=null,modelHistory=[],future=[],dirty=false;
function select(ids = []){
  selected = Array.isArray(ids) ? ids.filter(Boolean) : (ids ? [ids] : []);
  if (typeof render === 'function') render();
  if (typeof properties === 'function') properties();
  if (typeof navigatorPanel === 'function') navigatorPanel();
}
if (typeof window !== 'undefined') window.select = select;
var canvas=$('#canvas'),ctx=canvas?canvas.getContext('2d'):null;var width=0,height=0,baseScale=.05,projectedFaces=[],hits=[],lastPointer={x:0,y:0};
function storyOf(e){return model.stories.find(s=>s.id===e.story)||model.stories[0]}function heightOf(e){if(e.type==='roof'&&e.followStory)return storyOf(e).height+(e.roofOffset||0);if(e.type==='wall'&&e.followStory){const home=storyOf(e),top=model.stories.find(s=>s.id===e.topStory);return Math.max(10,(top?top.elevation:home.elevation+home.height)+(e.topOffset||0)-wallBase(e))}return e.followStory?storyOf(e).height:e.height||3000}function hostOf(e){return model.elements.find(w=>w.id===e.host)}function hosted(w){return model.elements.filter(e=>e.host===w.id)}function shown(e){return layers.find(l=>l.name===e.layer)?.visible!==false&&(view==='3d'||view==='framing3d'||e.story===activeStory)}
function checkpoint(){modelHistory.push(clone(model));if(modelHistory.length>80)modelHistory.shift();future=[]}function changed(){model.revision++;dirty=true;$('#save-state').textContent='Unsaved changes';render();properties();navigatorPanel();try{window.dispatchEvent(new Event('cadtech:modelChanged'))}catch(_){}}function commit(fn,propagate=true){const previous=clone(model),oldSelected=[...selected],oldFuture=[...future];checkpoint();try{fn();if(typeof autoAlignTrussRoofsToWallPlates==='function')autoAlignTrussRoofsToWallPlates();if(propagate)updateWallConnections(previous);validateWallGeometry();model.elements.filter(e=>e.type==='roof').forEach(validateRoof);model.elements.filter(e=>e.host).forEach(validateOpening);changed();return true}catch(error){model=previous;selected=oldSelected;modelHistory.pop();future=oldFuture;render();properties();toast(error.message);return false}}function undo(){if(!modelHistory.length)return;future.push(clone(model));model=modelHistory.pop();selected=selected.filter(id=>model.elements.some(e=>e.id===id));changed()}function redo(){if(!future.length)return;modelHistory.push(clone(model));model=future.pop();changed()}
var traceActive = true, pipetteActive = false, syringeActive = false, absorbedParams = null, trackerActive = true;
var toolGeomMethod = { wall: 'single', slab: 'poly', roof: 'poly', beam: 'single', column: 'square', zone: 'inner', object: 'Table & Chairs', dimension: 'linear', fill: 'diagonal45' };
var currentZoneCategory = 'Living Room', pendingOpening = null, wandActive = false;
function raySegmentIntersect(ro,rd,p1,p2){
  const v1={x:ro.x-p1.x,y:ro.y-p1.y},v2={x:p2.x-p1.x,y:p2.y-p1.y},v3={x:-rd.y,y:rd.x};
  const dot=v2.x*v3.x+v2.y*v3.y;if(Math.abs(dot)<1e-8)return null;
  const t1=(v2.x*v1.y-v2.y*v1.x)/dot,t2=(v1.x*v3.x+v1.y*v3.y)/dot;
  if(t1>1e-4&&t2>=0&&t2<=1)return {dist:t1,point:{x:ro.x+rd.x*t1,y:ro.y+rd.y*t1}};
  return null;
}
function floodRoom(q){
  const walls=model.elements.filter(e=>e.type==='wall'&&e.story===activeStory&&shown(e));
  if(!walls.length)return null;
  const numRays=72,rayPoints=[],maxDist=30000;
  for(let i=0;i<numRays;i++){
    const angle=(i*2*Math.PI)/numRays,dir={x:Math.cos(angle),y:Math.sin(angle)};
    let bestDist=maxDist,bestPoint=null;
    for(const w of walls){
      const poly=wallPoly(w);
      for(let j=0;j<poly.length;j++){
        const p1=poly[j],p2=poly[(j+1)%poly.length];
        const hit=raySegmentIntersect(q,dir,p1,p2);
        if(hit&&hit.dist>10&&hit.dist<bestDist){bestDist=hit.dist;bestPoint=hit.point}
      }
    }
    if(!bestPoint||bestDist>=maxDist-100)return null;
    rayPoints.push(bestPoint);
  }
  const simplified=[];
  for(let i=0;i<rayPoints.length;i++){
    const prev=rayPoints[(i+rayPoints.length-1)%rayPoints.length],curr=rayPoints[i],next=rayPoints[(i+1)%rayPoints.length];
    const d=segmentDistance(curr,prev,next).distance;
    if(d>45||!simplified.length)simplified.push(curr);
  }
  if(simplified.length<3)return null;
  let areaMm2=0;for(let i=0;i<simplified.length;i++){const a=simplified[i],b=simplified[(i+1)%simplified.length];areaMm2+=(a.x*b.y-b.x*a.y)}
  const areaM2=Math.abs(areaMm2)/2/1000000;if(areaM2<0.5)return null;
  const cx=simplified.reduce((s,p)=>s+p.x,0)/simplified.length,cy=simplified.reduce((s,p)=>s+p.y,0)/simplified.length;
  let name=currentZoneCategory||'Living Room';
  return {boundary:simplified,area:Math.round(areaM2*10)/10,center:{x:cx,y:cy},name};
}
function cylinderPolygon(center,r,segs=12){
  const pts=[];for(let i=0;i<segs;i++){const th=(i*2*Math.PI)/segs;pts.push({x:center.x+Math.cos(th)*r,y:center.y+Math.sin(th)*r})}
  return pts;
}
function unique(type){
  const prefix={
    wall:'W',window:'N',door:'D',skylight:'SK',roof:'R',shell:'SH',
    beam:'B',column:'C',slab:'S',stair:'ST',railing:'RL',curtainwall:'CW',
    morph:'MO',mesh:'MS',zone:'Z',object:'OBJ',
    line:'L',polyline:'P',circle:'O',arc:'A',rectangle:'REC',
    dimension:'DIM',leveldim:'LVL',radialdim:'RAD',angledim:'ANG',
    text:'TXT',label:'LBL',fill:'FIL',spline:'SPL',
    section:'SEC',elevation:'ELV',detail:'DTL',changemarker:'CHG',
    grid:'GRD',wallend:'WE',cornerwin:'CN',lamp:'LMP',camera:'CAM'
  }[type]||'E';
  let n=1;
  while(model.elements.some(e=>e.id===`${prefix}-${String(n).padStart(3,'0')}`))n++;
  return `${prefix}-${String(n).padStart(3,'0')}`;
}
function p2(p){return {x:width/2+(p.x-6500)*baseScale*scale+pan.x,y:height/2+(p.y-4500)*baseScale*scale+pan.y+20}}
function world(p){return {x:(p.x-width/2-pan.x)/(baseScale*scale)+6500,y:(p.y-height/2-pan.y-20)/(baseScale*scale)+4500}}
function snapped(p){return advancedSnap(p)}
function line(a,b,color='#687d6b',lw=1,dash=[]){ctx.strokeStyle=color;ctx.lineWidth=lw;ctx.setLineDash(dash);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.setLineDash([])}
function poly(ps,fill,stroke,lw=1){if(!ps.length)return;ctx.beginPath();ps.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();if(fill){ctx.fillStyle=fill;ctx.fill()}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=lw;ctx.stroke()}}
function label(t,x,y,size=10,color='#81917e',align='center'){ctx.fillStyle=color;ctx.font=`${size}px "DM Sans",Arial`;ctx.textAlign=align;ctx.textBaseline='middle';ctx.fillText(t,x,y)}
function rect(x,y,w,h,fill,stroke,lw=1){poly([{x,y},{x:x+w,y},{x:x+w,y:y+h},{x,y:y+h}],fill,stroke,lw)}
function segmentDistance(p,a,b){const dx=b.x-a.x,dy=b.y-a.y,l=dx*dx+dy*dy,t=l?Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/l)):0;return {distance:distance(p,lerp(a,b,t)),t,point:lerp(a,b,t)}}
function rawWallPoly(w,a=w.a,b=w.b,t=w.thickness){if(w.type==='wall'){a=wallCenterPoint(w,a);b=wallCenterPoint(w,b)}let len=distance(a,b)||1,n={x:-(b.y-a.y)/len*t/2,y:(b.x-a.x)/len*t/2};return [{x:a.x+n.x,y:a.y+n.y},{x:b.x+n.x,y:b.y+n.y},{x:b.x-n.x,y:b.y-n.y},{x:a.x-n.x,y:a.y-n.y}]}
function wallPoly(w,a=w.a,b=w.b,t=w.thickness){return joinedWallPolygon(w,a,b,t)}
function openingPoint(e){let w=hostOf(e);return w?wallCenterPoint(w,lerp(w.a,w.b,e.offset/distance(w.a,w.b))):null}
function inside(p,ps){let yes=false;for(let i=0,j=ps.length-1;i<ps.length;j=i++){let a=ps[i],b=ps[j];if(((a.y>p.y)!==(b.y>p.y))&&(p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x))yes=!yes}return yes}
function planPick(p){
  let q=world(p),best=null,bd=320/scale;
  const elems = [...model.elements.filter(shown)].sort((a,b)=>{
    const aIsOp = ['window','door','cornerwin','skylight'].includes(a.type);
    const bIsOp = ['window','door','cornerwin','skylight'].includes(b.type);
    if(aIsOp && !bIsOp) return -1;
    if(!aIsOp && bIsOp) return 1;
    return 0;
  });
  for(const e of elems){
    let d=Infinity;
    if(e.type==='window'||e.type==='door'||e.type==='cornerwin'||e.type==='skylight'){
      const z=openingPoint(e);
      if(z) d=Math.max(-10, distance(q,z)-(e.width||1200)/2);
    }else if(['wall','beam','line','dimension','stair','railing','curtainwall','grid'].includes(e.type)){
      const seg=e.type==='dimension'?resolveDimension(e):e;
      if(seg.a&&seg.b){
        d=e.type==='wall'&&(inside(q,wallPoly(e))||segmentDistance(q,seg.a,seg.b).distance<=e.thickness/2) ? 0 : segmentDistance(q,seg.a,seg.b).distance;
      }
    }else if(['column','object','lamp','camera','leveldim','detail','changemarker','label','wallend'].includes(e.type)&&e.a){
      d=distance(q,e.a);
    }else if(e.type==='circle'||e.type==='radialdim'){
      d=Math.abs(distance(q,e.a)-(e.radius||1500));
    }else if(e.type==='arc'||e.type==='angledim'){
      const ang=(Math.atan2(q.y-e.a.y,q.x-e.a.x)-(e.startAngle??0)+Math.PI*2)%(Math.PI*2);
      if(ang<=(e.sweep??Math.PI*1.5))d=Math.abs(distance(q,e.a)-(e.radius||1500));
    }else if(e.type==='text'){
      d=distance(q,e.a);
    }else if(e.points){
      for(let i=0;i<e.points.length;i++)d=Math.min(d,segmentDistance(q,e.points[i],e.points[(i+1)%e.points.length]).distance);
      if(inside(q,e.points))d=0;
    }
    if(d<bd){best=e;bd=d;}
  }
  return best;
}
function dim(a,b,offset,text){a=p2(a);b=p2(b);let dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy)||1,nx=-dy/len*offset,ny=dx/len*offset;let aa={x:a.x+nx,y:a.y+ny},bb={x:b.x+nx,y:b.y+ny};line(a,{x:aa.x+nx*.15,y:aa.y+ny*.15},'#a6b1a0',.65);line(b,{x:bb.x+nx*.15,y:bb.y+ny*.15},'#a6b1a0',.65);line(aa,bb,'#9ba894',.65);for(const p of [aa,bb])line({x:p.x-3,y:p.y+3},{x:p.x+3,y:p.y-3},'#7e8c76',.8);ctx.save();ctx.translate((aa.x+bb.x)/2,(aa.y+bb.y)/2);ctx.rotate(Math.atan2(dy,dx));ctx.fillStyle='#f7f9f6';ctx.fillRect(-22,-8,44,16);label(text||Math.round(distance(world(a),world(b))).toLocaleString('en-US'),0,0,9,'#8d9a84');ctx.restore()}
function furniture(){if(activeStory!=='s0')return;ctx.save();
const rooms=[['BEDROOM 01','18.6 m²',2350,3900],['LIVING ROOM','19.2 m²',2350,5500],['KITCHEN','12.4 m²',6600,2600],['BEDROOM 02','14.4 m²',10800,2750],['BATHROOM','9.9 m²',10800,5350],['DINING / LIVING','43.4 m²',6800,8300]];for(const [name,area,x,y] of rooms){let p=p2({x,y});label(name,p.x,p.y,8.5,'#82917b');label(area,p.x,p.y+15,8,'#a0aa97')}ctx.restore()}
function drawTraceReference(){
  if(!traceActive||view!=='plan')return;
  const refStory=model.stories.find(s=>s.id!==activeStory)||model.stories[0];
  if(!refStory||refStory.id===activeStory)return;
  ctx.save();
  ctx.globalAlpha=0.28;
  for(const e of model.elements.filter(e=>e.story===refStory.id)){
    if(e.type==='wall'||e.type==='beam'){
      poly(wallPoly(e).map(p2),'#fed7aa','#ea580c',0.8);
    }else if(e.type==='slab'&&e.points){
      poly(e.points.map(p2),'#ffedd5','#ea580c',0.8);
    }else if(e.type==='column'&&e.a){
      const p=p2(e.a),r=(e.thickness||300)*baseScale*scale;
      rect(p.x-r/2,p.y-r/2,r,r,'#fed7aa','#ea580c',0.8);
    }else if(e.a&&e.b){
      line(p2(e.a),p2(e.b),'#ea580c',0.8,[5,3]);
    }
  }
  ctx.restore();
}
function drawPlan(){
  const s=baseScale*scale;
  drawTraceReference();
  let slabs=model.elements.filter(e=>shown(e)&&e.type==='slab');
  for(const e of slabs)poly(defaultSlabPolygon(e).map(p2),selected.includes(e.id)?'#e4eee4':'#fafbf7','#d5decf',1);
  if(activeStory==='s0'){
    let a=p2({x:0,y:9250}),b=p2({x:13000,y:10900});rect(a.x,a.y,b.x-a.x,b.y-a.y,'#eff3e9','#d5dfce',.8);
    for(let x=100;x<13000;x+=300)line(p2({x,y:9250}),p2({x,y:10900}),'#dde4d5',.5);
    label('TIMBER DECK',width/2+pan.x,p2({x:0,y:10300}).y,8,'#97a58a');
  }
  furniture();renderJoinedPlanWalls();
  for(const e of model.elements.filter(shown)){
    let sel=selected.includes(e.id),color=sel?'#426e59':'#74866a';
    if(e.type==='wall'||e.type==='beam'){
      if(e.type==='beam')poly(wallPoly(e).map(p2),sel?'#a8c2ab':'#bdc8ad',color,sel?1.5:1);
      for(const o of hosted(e).filter(shown)){
        const len=distance(e.a,e.b),a=lerp(e.a,e.b,(o.offset-o.width/2)/len),b=lerp(e.a,e.b,(o.offset+o.width/2)/len);
        const ps=wallPoly(e,a,b,e.thickness*.65).map(p2),oc=selected.includes(o.id)?'#285c47':'#80957a';
        if(o.type==='window'||o.type==='cornerwin'){
          poly(ps,'#edf2e9',oc,.8);line(p2(wallCenterPoint(e,a)),p2(wallCenterPoint(e,b)),oc,.7);line(ps[0],ps[3],oc,.7);line(ps[1],ps[2],oc,.7);
        }else{
          const pa=p2(wallCenterPoint(e,a)),pb=p2(wallCenterPoint(e,b)),ang=Math.atan2(pb.y-pa.y,pb.x-pa.x);
          ctx.beginPath();ctx.arc(pa.x,pa.y,o.width*s,ang-Math.PI/2,ang);ctx.strokeStyle=oc;ctx.lineWidth=.8;ctx.stroke();
          line(pa,{x:pa.x+Math.cos(ang-Math.PI/2)*o.width*s,y:pa.y+Math.sin(ang-Math.PI/2)*o.width*s},oc,.8);
        }
      }
      if(sel){
        if(e.type==='wall')line(p2(e.a),p2(e.b),'#4c8765',.8,[4,3]);
        for(const p of [p2(e.a),p2(e.b)])rect(p.x-3,p.y-3,6,6,'#fff','#426e59',1.2);
        let mid=p2(lerp(e.a,e.b,.5));$('#selection-tip').style.cssText=`display:block;left:${mid.x-27}px;top:${mid.y+14}px`;$('#selection-tip').textContent=e.id;
      }
    }else if(e.type==='stair'&&e.a&&e.b){
      const w=e.width||1000,len=distance(e.a,e.b)||1,u={x:(e.b.x-e.a.x)/len,y:(e.b.y-e.a.y)/len},n={x:-u.y,y:u.x};
      const c1={x:e.a.x-n.x*w/2,y:e.a.y-n.y*w/2},c2={x:e.b.x-n.x*w/2,y:e.b.y-n.y*w/2},c3={x:e.b.x+n.x*w/2,y:e.b.y+n.y*w/2},c4={x:e.a.x+n.x*w/2,y:e.a.y+n.y*w/2};
      poly([c1,c2,c3,c4].map(p2),sel?'#e0ece1':'#f4f6f2',color,sel?2:1.2);
      const risers=e.risers||16;
      for(let i=1;i<risers;i++){const t1=lerp(c1,c2,i/risers),t2=lerp(c4,c3,i/risers);line(p2(t1),p2(t2),color,0.75)}
      line(p2(e.a),p2(e.b),color,1.2);
      const head=p2(e.b);ctx.beginPath();ctx.arc(head.x,head.y,3.5,0,7);ctx.fillStyle=color;ctx.fill();
      const mid=p2(lerp(e.a,e.b,0.5));label(`${risers} risers @ ${(e.riserHeight||190.5).toFixed(1)}mm`,mid.x,mid.y-12,8,color);
      if(sel)for(const p of [p2(e.a),p2(e.b)])rect(p.x-3,p.y-3,6,6,'#fff',color,1.2);
    }else if(e.type==='railing'&&e.a&&e.b){
      line(p2(e.a),p2(e.b),color,sel?2.5:1.6);
      const len=distance(e.a,e.b),cnt=Math.max(1,Math.floor(len/250));
      for(let i=0;i<=cnt;i++){const pt=p2(lerp(e.a,e.b,i/cnt));rect(pt.x-2,pt.y-2,4,4,color,color)}
      if(sel)for(const p of [p2(e.a),p2(e.b)])rect(p.x-3,p.y-3,6,6,'#fff',color,1.2);
    }else if(e.type==='curtainwall'&&e.a&&e.b){
      const w=e.thickness||120,len=distance(e.a,e.b)||1,n={x:-(e.b.y-e.a.y)/len*w/2,y:(e.b.x-e.a.x)/len*w/2};
      const ps=[{x:e.a.x+n.x,y:e.a.y+n.y},{x:e.b.x+n.x,y:e.b.y+n.y},{x:e.b.x-n.x,y:e.b.y-n.y},{x:e.a.x-n.x,y:e.a.y-n.y}];
      poly(ps.map(p2),sel?'#bae6fd80':'#e0f2fe60',color,sel?2:1.2);
      line(p2(e.a),p2(e.b),'#0284c7',1);
      const panels=Math.max(1,Math.floor(len/(e.panelWidth||1200)));
      for(let i=1;i<panels;i++){const pA=lerp(ps[0],ps[1],i/panels),pB=lerp(ps[3],ps[2],i/panels);line(p2(pA),p2(pB),color,1.2)}
      if(sel)for(const p of [p2(e.a),p2(e.b)])rect(p.x-3,p.y-3,6,6,'#fff',color,1.2);
    }else if(e.type==='grid'&&e.a&&e.b){
      line(p2(e.a),p2(e.b),color,1,[10,5]);
      for(const pt of [p2(e.a),p2(e.b)]){
        ctx.beginPath();ctx.arc(pt.x,pt.y,12,0,7);ctx.fillStyle='#fff';ctx.fill();ctx.strokeStyle=color;ctx.lineWidth=1.2;ctx.stroke();
        label(e.bubble||'A',pt.x,pt.y,9,color);
      }
    }else if(e.type==='leveldim'&&e.a){
      const p=p2(e.a);
      ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x-6,p.y-10);ctx.lineTo(p.x+6,p.y-10);ctx.closePath();
      ctx.fillStyle=sel?'#3b82f6':color;ctx.fill();
      line({x:p.x-12,y:p.y-10},{x:p.x+12,y:p.y-10},color,1.2);
      label(`▼ +${(e.targetHeight??storyOf(e).elevation).toLocaleString()} mm`,p.x+16,p.y-10,9,color,'left');
    }else if(e.type==='radialdim'&&e.a){
      const p=p2(e.a),r=(e.radius||1500)*s;
      ctx.beginPath();ctx.arc(p.x,p.y,r,0,Math.PI*0.35);ctx.strokeStyle=color;ctx.stroke();
      line(p,{x:p.x+r*Math.cos(0.2),y:p.y+r*Math.sin(0.2)},color,1);
      label(`R ${(e.radius||1500).toLocaleString()}`,p.x+r*0.6,p.y+r*0.3,9,color);
    }else if(e.type==='angledim'&&e.a){
      const p=p2(e.a);
      ctx.beginPath();ctx.arc(p.x,p.y,30,0,Math.PI/2);ctx.strokeStyle=color;ctx.stroke();
      line(p,{x:p.x+40,y:p.y},color,1);line(p,{x:p.x,y:p.y+40},color,1);
      label(`${e.angle||90}°`,p.x+20,p.y+20,9,color);
    }else if(e.type==='label'&&e.a){
      const p=p2(e.a);
      line(p,{x:p.x+25,y:p.y-15},color,1);line({x:p.x+25,y:p.y-15},{x:p.x+90,y:p.y-15},color,1);
      label(e.text||'Element',p.x+30,p.y-22,9,color,'left');
    }else if(e.type==='detail'&&e.a){
      const p=p2(e.a),r=(e.radius||800)*s;
      ctx.beginPath();ctx.arc(p.x,p.y,r,0,7);ctx.strokeStyle=color;ctx.setLineDash([5,3]);ctx.stroke();ctx.setLineDash([]);
      ctx.beginPath();ctx.arc(p.x+r+10,p.y-r-10,12,0,7);ctx.fillStyle='#fff';ctx.fill();ctx.strokeStyle=color;ctx.stroke();
      label(e.code||'D-01',p.x+r+10,p.y-r-10,8,color);
    }else if(e.type==='changemarker'&&e.a){
      const p=p2(e.a);
      ctx.beginPath();ctx.moveTo(p.x,p.y-10);ctx.lineTo(p.x+10,p.y+8);ctx.lineTo(p.x-10,p.y+8);ctx.closePath();
      ctx.fillStyle=sel?'#f59e0b':'#fef3c7';ctx.fill();ctx.strokeStyle=color;ctx.stroke();
      label(e.changeNumber||'CH-01',p.x+15,p.y,8,color,'left');
    }else if(e.type==='wallend'&&e.a){
      const p=p2(e.a);ctx.beginPath();ctx.arc(p.x,p.y,8,0,7);ctx.fillStyle=color;ctx.fill();
    }else if(e.type==='lamp'&&e.a){
      const p=p2(e.a);ctx.beginPath();ctx.arc(p.x,p.y,7,0,7);ctx.fillStyle='#fef08a';ctx.fill();ctx.strokeStyle=color;ctx.stroke();
      line({x:p.x-6,y:p.y-6},{x:p.x+6,y:p.y+6},color,1);line({x:p.x-6,y:p.y+6},{x:p.x+6,y:p.y-6},color,1);
    }else if(e.type==='camera'&&e.a){
      const p=p2(e.a);rect(p.x-7,p.y-5,14,10,'#334155',color);
      line(p,{x:p.x+40,y:p.y-25},'#64748b',0.8,[3,3]);line(p,{x:p.x+40,y:p.y+25},'#64748b',0.8,[3,3]);
      label('CAM',p.x,p.y+14,7.5,color);
    }else if(e.type==='object'&&e.a){
      const p=p2(e.a),w=(e.width||1600)*s,d=(e.depth||900)*s,sub=e.subtype||'Table & Chairs';
      if(sub==='Table & Chairs'){
        rect(p.x-w/2,p.y-d/2,w,d,sel?'#cbd5e1':'#f5f7f2',color,1.2);
        const cw=w/3.6,cd=Math.max(6,d*0.22);
        for(let i=0;i<3;i++){
          rect(p.x-w/2+i*(w/2.8)+6,p.y-d/2-cd-2,cw,cd,'#fff',color,0.8);
          rect(p.x-w/2+i*(w/2.8)+6,p.y+d/2+2,cw,cd,'#fff',color,0.8);
        }
      }else if(sub==='Living Sofa Set'){
        rect(p.x-w/2,p.y-d/2,w,d,sel?'#cbd5e1':'#eaf0e6',color,1.2);
        rect(p.x-w/2+4,p.y-d/2+3,w-8,d*0.3,'#dfe8da',color,0.8);
        for(let i=1;i<3;i++)line({x:p.x-w/2+i*(w/3),y:p.y-d/2+d*0.3},{x:p.x-w/2+i*(w/3),y:p.y+d/2-3},color,0.7);
      }else if(sub==='Double Bed'){
        rect(p.x-w/2,p.y-d/2,w,d,sel?'#cbd5e1':'#fafbf7',color,1.2);
        rect(p.x-w/2,p.y-d/2,w,Math.max(8,d*0.14),'#dce5d8',color,1);
        rect(p.x-w/2+10,p.y-d/2+15,w/2.4,d*0.22,'#f0f4ec',color,0.7);
        rect(p.x+4,p.y-d/2+15,w/2.4,d*0.22,'#f0f4ec',color,0.7);
        line({x:p.x-w/2,y:p.y-d/2+d*0.48},{x:p.x+w/2,y:p.y-d/2+d*0.48},color,0.8);
      }else if(sub==='Office Desk'){
        rect(p.x-w/2,p.y-d/2,w,d,sel?'#cbd5e1':'#f5f7f2',color,1.2);
        line({x:p.x-18,y:p.y-d/4},{x:p.x+18,y:p.y-d/4},'#334155',1.8);
        ctx.beginPath();ctx.arc(p.x,p.y+d/4,12*s*10,0,7);ctx.strokeStyle=color;ctx.stroke();
      }else if(sub==='Kitchen Counter'){
        rect(p.x-w/2,p.y-d/2,w,d,sel?'#cbd5e1':'#e8ece3',color,1.2);
        rect(p.x-w/3,p.y-d/3,w/4,d*0.65,'#fff',color,0.8);
        rect(p.x-w/3+w/4+4,p.y-d/3,w/4,d*0.65,'#fff',color,0.8);
        for(const [bx,by] of [[p.x+w/4-8,p.y-8],[p.x+w/4+8,p.y-8],[p.x+w/4-8,p.y+8],[p.x+w/4+8,p.y+8]]){
          ctx.beginPath();ctx.arc(bx,by,4,0,7);ctx.strokeStyle='#475569';ctx.stroke();
        }
      }else if(sub==='Bathroom WC'){
        rect(p.x-w/2+8,p.y-d/2,w-16,d*0.3,'#fff',color,1);
        ctx.beginPath();ctx.ellipse(p.x,p.y+4,w*0.32,d*0.38,0,0,7);ctx.fillStyle='#fff';ctx.fill();ctx.strokeStyle=color;ctx.stroke();
      }else{
        rect(p.x-w/2,p.y-d/2,w,d,sel?'#cbd5e1':'#e2e8f0',color,1.2);
      }
      label(sub,p.x,p.y,7.5,color);
    }else if(e.type==='skylight'&&e.a){
      const p=p2(e.a),w=(e.width||1000)*s,l=(e.length||1400)*s;
      rect(p.x-w/2,p.y-l/2,w,l,'#bae6fd80',sel?'#0284c7':'#0369a1',1.2);
      line({x:p.x-w/2,y:p.y},{x:p.x+w/2,y:p.y},'#0284c7',0.8);line({x:p.x,y:p.y-l/2},{x:p.x,y:p.y+l/2},'#0284c7',0.8);
      label('Skylight',p.x,p.y+l/2+8,7.5,'#0369a1');
    }else if(e.type==='zone'&&e.points){
      poly(e.points.map(p2),'#e8f5e940',sel?'#2e7d32':'#81c784',sel?2:1);
      const cx=e.center?p2(e.center):p2({x:e.points.reduce((s,p)=>s+p.x,0)/e.points.length,y:e.points.reduce((s,p)=>s+p.y,0)/e.points.length});
      rect(cx.x-44,cx.y-24,88,48,'#ffffffeb',sel?'#2e7d32':'#718e7b',1.2);
      label(e.roomName||'LIVING ROOM',cx.x,cx.y-13,8.5,'#1b5e20','center');
      label(`No. ${e.zoneNumber||'01'}`,cx.x,cx.y-2,7.5,'#558b2f','center');
      label(`${e.areaM2?e.areaM2.toFixed(1)+' m²':'—'}`,cx.x,cx.y+9,8,'#2e7d32','center');
      label(`FL: +${storyOf(e).elevation}`,cx.x,cx.y+19,7,'#78909c','center');
    }else if(e.type==='fill'&&e.points){
      poly(e.points.map(p2),e.backgroundColor||'#eef3eb',color,sel?2:1);
      const pts=e.points.map(p2),minX=Math.min(...pts.map(p=>p.x)),maxX=Math.max(...pts.map(p=>p.x)),minY=Math.min(...pts.map(p=>p.y)),maxY=Math.max(...pts.map(p=>p.y));
      ctx.save();ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.clip();
      ctx.strokeStyle=color;ctx.lineWidth=0.7;
      const hType=e.hatchType||'diagonal45';
      if(hType==='cross'){
        for(let x=minX-maxY+minY;x<maxX+maxY-minY;x+=12){ctx.beginPath();ctx.moveTo(x,minY);ctx.lineTo(x+maxY-minY,maxY);ctx.stroke()}
        for(let x=minX-maxY+minY;x<maxX+maxY-minY;x+=12){ctx.beginPath();ctx.moveTo(x,maxY);ctx.lineTo(x+maxY-minY,minY);ctx.stroke()}
      }else if(hType!=='solid'){
        for(let x=minX-maxY+minY;x<maxX+maxY-minY;x+=12){ctx.beginPath();ctx.moveTo(x,minY);ctx.lineTo(x+maxY-minY,maxY);ctx.stroke()}
      }
      ctx.restore();
    }else if(e.type==='morph'&&e.points){
      poly(e.points.map(p2),sel?'#cbd5e180':'#e2e8f050',color,sel?2:1.2);
      const pts=e.points.map(p2),cx=pts.reduce((a,p)=>a+p.x,0)/pts.length,cy=pts.reduce((a,p)=>a+p.y,0)/pts.length;
      for(const p of pts)line({x:cx,y:cy},p,color,0.5,[3,3]);
      if(sel)for(const p of pts)rect(p.x-3,p.y-3,6,6,'#fff',color,1.2);
    }else if(e.type==='mesh'&&e.points){
      poly(e.points.map(p2),sel?'#bbf7d080':'#dcfce750',color,sel?2:1.2);
      label(`Topo +${e.elevation||0}`,p2(e.points[0]).x,p2(e.points[0]).y-10,8,color);
      if(sel)for(const p of e.points.map(p2))rect(p.x-3,p.y-3,6,6,'#fff',color,1.2);
    }else if(e.type==='spline'&&e.points){
      if(e.points.length>1){
        const pts=e.points.map(p2);ctx.beginPath();ctx.moveTo(pts[0].x,pts[0].y);
        for(let i=1;i<pts.length;i++){const mid={x:(pts[i-1].x+pts[i].x)/2,y:(pts[i-1].y+pts[i].y)/2};ctx.quadraticCurveTo(pts[i-1].x,pts[i-1].y,mid.x,mid.y)}
        ctx.lineTo(pts.at(-1).x,pts.at(-1).y);ctx.strokeStyle=color;ctx.lineWidth=sel?2:1.2;ctx.stroke();
      }
      if(sel)for(const p of e.points.map(p2))rect(p.x-3,p.y-3,6,6,'#fff',color,1.2);
    }else if(['line','dimension'].includes(e.type)){
      if(e.type==='dimension'){
        const d=resolveDimension(e);dim(d.a,d.b,(e.offset??600)*baseScale*scale);
        if(!d.resolved){const p=p2(lerp(d.a,d.b,.5));label('Detached anchor',p.x,p.y+18,8,'#a18258')}
      }else{
        line(p2(e.a),p2(e.b),color,sel?2:1);
        if(sel)for(const p of [p2(e.a),p2(e.b)])rect(p.x-3,p.y-3,6,6,'white','#426e59',1.2);
      }
    }else if(e.type==='column'){
      const p=p2(e.a),r=(e.thickness||300)*s;
      if(e.columnProfile==='circle'){
        ctx.beginPath();ctx.arc(p.x,p.y,r/2,0,7);ctx.fillStyle=sel?'#9fb89f':'#c0cab6';ctx.fill();ctx.strokeStyle=color;ctx.lineWidth=sel?2:1;ctx.stroke();
        line({x:p.x-r/2,y:p.y},{x:p.x+r/2,y:p.y},color,0.6);line({x:p.x,y:p.y-r/2},{x:p.x,y:p.y+r/2},color,0.6);
      }else{
        rect(p.x-r/2,p.y-r/2,r,r,sel?'#9fb89f':'#c0cab6',color,1);
      }
    }else if(e.type==='circle'||e.type==='arc'){
      const p=p2(e.a);ctx.beginPath();
      ctx.arc(p.x,p.y,e.radius*s,e.type==='arc'?(e.startAngle??0):0,e.type==='arc'?(e.startAngle??0)+(e.sweep??Math.PI*1.5):Math.PI*2);
      ctx.strokeStyle=color;ctx.lineWidth=sel?2:1;ctx.stroke();
    }else if(e.type==='text'){
      const p=p2(e.a);label(e.text,p.x,p.y,12,color,'left');
    }else if(e.type==='polyline'){
      for(let i=1;i<e.points.length;i++)line(p2(e.points[i-1]),p2(e.points[i]),color,sel?2:1);
    }else if(e.type==='roof'){
      drawRoofPlan(e,sel);
    }else if(e.points&&e.type!=='slab'&&e.type!=='zone'){
      poly(e.points.map(p2),e.type==='roof'?'#e9e8db':null,color,sel?2:1);
      if(e.type==='roof'){line(p2(e.points[0]),p2(e.points[2]),'#a9ae96',.7)}
    }
  }
  if(pendingOpening&&hover){
    const w=hostOf(pendingOpening);
    if(w){
      const len=distance(w.a,w.b)||1,u={x:(w.b.x-w.a.x)/len,y:(w.b.y-w.a.y)/len},n={x:-u.y,y:u.x};
      const opCenter=lerp(w.a,w.b,pendingOpening.offset/len);
      const dotN=(hover.x-opCenter.x)*n.x+(hover.y-opCenter.y)*n.y,dotU=(hover.x-opCenter.x)*u.x+(hover.y-opCenter.y)*u.y;
      const flipped=dotN<0,hand=dotU>0?'right':'left',pa=p2(opCenter);
      ctx.save();ctx.strokeStyle='#0284c7';ctx.lineWidth=1.5;ctx.setLineDash([4,3]);
      const ang=Math.atan2(w.b.y-w.a.y,w.b.x-w.a.x)+(flipped?Math.PI:0);
      ctx.beginPath();ctx.arc(pa.x,pa.y,pendingOpening.width*s,ang-(hand==='right'?Math.PI/2:-Math.PI/2),ang);ctx.stroke();
      ctx.restore();
      label(`Opening swing: ${flipped?'Interior':'Exterior'} / ${hand==='right'?'Right':'Left'} (Click to confirm)`,pa.x,pa.y-18,9,'#0284c7');
    }
  }
  if(activeStory==='s0'&&layers[3].visible){
    for(const [id,offset] of [['W-001',-43],['W-004',39]]){
      const w=model.elements.find(e=>e.id===id&&e.type==='wall');if(w)dim(w.a,w.b,offset,fmt(distance(w.a,w.b)))
    }
    let a=p2({x:-1600,y:sectionPlaneY()}),b=p2({x:14200,y:sectionPlaneY()});line(a,b,'#a2b49a',.65,[6,5]);
    for(const p of [a,b]){ctx.beginPath();ctx.arc(p.x,p.y,10,0,7);ctx.fillStyle='#f7f9f6';ctx.fill();ctx.strokeStyle='#9fae97';ctx.stroke();label('A',p.x,p.y,8,'#86957e')}
  }
}
function project3(p){return cameraProject(p)}
const materials={
  Timber:['#d0c4a5','#b6ab8d','#e2dac4'],
  Concrete:['#c6cec4','#acb8ae','#e4e8e0'],
  Oak:['#c2a482','#a88e6b','#dcc5a5'],
  Glass:['#b1c8c5','#8faeab','#d4e4df'],
  Steel:['#94a3b8','#64748b','#cbd5e1'],
  Brick:['#b91c1c','#991b1b','#f87171'],
  Stone:['#78716c','#57534e','#a8a29e']
};
function prism(id,ps,z0,z1,material){
  const clipped=clipSolidGeometry(ps,z0,z1);if(!clipped)return;({ps,z0,z1}=clipped);ps=cleanPolygon(ps);
  const colors=materials[material]||materials.Timber,top=ps.map(p=>({...p,z:z1})),bottom=ps.map(p=>({...p,z:z0}));
  function face(world,color){const points=world.map(project3);projectedFaces.push({id,points,world,cutSurface:isCutFace(world),depth:points.reduce((a,p)=>a+p.depth,0)/points.length,color})}
  face(top,colors[2]);face([...bottom].reverse(),colors[1]);
  for(let i=0;i<ps.length;i++){let j=(i+1)%ps.length;face([bottom[i],bottom[j],top[j],top[i]],i%2?colors[0]:colors[1])}
}
function defaultSlabPolygon(s) {
  if (s && s.points && Array.isArray(s.points) && s.points.length >= 3) return s.points;
  if (s && s.a && s.b) {
    return [
      { x: Math.min(s.a.x, s.b.x), y: Math.min(s.a.y, s.b.y) },
      { x: Math.max(s.a.x, s.b.x), y: Math.min(s.a.y, s.b.y) },
      { x: Math.max(s.a.x, s.b.x), y: Math.max(s.a.y, s.b.y) },
      { x: Math.min(s.a.x, s.b.x), y: Math.max(s.a.y, s.b.y) }
    ];
  }
  // Align default slab polygon to exterior wall framing outer boundary if walls exist
  const story = s?.story || activeStory;
  const extWalls = model.elements.filter(e => e.type === 'wall' && (e.story === story || !e.story) && e.layer === 'Exterior Walls');
  if (extWalls.length >= 3) {
    const pts = [];
    for (const w of extWalls) {
      pts.push(w.a, w.b);
    }
    const xs = pts.map(p => p.x), ys = pts.map(p => p.y);
    return [
      { x: Math.min(...xs), y: Math.min(...ys) },
      { x: Math.max(...xs), y: Math.min(...ys) },
      { x: Math.max(...xs), y: Math.max(...ys) },
      { x: Math.min(...xs), y: Math.max(...ys) }
    ];
  }
  return [
    { x: 0, y: 0 },
    { x: 13000, y: 0 },
    { x: 13000, y: 9000 },
    { x: 0, y: 9000 }
  ];
}

function generateFloorFramingForSlab(s) {
  if (!s || s.type !== 'slab') return [];
  const pts = defaultSlabPolygon(s);
  if (pts.length < 3) return [];

  const thickness = Number(s.thickness) || 200;
  const joistDepth = thickness;
  const rimWidth = 45;
  const joistWidth = 45;
  const girderWidth = 90;
  const spacing = Number(s.joistSpacing) || 406.4;
  const members = [];

  // Compute centroid of slab polygon to orient rim board inward
  const cx = pts.reduce((a, p) => a + p.x, 0) / pts.length;
  const cy = pts.reduce((a, p) => a + p.y, 0) / pts.length;

  // 1. Rim Boards along perimeter
  for (let i = 0; i < pts.length; i++) {
    const p1 = pts[i];
    const p2 = pts[(i + 1) % pts.length];
    const len = Math.hypot(p2.x - p1.x, p2.y - p1.y);
    if (len > 10) {
      members.push({
        id: `${s.id}:RIM-${i + 1}`,
        slabId: s.id,
        type: 'Rim board',
        a: { x: p1.x, y: p1.y },
        b: { x: p2.x, y: p2.y },
        width: rimWidth,
        depth: joistDepth,
        z0: -thickness,
        z1: 0,
        length: len,
        center: { x: cx, y: cy },
        section: 'Rim Board 1-1/8x11-7/8'
      });
    }
  }

  // 2. Corner Floor Framing Studs / Corner Backing Blocks directly below Wall Corner Studs
  for (let i = 0; i < pts.length; i++) {
    const pCurr = pts[i];
    const pPrev = pts[(i + pts.length - 1) % pts.length];
    const pNext = pts[(i + 1) % pts.length];

    const dirPrev = { x: Math.sign(pPrev.x - pCurr.x), y: Math.sign(pPrev.y - pCurr.y) };
    const dirNext = { x: Math.sign(pNext.x - pCurr.x), y: Math.sign(pNext.y - pCurr.y) };

    members.push({
      id: `${s.id}:CRN-${i + 1}`,
      slabId: s.id,
      type: 'Corner stud',
      a: { x: pCurr.x, y: pCurr.y },
      b: { x: pCurr.x + (dirPrev.x + dirNext.x) * rimWidth, y: pCurr.y + (dirPrev.y + dirNext.y) * rimWidth },
      width: joistWidth,
      depth: joistDepth,
      z0: -thickness,
      z1: 0,
      length: Math.hypot((dirPrev.x + dirNext.x) * rimWidth, (dirPrev.y + dirNext.y) * rimWidth) || 140,
      section: '3-Stud Corner Rim Block'
    });
  }

  const xs = pts.map(p => p.x), ys = pts.map(p => p.y);
  const minX = Math.min(...xs), maxX = Math.max(...xs);
  const minY = Math.min(...ys), maxY = Math.max(...ys);
  const widthX = maxX - minX, lengthY = maxY - minY;

  const spanAlongY = s.joistDirection === 'Y' || (s.joistDirection !== 'X' && widthX >= lengthY);
  let joistCount = 0;

  if (spanAlongY) {
    const hasGirder = widthX > 4800;
    const midY = (minY + maxY) / 2;

    if (hasGirder) {
      members.push({
        id: `${s.id}:GIRDER-1`,
        slabId: s.id,
        type: 'Floor beam',
        a: { x: minX + rimWidth, y: midY },
        b: { x: maxX - rimWidth, y: midY },
        width: girderWidth,
        depth: joistDepth,
        z0: -thickness,
        z1: 0,
        length: widthX - 2 * rimWidth,
        section: '2-Ply LVL 1-3/4x11-7/8'
      });
    }

    for (let x = minX + spacing; x < maxX - spacing / 2; x += spacing) {
      const intersects = [];
      for (let i = 0; i < pts.length; i++) {
        const p1 = pts[i], p2 = pts[(i + 1) % pts.length];
        if (Math.abs(p1.x - p2.x) < 1e-5) continue;
        if ((p1.x <= x && p2.x > x) || (p2.x <= x && p1.x > x)) {
          const yInt = p1.y + (p2.y - p1.y) * (x - p1.x) / (p2.x - p1.x);
          intersects.push(yInt);
        }
      }
      intersects.sort((a, b) => a - b);
      for (let k = 0; k < intersects.length - 1; k += 2) {
        let y0 = intersects[k] + rimWidth, y1 = intersects[k + 1] - rimWidth;

        if (hasGirder && y0 < midY && y1 > midY) {
          // Bay 1
          const y1a = midY - girderWidth / 2;
          if (y1a - y0 > 100) {
            joistCount++;
            members.push({
              id: `${s.id}:FJ-${String(joistCount).padStart(3, '0')}`,
              slabId: s.id,
              type: 'Floor joist',
              a: { x, y: y0 },
              b: { x, y: y1a },
              width: joistWidth,
              depth: joistDepth,
              z0: -thickness,
              z1: 0,
              length: y1a - y0,
              section: 'I-Joist 11-7/8'
            });

            if (y1a - y0 > 2400) {
              const bY = (y0 + y1a) / 2;
              const xNext = Math.min(maxX - rimWidth, x + spacing);
              members.push({
                id: `${s.id}:BLK-${joistCount}`,
                slabId: s.id,
                type: 'Blocking',
                a: { x, y: bY },
                b: { x: xNext, y: bY },
                width: joistWidth,
                depth: joistDepth,
                z0: -thickness,
                z1: 0,
                length: xNext - x,
                section: 'I-Joist Blocking'
              });
            }
          }

          // Bay 2
          const y0b = midY + girderWidth / 2;
          if (y1 - y0b > 100) {
            joistCount++;
            members.push({
              id: `${s.id}:FJ-${String(joistCount).padStart(3, '0')}`,
              slabId: s.id,
              type: 'Floor joist',
              a: { x, y: y0b },
              b: { x, y: y1 },
              width: joistWidth,
              depth: joistDepth,
              z0: -thickness,
              z1: 0,
              length: y1 - y0b,
              section: 'I-Joist 11-7/8'
            });

            if (y1 - y0b > 2400) {
              const bY = (y0b + y1) / 2;
              const xNext = Math.min(maxX - rimWidth, x + spacing);
              members.push({
                id: `${s.id}:BLK-${joistCount}`,
                slabId: s.id,
                type: 'Blocking',
                a: { x, y: bY },
                b: { x: xNext, y: bY },
                width: joistWidth,
                depth: joistDepth,
                z0: -thickness,
                z1: 0,
                length: xNext - x,
                section: 'I-Joist Blocking'
              });
            }
          }
        } else if (y1 - y0 > 100) {
          joistCount++;
          members.push({
            id: `${s.id}:FJ-${String(joistCount).padStart(3, '0')}`,
            slabId: s.id,
            type: 'Floor joist',
            a: { x, y: y0 },
            b: { x, y: y1 },
            width: joistWidth,
            depth: joistDepth,
            z0: -thickness,
            z1: 0,
            length: y1 - y0,
            section: 'I-Joist 11-7/8'
          });
        }
      }
    }
  } else {
    const hasGirder = lengthY > 4800;
    const midX = (minX + maxX) / 2;

    if (hasGirder) {
      members.push({
        id: `${s.id}:GIRDER-1`,
        slabId: s.id,
        type: 'Floor beam',
        a: { x: midX, y: minY + rimWidth },
        b: { x: midX, y: maxY - rimWidth },
        width: girderWidth,
        depth: joistDepth,
        z0: -thickness,
        z1: 0,
        length: lengthY - 2 * rimWidth,
        section: '2-Ply LVL 1-3/4x11-7/8'
      });
    }

    for (let y = minY + spacing; y < maxY - spacing / 2; y += spacing) {
      const intersects = [];
      for (let i = 0; i < pts.length; i++) {
        const p1 = pts[i], p2 = pts[(i + 1) % pts.length];
        if (Math.abs(p1.y - p2.y) < 1e-5) continue;
        if ((p1.y <= y && p2.y > y) || (p2.y <= y && p1.y > y)) {
          const xInt = p1.x + (p2.x - p1.x) * (y - p1.y) / (p2.y - p1.y);
          intersects.push(xInt);
        }
      }
      intersects.sort((a, b) => a - b);
      for (let k = 0; k < intersects.length - 1; k += 2) {
        let x0 = intersects[k] + rimWidth, x1 = intersects[k + 1] - rimWidth;

        if (hasGirder && x0 < midX && x1 > midX) {
          const x1a = midX - girderWidth / 2;
          if (x1a - x0 > 100) {
            joistCount++;
            members.push({
              id: `${s.id}:FJ-${String(joistCount).padStart(3, '0')}`,
              slabId: s.id,
              type: 'Floor joist',
              a: { x: x0, y },
              b: { x: x1a, y },
              width: joistWidth,
              depth: joistDepth,
              z0: -thickness,
              z1: 0,
              length: x1a - x0,
              section: 'I-Joist 11-7/8'
            });
          }

          const x0b = midX + girderWidth / 2;
          if (x1 - x0b > 100) {
            joistCount++;
            members.push({
              id: `${s.id}:FJ-${String(joistCount).padStart(3, '0')}`,
              slabId: s.id,
              type: 'Floor joist',
              a: { x: x0b, y },
              b: { x: x1, y },
              width: joistWidth,
              depth: joistDepth,
              z0: -thickness,
              z1: 0,
              length: x1 - x0b,
              section: 'I-Joist 11-7/8'
            });
          }
        } else if (x1 - x0 > 100) {
          joistCount++;
          members.push({
            id: `${s.id}:FJ-${String(joistCount).padStart(3, '0')}`,
            slabId: s.id,
            type: 'Floor joist',
            a: { x: x0, y },
            b: { x: x1, y },
            width: joistWidth,
            depth: joistDepth,
            z0: -thickness,
            z1: 0,
            length: x1 - x0,
            section: 'I-Joist 11-7/8'
          });
        }
      }
    }
  }

  return members;
}

function floorMemberPolygon(m) {
  const dx = m.b.x - m.a.x;
  const dy = m.b.y - m.a.y;
  const len = Math.hypot(dx, dy) || 1;
  let nx = -dy / len;
  let ny = dx / len;

  if (m.type === 'Rim board') {
    const w = m.width || 45;
    if (m.center) {
      const mx = (m.a.x + m.b.x) / 2;
      const my = (m.a.y + m.b.y) / 2;
      const dot = nx * (m.center.x - mx) + ny * (m.center.y - my);
      if (dot < 0) {
        nx = -nx;
        ny = -ny;
      }
    }
    return [
      { x: m.a.x, y: m.a.y },
      { x: m.b.x, y: m.b.y },
      { x: m.b.x + nx * w, y: m.b.y + ny * w },
      { x: m.a.x + nx * w, y: m.a.y + ny * w }
    ];
  }

  const half = (m.width || 45) / 2;
  return [
    { x: m.a.x - nx * half, y: m.a.y - ny * half },
    { x: m.b.x - nx * half, y: m.b.y - ny * half },
    { x: m.b.x + nx * half, y: m.b.y + ny * half },
    { x: m.a.x + nx * half, y: m.a.y + ny * half }
  ];
}

if (typeof window !== 'undefined') {
  window.generateFloorFramingForSlab = generateFloorFramingForSlab;
  window.floorMemberPolygon = floorMemberPolygon;
}

function solidModel(){
  projectedFaces=[];
  if(view==='framing3d'){
    for(const w of model.elements.filter(e=>e.type==='wall'&&shown(e))){
      const z=wallBase(w);
      for(const m of generateWallFraming(w).members){
        const n0=projectedFaces.length;prism(w.id,framingMemberWorld(w,m),z+m.z0,z+m.z1,'Oak');
        for(let i=n0;i<projectedFaces.length;i++){projectedFaces[i].timberMember=true;projectedFaces[i].memberType=m.type}
      }
    }
    for(const s of model.elements.filter(e=>e.type==='slab'&&shown(e))){
      const z=storyOf(s).elevation;
      for(const m of generateFloorFramingForSlab(s)){
        const n0=projectedFaces.length;prism(s.id,floorMemberPolygon(m),z+m.z0,z+m.z1,'Timber');
        for(let i=n0;i<projectedFaces.length;i++){projectedFaces[i].timberMember=true;projectedFaces[i].memberType=m.type}
      }
    }
    drawRoofFraming3D();projectedFaces.sort((a,b)=>a.depth-b.depth);return;
  }
  const wallCells=clipWallCells(joinedWallCells(model.elements.filter(e=>e.type==='wall'&&shown(e))));
  for(const face of wallSurfaces(wallCells)){
    const ps=face.points.map(project3),colors=materials[face.material]||materials.Timber;
    projectedFaces.push({id:face.id,points:ps,depth:ps.reduce((a,p)=>a+p.depth,0)/ps.length,color:selected.includes(face.id)?'#91b8a1':face.kind==='top'?colors[2]:face.kind==='bottom'?colors[1]:(Math.abs(face.points[0].x-face.points[1].x)>Math.abs(face.points[0].y-face.points[1].y)?colors[0]:colors[1]),wallSurface:true,world:face.points,cutSurface:isCutFace(face.points)});
  }
  for(const o of model.elements.filter(e=>e.host&&shown(e))){
    const w=hostOf(o),len=distance(w.a,w.b),z=wallBase(w),top=heightOf(w);
    prism(o.id,openingSolidPolygon(w,o),z+o.sill,z+Math.min(o.sill+o.height,top),o.type==='window'?'Glass':'Oak');
  }
  for(const e of model.elements.filter(shown)){
    const z=storyOf(e).elevation;
    if(e.type==='wall'){continue;}
    else if(e.type==='slab')prism(e.id,e.points,z-e.thickness,z,e.material);
    else if(e.type==='column'){
      const r=(e.thickness||300)/2;
      const poly=e.columnProfile==='circle'?cylinderPolygon(e.a,r,12):wallPoly(e,{x:e.a.x-r,y:e.a.y},{x:e.a.x+r,y:e.a.y});
      prism(e.id,poly,z,z+heightOf(e),e.material);
    }
    else if(e.type==='skylight'){
      const w=(e.width||1000)/2,l=(e.length||1400)/2;
      prism(e.id,[{x:e.a.x-w,y:e.a.y-l},{x:e.a.x+w,y:e.a.y-l},{x:e.a.x+w,y:e.a.y+l},{x:e.a.x-w,y:e.a.y+l}],z+2400,z+2500,'Glass');
    }
    else if(e.type==='beam')prism(e.id,wallPoly(e),z+heightOf(e)-e.thickness,z+heightOf(e),e.material);
    else if(e.type==='roof')drawRoofSolid(e);
    else if(e.type==='stair'&&e.a&&e.b){
      const risers=e.risers||16,rh=(e.height||3048)/risers,w=e.width||1000,len=distance(e.a,e.b)||1,u={x:(e.b.x-e.a.x)/len,y:(e.b.y-e.a.y)/len},n={x:-u.y*w/2,y:u.x*w/2};
      for(let i=0;i<risers;i++){
        const p1=lerp(e.a,e.b,i/risers),p2=lerp(e.a,e.b,(i+1)/risers);
        prism(e.id,[{x:p1.x+n.x,y:p1.y+n.y},{x:p2.x+n.x,y:p2.y+n.y},{x:p2.x-n.x,y:p2.y-n.y},{x:p1.x-n.x,y:p1.y-n.y}],z+i*rh,z+(i+1)*rh,'Timber');
      }
    }else if(e.type==='railing'&&e.a&&e.b){
      prism(e.id,wallPoly(e,e.a,e.b,40),z+950,z+1050,'Steel');
      const len=distance(e.a,e.b),cnt=Math.max(1,Math.floor(len/500));
      for(let i=0;i<=cnt;i++){
        const pt=lerp(e.a,e.b,i/cnt);
        prism(e.id,[{x:pt.x-20,y:pt.y-20},{x:pt.x+20,y:pt.y-20},{x:pt.x+20,y:pt.y+20},{x:pt.x-20,y:pt.y+20}],z,z+1000,'Steel');
      }
    }else if(e.type==='curtainwall'&&e.a&&e.b){
      prism(e.id,wallPoly(e,e.a,e.b,50),z,z+heightOf(e),'Glass');
    }else if(e.type==='morph'&&e.points){
      prism(e.id,e.points,z,z+(e.height||2400),e.material||'Concrete');
    }else if(e.type==='mesh'&&e.points){
      prism(e.id,e.points,z-(e.skirtDepth||800),z,e.material||'Concrete');
    }else if(e.type==='object'&&e.a){
      const w=e.width||1600,d=e.depth||900;
      prism(e.id,[{x:e.a.x-w/2,y:e.a.y-d/2},{x:e.a.x+w/2,y:e.a.y-d/2},{x:e.a.x+w/2,y:e.a.y+d/2},{x:e.a.x-w/2,y:e.a.y+d/2}],z,z+(e.height||750),e.material||'Oak');
    }
  }
  projectedFaces.sort((a,b)=>a.depth-b.depth);
}
function draw3D(){const vp=globalThis.cadtechViewport;if(vp&&vp.enabled&&vp.sync()){cameraUI();return}drawViewportGround();solidModel();projectedFaces=projectedFaces.filter(f=>transparent||surfaceVisible(f));prepareWallFeatureEdges(projectedFaces);if(!transparent){drawOpaqueSolids(projectedFaces)}else {solidOwners=null;ctx.globalAlpha=.38;for(const face of projectedFaces){const fill=sceneCamera.style==='hiddenline'?'#f8faf7':shadedSurface(face),edge=sceneCamera.style==='hiddenline'?'#67746d':face.wallSurface?null:selected.includes(face.id)?'#4e8061':'#686d5630';poly(face.points,fill,edge,selected.includes(face.id)?.8:.5);for(const e of face.featureEdges||[])line(e.a,e.b,e.selected?'#4f7e5e':sceneCamera.style==='hiddenline'?'#66756d':'#6d7f6a70',e.selected?1:.65)}}ctx.globalAlpha=1;drawViewportAxes();label('Drag to orbit · Shift / Space + drag to pan · Scroll to zoom',width/2,height-28,11,'#85988b');cameraUI()}
function drawElevation(){hits=[];const s=baseScale*scale,ox=width/2-6500*s+pan.x,oy=height/2+2000*s+pan.y;const pr=(x,z)=>({x:ox+x*s,y:oy-z*s});line(pr(-1800,0),pr(14800,0),'#adb8a5',1);for(const st of model.stories){const p=pr(-1500,st.elevation);line(p,pr(14500,st.elevation),'#cbd4c4',.65,[6,5]);label(`+${st.elevation.toLocaleString()}  ${st.name}`,p.x,p.y-12,9,'#8b9a81','left')}
if(view==='section'){drawJoinedSection(pr);drawRoofElevation(pr);return}const walls=model.elements.filter(e=>e.type==='wall'&&e.story===activeStory&&shown(e));for(const e of walls){let st={...storyOf(e),elevation:wallBase(e)},h=heightOf(e);if(view==='elevation'&&(Math.abs(e.a.y-e.b.y)>1||e.layer!=='Exterior Walls'||e.a.y<Math.max(...walls.filter(w=>Math.abs(w.a.y-w.b.y)<1&&w.layer==='Exterior Walls').map(w=>w.a.y))))continue;let a=pr(Math.min(e.a.x,e.b.x),st.elevation+h),b=pr(Math.max(e.a.x,e.b.x),st.elevation);if(view==='section'&&!(Math.min(e.a.y,e.b.y)<=5850&&Math.max(e.a.y,e.b.y)>=5850))continue;if(view==='section'){a=pr(e.a.x-e.thickness/2,st.elevation+h);b=pr(e.a.x+e.thickness/2,st.elevation)}rect(a.x,a.y,b.x-a.x,b.y-a.y,selected.includes(e.id)?'#d0e2d0':view==='section'?'#bec9b2':'#eef1e9','#809373',1);hits.push({id:e.id,a,b});if(view==='elevation')for(const o of hosted(e)){const pos=openingPoint(o),x=pos.x,y=st.elevation+o.sill;let l=pr(x-o.width/2,y+o.height),r=pr(x+o.width/2,y);rect(l.x,l.y,r.x-l.x,r.y-l.y,o.type==='window'?'#dce8df':'#d5cbb2',selected.includes(o.id)?'#315d54':'#9aa990',1);line({x:(l.x+r.x)/2,y:l.y},{x:(l.x+r.x)/2,y:r.y},'#9cafa0',.8);hits.push({id:o.id,a:l,b:r})}}drawRoofElevation(pr);label(view==='section'?'SECTION A–A · CUT AT Y 5,850 mm':'SOUTH ELEVATION · LIVE MODEL PROJECTION',width/2,height-65,9,'#929f89')}
function render(){trackerUI();if(!width)return;if(!isModelView())globalThis.cadtechViewport?.hide();ctx.clearRect(0,0,width,height);ctx.fillStyle='#f7f9f6';ctx.fillRect(0,0,width,height);$('#selection-tip').style.display='none';if(view==='plan'){if(grid){let step=1000*baseScale*scale;if(step>12){ctx.fillStyle='#c9d3c1';let origin=p2({x:0,y:0});for(let x=origin.x%step;x<width;x+=step)for(let y=origin.y%step;y<height;y+=step){ctx.beginPath();ctx.arc(x,y,.65,0,7);ctx.fill()}}}drawPlan()}else if(view==='framingplan')drawFramingPlan();else if(view==='roofframingplan')drawRoofFramingPlan();else if(view==='ewpspecs')drawEWPFloorFramingPlan();else if(view==='panel')drawWallPanel();else if(view==='framing3d')draw3D();else if(view==='3d')draw3D();else if(view!=='schedule'&&view!=='cutlist'&&view!=='trusselevation')drawElevation();if(view==='plan'&&points.length){if(['wall','line','beam'].includes(tool)){const p=p2(points.at(-1));line({x:0,y:p.y},{x:width,y:p.y},'#819c7c80',.6,[3,6]);line({x:p.x,y:0},{x:p.x,y:height},'#819c7c80',.6,[3,6]);}if(tool==='wall'&&hover&&distance(points.at(-1),hover)>10){const preview={id:'preview',type:'wall',a:points.at(-1),b:hover,thickness:200,reference:'outside',story:activeStory};poly(wallPoly(preview).map(p2),'#739a7c30','#4a795b',1);}for(let i=1;i<points.length;i++)line(p2(points[i-1]),p2(points[i]),'#3d785b',1.5,[4,3]);if(hover){line(p2(points.at(-1)),p2(hover),'#3d785b',1.2,[4,3]);const p=p2(hover);rect(p.x-3,p.y-3,6,6,'white','#3d785b')}}if(view==='plan'&&hover&&(tool!=='select'||['grip','element'].includes(drag?.kind))){let p=p2(hover);line({x:p.x-9,y:p.y},{x:p.x+9,y:p.y},'#4d8261',.8);line({x:p.x,y:p.y-9},{x:p.x,y:p.y+9},'#4d8261',.8);if(snap&&currentSnap&&!['Grid','Off'].includes(currentSnap)){ctx.setLineDash([]);ctx.strokeStyle='#2f7a55';ctx.lineWidth=1.4;ctx.strokeRect(p.x-5,p.y-5,10,10);label(currentSnap,p.x+12,p.y-12,10,'#2f6b4d','left')}}editPreview();if(drag?.kind==='marquee'){const crossing=lastPointer.x<drag.start.x;ctx.setLineDash(crossing?[5,3]:[]);rect(drag.start.x,drag.start.y,lastPointer.x-drag.start.x,lastPointer.y-drag.start.y,crossing?'#387c9820':'#70977917',crossing?'#387c98':'#6e9575',1);ctx.setLineDash([]);label(crossing?'Crossing selection':'Window selection',Math.min(drag.start.x,lastPointer.x)+5,Math.min(drag.start.y,lastPointer.y)-8,9,crossing?'#387c98':'#6e9575','left')};$('#elements-count').textContent=`${model.elements.length} elements`;$('#zoom-status').textContent=`${Math.round(scale*100)}%`;$('#undo').disabled=!modelHistory.length;$('#redo').disabled=!future.length;if(view==='schedule'||view==='cutlist')schedule();$('#wall-palette').classList.toggle('hidden',!(view==='plan'&&tool==='select'&&model.elements.some(e=>selected.includes(e.id)&&e.type==='wall')))}
function resize(){const b=canvas.getBoundingClientRect();width=b.width;height=b.height;canvas.width=Math.round(width*devicePixelRatio);canvas.height=Math.round(height*devicePixelRatio);ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);baseScale=Math.max(.014,Math.min((width-110)/16000,(height-150)/12000));if(isModelView())fit3DCamera(false);render()}new ResizeObserver(resize).observe($('#canvas-area'));
function field(label,key,value,unit='',type='number'){return `<label class="field"><span>${label}</span><div class="input-unit"><input data-property="${key}" value="${esc(value)}" type="${type}" ${type==='number'?'step="0.1"':''}>${unit?`<span>${unit}</span>`:''}</div></label>`}function choice(label,key,value,opts){return `<label class="field"><span>${label}</span><select data-property="${key}">${opts.map(([v,t])=>`<option value="${esc(v)}" ${v===value?'selected':''}>${esc(t)}</option>`).join('')}</select></label>`}
var APP_WALL_HEIGHT_PRESETS=[2400,2440,2500,2600,2700,2743,2800,3000,3048,3200,3300,3600];
var APP_OPENING_HEAD_PRESETS=[1800,2000,2040,2100,2134,2200,2300,2400,2440,2500,2600];
function appPresetKey(actual,presets){const n=Number(actual);const hit=presets.find(v=>Math.abs(v-n)<=1);return hit===undefined?'custom':String(hit)}
function properties(){
  let e=model.elements.find(e=>e.id===selected[0]);
  renderInfoBox();
  if(!e){
    $('#properties').innerHTML=`<div class="property-heading"><span class="element-symbol">${icon('building')}</span><div><strong>Project Settings</strong><small>Archicad Virtual Building</small></div></div><div class="section-header">ACTIVE STORY</div>${field('Height','storyHeight',model.stories.find(s=>s.id===activeStory).height,'mm')}<div class="empty-prop">Select an element to edit its geometry, materials, and IFC classification.</div><div style="padding:0 19px"><span class="status-label">All views synchronized</span></div>`;
    bindProperties();return;
  }
  const name=e.type[0].toUpperCase()+e.type.slice(1);
  let html=`<div class="property-heading"><span class="element-symbol">${icon(e.type)}</span><div><strong>${name}</strong><small>${esc(e.id)} · ${selected.length>1?selected.length+' selected':'Selected element'}</small></div><span class="selection-count">${selected.length.toString().padStart(2,'0')}</span></div><div class="prop-section"><div class="section-header">GENERAL & CLASSIFICATION</div>${field('Element ID','id',e.id,'','text')}${choice('Story','story',e.story,model.stories.map(s=>[s.id,s.name]))}${choice('Layer','layer',e.layer,layers.map(l=>[l.name,l.name]))}</div><div class="prop-section"><div class="section-header">GEOMETRY & POSITIONING</div>`;
  if(['wall','beam','column','curtainwall','stair'].includes(e.type)){
    if(e.b)html+=field('Length','length',Math.round(distance(e.a,e.b)),'mm');
    html+=field('Height','height',heightOf(e),'mm')+field('Thickness / Width','thickness',e.thickness||200,'mm');
    if(e.type==='wall')html+=field('End X','bx',Math.round(e.b.x),'mm')+field('End Y','by',Math.round(e.b.y),'mm')+choice('Wall height preset','wallHeightPreset',appPresetKey(heightOf(e),APP_WALL_HEIGHT_PRESETS),[['custom','Custom / manual height'],...APP_WALL_HEIGHT_PRESETS.map(v=>[String(v),`${v} mm`])])+choice('Reference line','reference',e.reference||'outside',[['outside','Outside face'],['center','Center core'],['inside','Inside face']])+choice('Top linked','followStory',String(e.followStory),[['true','Story height'],['false','Custom height']]);
    if(e.type==='stair')html+=field('Risers count','risers',e.risers||16,'')+field('Riser height','riserHeight',Math.round(e.riserHeight||190.5),'mm')+field('Flight width','width',e.width||1000,'mm');
    if(e.type==='curtainwall')html+=field('Panel module width','panelWidth',e.panelWidth||1200,'mm');
  }
  if(e.type==='railing'&&e.a&&e.b){
    html+=field('Length','length',Math.round(distance(e.a,e.b)),'mm')+field('Railing height','height',e.height||1050,'mm')+field('Baluster spacing','balusterSpacing',e.balusterSpacing||120,'mm');
  }
  if(e.type==='grid'&&e.a&&e.b){
    html+=field('Grid ID marker','bubble',e.bubble||'A','','text')+field('Length','length',Math.round(distance(e.a,e.b)),'mm');
  }
  if(e.type==='leveldim'){
    html+=field('Level height','targetHeight',e.targetHeight??storyOf(e).elevation,'mm')+choice('Marker symbol','markerType',e.markerType||'archicad_triangle',[['archicad_triangle','Archicad standard triangle'],['circle','Benchmark circle']]);
  }
  if(e.type==='object'){
    html+=field('Object Type','subtype',e.subtype||'Table & Chairs','','text')+field('Width','width',e.width||1600,'mm')+field('Depth','depth',e.depth||900,'mm')+field('Height','height',e.height||750,'mm');
  }
  if(e.type==='morph'||e.type==='mesh'){
    html+=field('Height / Extrusion','height',e.height||2400,'mm');
    if(e.type==='mesh')html+=field('Base skirt depth','skirtDepth',e.skirtDepth||800,'mm')+field('Base elevation','elevation',e.elevation||0,'mm');
  }
  if(e.type==='fill'){
    html+=choice('Hatch pattern','hatchType',e.hatchType||'diagonal45',[['diagonal45','45° Diagonal'],['cross','Crosshatch'],['solid','Solid fill']])+field('Hatch spacing','hatchScale',e.hatchScale||200,'mm');
  }
  if(e.b&&!['wall','stair','railing','curtainwall','grid'].includes(e.type)){
    const d=e.type==='dimension'?resolveDimension(e):e;
    html+=field('End X','bx',Math.round(d.b.x),'mm')+field('End Y','by',Math.round(d.b.y),'mm');
    if(e.type==='line')html+=field('Length','length',Math.round(distance(e.a,e.b)),'mm');
  }
  if(e.host){
    html+=choice('Host wall','host',e.host,model.elements.filter(w=>w.type==='wall').map(w=>[w.id,w.id]))+field('Offset','offset',e.offset,'mm')+field('Width','width',e.width,'mm')+field('Height','height',e.height,'mm');
    if(e.type==='window'||e.type==='cornerwin')html+=field('Sill height','sill',e.sill,'mm');
    html+=field('Header / opening head level','head',e.sill+e.height,'mm');
    if(e.type==='window'||e.type==='door')html+=choice('Head height preset','openingHeadPreset',appPresetKey((e.sill||0)+e.height,APP_OPENING_HEAD_PRESETS),[['custom','Custom / manual head level'],...APP_OPENING_HEAD_PRESETS.map(v=>[String(v),`${v} mm above wall base`])])+`<div class="empty-prop">Changing the head level adjusts opening height from its current sill. The header is generated immediately above the opening.</div>`;
  }
  if(e.type==='slab')html+=field('Thickness','thickness',e.thickness,'mm');
  if(e.type==='roof')html+=roofProperties(e);
  if(e.radius)html+=field('Radius','radius',e.radius,'mm');
  if(e.a){
    const a=e.type==='dimension'?resolveDimension(e).a:e.a;
    html+=field('Start X','ax',Math.round(a.x),'mm')+field('Start Y','ay',Math.round(a.y),'mm');
  }
  if(e.type==='dimension'){
    const d=resolveDimension(e);
    html+=field('Baseline offset','offset',e.offset??600,'mm')+`<div class="empty-prop">${d.resolved?'Linked associative anchors follow elements.':'One or more anchors detached.'}</div>`;
  }
  if(e.type==='text')html+=field('Text','text',e.text,'','text');
  if(e.type==='label')html+=field('Label text','text',e.text||'Label','','text');
  if(e.type==='detail')html+=field('Detail code','code',e.code||'D-01','','text')+field('Radius','radius',e.radius||800,'mm');
  if(e.type==='changemarker')html+=field('Revision number','changeNumber',e.changeNumber||'CH-01','','text')+field('Reason','text',e.text||'Revision','','text');
  if(e.type==='lamp')html+=field('Lamp wattage','wattage',e.wattage||60,'W')+choice('Fixture type','lightType',e.lightType||'downlight',[['downlight','Recessed Downlight'],['pendant','Pendant Luminaire'],['cove','Linear Cove']]);
  if(e.type==='camera')html+=field('Field of view','fov',e.fov||60,'°')+field('Camera height','height',e.height||1600,'mm');
  html+='</div>';

  if(['wall','window','door','beam','column','slab','roof','curtainwall','stair','morph','mesh','object'].includes(e.type)){
    html+=`<div class="prop-section"><div class="section-header">SURFACE & MATERIAL</div>${choice('Material','material',e.material||'Timber',Object.keys(materials).map(m=>[m,m]))}</div>`;
  }
  if(e.type==='roof')html+=roofFramingProperties(e);
  if(e.type==='wall'){
    html+=framingProperties(e);
    let hs=hosted(e);
    html+=`<div class="section-header">HOSTED OPENINGS <span>${hs.length}</span></div>`+hs.map(o=>`<div class="hosted-row">${icon(o.type)}${o.type[0].toUpperCase()+o.type.slice(1)} · ${o.id}<button data-select="${o.id}">Select</button></div>`).join('')+(hs.length?'':'<div class="empty-prop">Place a door, window or corner window.</div>');
  }
  html+=`<div style="padding:12px 19px 0"><span class="status-label">${e.host?'Hosted BIM Opening':'2D + 3D live synchronized'}</span></div>`;
  const propEl=$('#properties');if(propEl)propEl.innerHTML=html;
  bindProperties();
  if(e.structure==='composite'){const th=$('#properties [data-property="thickness"]');if(th)th.readOnly=true;}
  $$('[data-junction-detail]').forEach(b=>b.onclick=()=>{
    const mode=b.dataset.junctionDetail;
    try{
      if(!['insideBlocking','insideStudFull','insideStudPartial'].includes(mode))throw Error('Unsupported inside-wall junction detail.');
      if(construction(e).insideJunctionDetail===mode)return;
      if(commit(()=>setWallProperty(e,'framing.insideJunctionDetail',mode)))toast(`${window.insideJunctionLabel?.(mode)||mode} selected; wall framing regenerated.`);
    }catch(error){toast(error.message||'Could not update the inside-wall junction detail.');}
  });
  $$('[data-wall-action]').forEach(b=>b.onclick=()=>{
    const action=b.dataset.wallAction;
    if(action==='flip'){commit(()=>e.flipped=!e.flipped);toast('Wall orientation flipped; framing regenerated.')}
    else if(action==='cornerDetail'){openCornerDetailModal(e)}
    else if(action==='junctionAudit'){
      const audit=window.auditAllWallJunctions?.();
      if(!audit){toast('Wall-junction audit is unavailable.');return;}
      const rows=audit.connections.map(c=>`<tr><td>${esc(c.wallId)}</td><td>${esc(c.otherWallId)}</td><td style="text-align:right">${c.offsetMm.toLocaleString()} mm</td><td>${esc(c.detail)}</td><td><b style="color:${c.status==='OK'?'#15803d':'#b45309'}">${esc(c.status)}</b></td></tr>`).join('');
      const problemList=audit.issues.length?`<h3 style="margin:14px 0 6px">Review items (${audit.issues.length})</h3><ul style="margin:0;padding-left:20px">${audit.issues.map(i=>`<li style="margin:5px 0">${esc(i)}</li>`).join('')}</ul>`:'<p style="padding:10px;background:#f0fdf4;border-radius:6px;color:#166534">No missing T-junction backing members were detected. This is a geometry check, not a structural capacity verification.</p>';
      openModal('Internal Wall Intersection Audit',`<div class="modal-copy">Checked ${audit.wallCount} framed walls and ${audit.junctionCount} wall intersections. <b>${audit.okCount} OK</b> · <b>${audit.reviewCount} need review</b>. The selected internal-wall detail applies to T-junctions where another wall terminates on the through-wall.</div><div style="overflow:auto;max-height:38vh;margin:12px 0;border:1px solid #dbe3ea;border-radius:6px"><table style="width:100%;border-collapse:collapse;font-size:12px"><thead><tr style="background:#f1f5f9;text-align:left"><th style="padding:7px">Through wall</th><th style="padding:7px">Branch wall</th><th style="padding:7px">Offset</th><th style="padding:7px">Selected detail</th><th style="padding:7px">Status</th></tr></thead><tbody>${rows||'<tr><td colspan="5" style="padding:10px">No internal wall junctions were detected.</td></tr>'}</tbody></table></div>${problemList}<div class="modal-actions"><button id="wall-junction-audit-close" class="primary">Close</button></div>`);
      bindClick('#wall-junction-audit-close',()=>$('#modal')?.close?.());
    }
    else setView(action==='panel'?'panel':'cutlist')
  });
  $$('[data-roof-align]').forEach(b=>b.onclick=()=>alignRoofFraming(e));
  $$('[data-roof-view]').forEach(b=>b.onclick=()=>setView(b.dataset.roofView));
  $$('[data-select]').forEach(b=>b.onclick=()=>select([b.dataset.select]));
}

function bindProperties(){
  $$('[data-property]').forEach(input=>input.onchange=()=>{
    let key=input.dataset.property,v=input.type==='number'?Number(input.value):input.value,e=model.elements.find(e=>e.id===selected[0]);
    try{
      if(input.type==='number'&&(!Number.isFinite(v)||Math.abs(v)>1000000))throw Error('Enter a valid value.');
      if(['height','thickness','width','radius','length','storyHeight','risers','panelWidth'].includes(key)&&v<=0)throw Error('Size must be greater than zero.');
      if(key==='storyHeight'){setStoryHeight(activeStory,v);return}
      if(!e)return;
      if(key==='wallHeightPreset'){
        if(v==='custom'){properties();return;}
        if(e.type!=='wall')throw Error('Select a wall to change its height.');
        const h=Number(v);
        if(!Number.isFinite(h)||h<=0)throw Error('Choose a valid wall height preset.');
        if(hosted(e).some(o=>(o.sill||0)+o.height>h+1))throw Error('This wall height would cut off a hosted window or door. Adjust opening head levels first.');
        commit(()=>{e.height=h;e.followStory=false;});
        toast(`Wall height set to ${Math.round(h)} mm.`);return;
      }
      if(key==='openingHeadPreset'){
        if(v==='custom'){properties();return;}
        if(!['window','door'].includes(e.type))throw Error('Select a window or door to set its head level.');
        const head=Number(v),sill=Number(e.sill||0),newHeight=head-sill;
        if(!Number.isFinite(head)||newHeight<=0)throw Error('Head level must be above the sill.');
        const proposed={...e,height:newHeight};validateOpening(proposed);
        commit(()=>{e.height=newHeight;});
        toast(`${e.type==='window'?'Window':'Door'} head level set to ${Math.round(head)} mm.`);return;
      }
      if(key==='windowHeadPreset'||key==='doorHeadPreset'){
        if(v==='custom'||v==='mixed'){properties();return;}
        if(e.type!=='wall')throw Error('Select a wall to change its hosted opening head levels.');
        const type=key==='windowHeadPreset'?'window':'door',head=Number(v);
        const openings=hosted(e).filter(o=>o.type===type);
        if(!openings.length)throw Error(`This wall has no hosted ${type}s.`);
        const proposed=openings.map(o=>({...o,height:head-(o.sill||0)}));
        if(proposed.some(o=>!Number.isFinite(o.height)||o.height<=0))throw Error('The selected head level must be above every opening sill.');
        proposed.forEach(validateOpening);
        commit(()=>proposed.forEach(o=>{const target=model.elements.find(el=>el.id===o.id);if(target)target.height=o.height;}));
        toast(`${type==='window'?'Window':'Door'} head levels set to ${Math.round(head)} mm for ${proposed.length} opening(s).`);return;
      }
      if(key==='id'&&(!v.trim()||model.elements.some(o=>o!==e&&o.id===v)))throw Error('Use a unique element ID.');
      if(key==='thickness'&&e.structure==='composite')throw Error('Composite thickness is the sum of its layers.');
      if(key==='priority'&&(v<0||v>1000))throw Error('Priority must be between 0 and 1,000.');
      if(key==='topStory'&&v&&model.stories.find(s=>s.id===v)?.elevation<=storyOf(e).elevation)throw Error('Top level must be above the home story.');
      if(key.startsWith('roofFraming.')){commit(()=>{e.roofFraming={...roofFramingSettings(e),[key.split('.')[1]]:v};validateRoofFraming(e)});return}
      if(key.startsWith('roofLoads.')){commit(()=>{e.roofLoads={...roofLoadsSettings(e),[key.split('.')[1]]:v};});return}
      if(key.startsWith('framing.')||key==='structure'||key==='composite'){commit(()=>setWallProperty(e,key,v));return}
      let proposed={...e,[key]:v};
      if(key==='head'){proposed.height=v-e.sill;delete proposed.head;if(proposed.height<=0)throw Error('Head height must be above the sill.')}
      if(key==='reveal'&&(v<0||v>Math.max(0,(hostOf(e)?.thickness||200)-40)))throw Error('Reveal must stay within the wall thickness.');
      if(key==='height')proposed.followStory=false;
      if(['offset','width','sill','height','host','head'].includes(key)&&e.host){if(key==='host')proposed.story=hostOf(proposed).story;validateOpening(proposed)}
      if(key==='height'&&e.type==='wall'&&hosted(e).some(o=>o.sill+o.height>v))throw Error('Height must contain all hosted openings.');
      commit(()=>{
        if(key==='length')e.b=lerp(e.a,e.b,v/distance(e.a,e.b));
        else if(['ax','ay','bx','by'].includes(key)){
          if(e.type==='dimension'&&e.refs){const d=resolveDimension(e);e.a=clone(d.a);e.b=clone(d.b);e.refs[key[0]==='a'?0:1]=null;}
          e[key[0]][key[1]]=v;
        }else if(key==='followStory'){e.followStory=v==='true';e.height=heightOf(e)}
        else if(key==='id'){
          const old=e.id;e.id=v;hosted({id:old}).forEach(o=>o.host=v);
          model.elements.forEach(d=>d.refs?.forEach(ref=>{if(ref?.elementId===old)ref.elementId=v}));
          selected=selected.map(id=>id===old?v:id);
        }else Object.assign(e,proposed);
        if(e.type==='wall')hosted(e).forEach(o=>{o.story=e.story;fitOpening(o,e)});
      });
      toast('Archicad model updated');
      renderInfoBox();
    }catch(err){toast(err.message);properties()}
  });
}

function renderInfoBox(){
  const box=$('#info-box');
  if(!box)return;
  const e=model.elements.find(x=>x.id===selected[0]);
  const activeToolDef=toolGroups.flatMap(([,...ts])=>ts).find(t=>t[0]===tool)||['select','Arrow Tool'];
  const toolName=e?`${e.type[0].toUpperCase()+e.type.slice(1)} · ${e.id}`:`${activeToolDef[1]} Tool`;
  const toolIconId=e?e.type:(paths[tool]?tool:'cube');
  let html=`<div class="info-section"><span class="info-label">TOOL</span><span style="display:flex;align-items:center;gap:4px;font-weight:700">${icon(toolIconId)} ${toolName}</span></div><div class="info-divider"></div>`;

  const activeType=e?.type||tool;
  if(activeType==='wall'){
    const g=toolGeomMethod.wall||'single';
    html+=`<div class="info-section"><span class="info-label">GEOM</span><div class="info-btn-group"><button class="info-btn ${g==='single'?'active':''}" data-geom="single" title="Straight Single">―</button><button class="info-btn ${g==='chained'?'active':''}" data-geom="chained" title="Chained Polywall">∿</button><button class="info-btn ${g==='rect'?'active':''}" data-geom="rect" title="Rectangular 4-Wall">▢</button><button class="info-btn ${g==='rotated_rect'?'active':''}" data-geom="rotated_rect" title="Rotated Rectangle">◇</button></div></div><div class="info-divider"></div>`;
    html+=`<div class="info-section"><span class="info-label">REF LINE</span><select class="info-select" id="info-ref-line"><option value="outside" ${(e?.reference||'outside')==='outside'?'selected':''}>Outside Face</option><option value="center" ${e?.reference==='center'?'selected':''}>Center Core</option><option value="inside" ${e?.reference==='inside'?'selected':''}>Inside Face</option></select></div><div class="info-divider"></div>`;
  }else if(activeType==='slab'){
    const g=toolGeomMethod.slab||'poly';
    html+=`<div class="info-section"><span class="info-label">GEOM</span><div class="info-btn-group"><button class="info-btn ${g==='poly'?'active':''}" data-geom="poly" title="Polygonal">⬡</button><button class="info-btn ${g==='rect'?'active':''}" data-geom="rect" title="Rectangular">▢</button></div></div><div class="info-divider"></div>`;
  }else if(activeType==='roof'){
    const g=toolGeomMethod.roof||'poly';
    html+=`<div class="info-section"><span class="info-label">GEOM</span><div class="info-btn-group"><button class="info-btn ${g==='poly'?'active':''}" data-geom="poly" title="Multi-plane">⬡</button><button class="info-btn ${g==='rect'?'active':''}" data-geom="rect" title="Rectangular Hip">▢</button></div></div><div class="info-divider"></div>`;
    html+=`<div class="info-section"><span class="info-label">PITCH</span><div class="info-input-wrap"><input id="info-pitch" type="number" step="1" value="${e?.pitch||25}"><span>°</span></div></div><div class="info-section"><span class="info-label">OVERHANG</span><div class="info-input-wrap"><input id="info-overhang" type="number" step="50" value="${e?.overhang||609.6}"><span>mm</span></div></div><div class="info-divider"></div>`;
  }else if(activeType==='column'){
    const g=toolGeomMethod.column||'square';
    html+=`<div class="info-section"><span class="info-label">PROFILE</span><div class="info-btn-group"><button class="info-btn ${g==='square'?'active':''}" data-geom="square" title="Square / Rectangular">▢</button><button class="info-btn ${g==='circle'?'active':''}" data-geom="circle" title="Circular">○</button></div></div><div class="info-divider"></div>`;
  }else if(activeType==='beam'){
    const g=toolGeomMethod.beam||'single';
    html+=`<div class="info-section"><span class="info-label">GEOM</span><div class="info-btn-group"><button class="info-btn ${g==='single'?'active':''}" data-geom="single" title="Straight Single">―</button><button class="info-btn ${g==='chained'?'active':''}" data-geom="chained" title="Chained Beam">∿</button></div></div><div class="info-divider"></div>`;
  }else if(activeType==='zone'){
    const g=toolGeomMethod.zone||'inner';
    html+=`<div class="info-section"><span class="info-label">METHOD</span><div class="info-btn-group"><button class="info-btn ${g==='inner'?'active':''}" data-geom="inner" title="Auto-flood Inner Edge">🪄 Auto</button><button class="info-btn ${g==='poly'?'active':''}" data-geom="poly" title="Manual Polygon">⬡ Poly</button></div></div><div class="info-divider"></div>`;
    html+=`<div class="info-section"><span class="info-label">ROOM</span><select class="info-select" id="info-zone-cat">${['Living Room','Bedroom','Kitchen','Dining','Bathroom','Office','Hallway','Terrace'].map(c=>`<option value="${c}" ${currentZoneCategory===c?'selected':''}>${c}</option>`).join('')}</select></div><div class="info-divider"></div>`;
  }else if(activeType==='object'){
    const sub=e?.subtype||toolGeomMethod.object||'Table & Chairs';
    html+=`<div class="info-section"><span class="info-label">SUBTYPE</span><select class="info-select" id="info-obj-sub">${['Table & Chairs','Living Sofa Set','Double Bed','Office Desk','Kitchen Counter','Bathroom WC','Wardrobe'].map(s=>`<option value="${s}" ${sub===s?'selected':''}>${s}</option>`).join('')}</select></div><div class="info-divider"></div>`;
  }else if(activeType==='door'||activeType==='window'||activeType==='cornerwin'){
    html+=`<div class="info-section"><span class="info-label">WIDTH</span><div class="info-input-wrap"><input id="info-width" type="number" step="50" value="${e?.width||(activeType==='door'?900:1500)}"><span>mm</span></div></div><div class="info-section"><span class="info-label">SILL</span><div class="info-input-wrap"><input id="info-sill" type="number" step="50" value="${e?.sill??(activeType==='door'?0:900)}"><span>mm</span></div></div><div class="info-divider"></div><button id="info-flip-swing" class="info-btn" title="Flip Opening Inward / Outward">Flip Swing</button><button id="info-flip-hand" class="info-btn" title="Flip Hinge Left / Right">Flip Hand</button><div class="info-divider"></div>`;
  }else if(activeType==='fill'){
    const pat=e?.hatchType||toolGeomMethod.fill||'diagonal45';
    html+=`<div class="info-section"><span class="info-label">HATCH</span><select class="info-select" id="info-fill-pattern"><option value="diagonal45" ${pat==='diagonal45'?'selected':''}>45° Diagonal</option><option value="cross" ${pat==='cross'?'selected':''}>Cross Hatch</option><option value="solid" ${pat==='solid'?'selected':''}>Solid Fill</option></select></div><div class="info-divider"></div>`;
  }

  const curHeight=e?heightOf(e):3048,curThick=e?.thickness||200;
  html+=`<div class="info-section"><span class="info-label">HEIGHT</span><div class="info-input-wrap"><input id="info-height" type="number" step="100" value="${curHeight}"><span>mm</span></div></div><div class="info-section"><span class="info-label">THICK</span><div class="info-input-wrap"><input id="info-thick" type="number" step="10" value="${curThick}"><span>mm</span></div></div><div class="info-divider"></div><div class="info-section"><span class="info-label">STORY</span><select class="info-select" id="info-story">${model.stories.map(s=>`<option value="${s.id}" ${(e?.story||activeStory)===s.id?'selected':''}>${s.name}</option>`).join('')}</select></div><div class="info-divider"></div><div class="info-section"><span class="info-label">LAYER</span><select class="info-select" id="info-layer">${layers.map(l=>`<option value="${l.name}" ${(e?.layer||'Exterior Walls')===l.name?'selected':''}>${l.name}</option>`).join('')}</select></div><div class="info-divider"></div><div class="info-section"><span class="info-label">SURFACE</span><select class="info-select" id="info-material">${Object.keys(materials).map(m=>`<option value="${m}" ${(e?.material||'Timber')===m?'selected':''}>${m}</option>`).join('')}</select></div><div class="info-divider"></div><div class="info-section"><span class="info-label">STRUCTURAL</span><select class="info-select"><option>Load-Bearing</option><option>Non-Load-Bearing</option></select></div>`;
  box.innerHTML=html;icons(box);

  $$('[data-geom]').forEach(btn=>btn.onclick=()=>{
    toolGeomMethod[activeType]=btn.dataset.geom;
    points=[];
    renderInfoBox();
    render();
    toast(`Geometry method: ${btn.title}`);
  });
  $('#info-zone-cat')?.addEventListener('change',ev=>{currentZoneCategory=ev.target.value;toast(`Zone room type: ${currentZoneCategory}`)});
  $('#info-obj-sub')?.addEventListener('change',ev=>{toolGeomMethod.object=ev.target.value;if(e&&e.type==='object')commit(()=>e.subtype=ev.target.value);toast(`Object: ${ev.target.value}`)});
  $('#info-fill-pattern')?.addEventListener('change',ev=>{toolGeomMethod.fill=ev.target.value;if(e&&e.type==='fill')commit(()=>e.hatchType=ev.target.value)});
  $('#info-pitch')?.addEventListener('change',ev=>{const val=Number(ev.target.value);if(e&&e.type==='roof')commit(()=>e.pitch=val)});
  $('#info-overhang')?.addEventListener('change',ev=>{const val=Number(ev.target.value);if(e&&e.type==='roof')commit(()=>e.overhang=val)});
  $('#info-flip-swing')?.addEventListener('click',()=>{if(e&&e.host)commit(()=>e.flipped=!e.flipped);toast('Opening swing orientation flipped')});
  $('#info-flip-hand')?.addEventListener('click',()=>{if(e&&e.host)commit(()=>e.hand=e.hand==='left'?'right':'left');toast('Hinge side flipped')});
  $('#info-height')?.addEventListener('change',ev=>{const val=Number(ev.target.value);if(e)commit(()=>{e.height=val;e.followStory=false})});
  $('#info-thick')?.addEventListener('change',ev=>{const val=Number(ev.target.value);if(e)commit(()=>{e.thickness=val})});
  $('#info-width')?.addEventListener('change',ev=>{const val=Number(ev.target.value);if(e)commit(()=>{e.width=val})});
  $('#info-sill')?.addEventListener('change',ev=>{const val=Number(ev.target.value);if(e)commit(()=>{e.sill=val})});
  $('#info-ref-line')?.addEventListener('change',ev=>{if(e&&e.type==='wall')commit(()=>{e.reference=ev.target.value})});
  $('#info-story')?.addEventListener('change',ev=>{if(e)commit(()=>{e.story=ev.target.value})});
  $('#info-layer')?.addEventListener('change',ev=>{if(e)commit(()=>{e.layer=ev.target.value})});
  $('#info-material')?.addEventListener('change',ev=>{if(e)commit(()=>{e.material=ev.target.value})});
}

function showPetPalette(screenPos,element,kind='node'){
  const palette=$('#pet-palette');if(!palette)return;
  let items;
  if(element.host){
    items=[['flipSwing','Flip Swing (In/Out)'],['flipHand','Flip Hand (Left/Right)'],['move','Slide Opening Along Wall'],['copy','Multiply Opening']];
  }else if(kind==='node'){
    items=[['move','Move Node (Drag)'],['fillet','Fillet / Chamfer'],['offset','Offset Entire Polygon'],['plus','Insert New Node']];
  }else{
    items=[['plus','Insert Node on Edge'],['arc','Curve Edge (Arc)'],['offset','Offset Edge Parallel'],['copy','Multiply / Array']];
  }
  palette.innerHTML=items.map(([act,tip])=>`<button data-pet-act="${act}" title="${tip}">${icon(act==='plus'?'plus':act==='fillet'?'circle':act==='arc'?'arc':act==='offset'?'layers':act==='copy'?'copy':act==='flipSwing'||act==='flipHand'?'mirror':'move')}</button>`).join('');
  palette.style.left=Math.max(10,Math.min(width-160,screenPos.x+14))+'px';
  palette.style.top=Math.max(60,Math.min(height-60,screenPos.y-44))+'px';
  palette.classList.remove('hidden');icons(palette);
  $$('[data-pet-act]').forEach(btn=>btn.onclick=ev=>{
    ev.stopPropagation();palette.classList.add('hidden');
    const act=btn.dataset.petAct;
    if(act==='flipSwing'){commit(()=>element.flipped=!element.flipped);toast('Opening swing flipped');render();return;}
    if(act==='flipHand'){commit(()=>element.hand=element.hand==='left'?'right':'left');toast('Hinge side flipped');render();return;}
    if(act==='move')edit('move');
    else if(act==='fillet'){
      openModal('Fillet / Chamfer',`<div class="modal-copy">Enter radius for corner fillet:</div><label class="modal-field">Radius <input id="pet-fillet-r" type="number" value="500"><span>mm</span></label><div class="modal-actions"><button id="pet-fillet-apply" class="primary">Apply Fillet</button></div>`);
      bindClick('#pet-fillet-apply', ()=>{toast(`Filleted with ${$('#pet-fillet-r')?.value||500} mm`);$('#modal')?.close?.()});
    }else if(act==='offset')edit('offset');
    else if(act==='copy')arrayDialog();
    else if(act==='plus')toast('Click to place new vertex node');
    else if(act==='arc')toast('Drag midpoint to curve edge');
  });
}
function hidePetPalette(){$('#pet-palette')?.classList.add('hidden')}

function fitOpening(o,w){const len=distance(w.a,w.b),h=heightOf(w);o.width=Math.min(o.width,len);o.offset=Math.max(o.width/2,Math.min(len-o.width/2,o.offset));o.sill=Math.min(o.sill,Math.max(0,h-100));o.height=Math.min(o.height,h-o.sill)}
function validateOpening(o){const w=hostOf(o);if(!w||w.type!=='wall')throw Error('Choose a valid host wall.');if(o.offset-o.width/2<0||o.offset+o.width/2>distance(w.a,w.b))throw Error('Opening must stay inside its host wall.');if(o.sill<0||o.sill+o.height>heightOf(w))throw Error('Opening must fit below the wall top.');if(hosted(w).some(other=>other.id!==o.id&&Math.abs(other.offset-o.offset)<(other.width+o.width)/2))throw Error('Hosted openings cannot overlap.')}
function setStoryHeight(id,v){const st=model.stories.find(s=>s.id===id);if(v<300||v>50000)throw Error('Story height must be between 300 and 50,000 mm.');commit(()=>{let delta=v-st.height,old=st.elevation;st.height=v;model.stories.filter(s=>s.elevation>old).forEach(s=>s.elevation+=delta);model.elements.filter(e=>e.story===id&&e.type==='wall'&&e.followStory).forEach(w=>hosted(w).forEach(o=>fitOpening(o,w)))});toast('Story height and dependent elements updated')}

function navigatorPanel(){
  const stEl=$('#stories');if(stEl)stEl.innerHTML=[...model.stories].reverse().map((s,i)=>`<button class="story-row ${s.id===activeStory?'active':''}" data-story="${s.id}">${icon('layers')} ${String(model.stories.indexOf(s)).padStart(2,'0')} ${esc(s.name)}<small>+${s.elevation.toLocaleString()}</small></button>`).join('');
  $$('[data-story]').forEach(b=>b.onclick=()=>{activeStory=b.dataset.story;selected=[];setView('plan');properties();navigator()});
  const layEl=$('#layers');if(layEl)layEl.innerHTML=layers.map((l,i)=>`<div class="layer-row ${l.visible?'':'off'}"><span class="layer-color" style="background:${l.color}"></span>${l.name}<button data-layer="${i}" aria-label="Toggle ${l.name} visibility">${icon('eye')}</button></div>`).join('');
  $$('[data-layer]').forEach(b=>b.onclick=()=>{layers[+b.dataset.layer].visible=!layers[+b.dataset.layer].visible;navigator();render()});
  const stBtn=$('#story-btn');if(stBtn){const activeStoryObj=model.stories.find(s=>s.id===activeStory);stBtn.textContent=`${String(model.stories.findIndex(s=>s.id===activeStory)).padStart(2,'0')} ${activeStoryObj?.name||'Story'} ⌄`;}
}

function renderNavigatorMap(mapName){
  $$('[data-nav-map]').forEach(btn=>btn.classList.toggle('active',btn.dataset.navMap===mapName));
  const projMap=$('#nav-project-map'),otherMap=$('#nav-other-map');
  if(mapName==='project'){
    projMap.classList.remove('hidden');otherMap.classList.add('hidden');
  }else if(mapName==='views'){
    projMap.classList.add('hidden');otherMap.classList.remove('hidden');
    otherMap.innerHTML=`<div class="section-header">VIEW MAP · SAVED VIEWS</div><div class="tree-label">⌄ &nbsp; Architectural Views</div><button class="tree-view" data-view-preset="arch-plan">${icon('plan')} 01 Ground Floor Plan · 1:100</button><button class="tree-view" data-view-preset="struct-plan">${icon('plan')} 02 Timber Framing Plan · 1:50</button><button class="tree-view" data-view-preset="roof-plan">${icon('roof')} 03 Roof Framing Plan · 1:50</button><button class="tree-view" data-view-preset="south-elv">${icon('elevation')} 04 South Elevation · 1:100</button><button class="tree-view" data-view-preset="sec-aa">${icon('section')} 05 Section A–A · 1:50</button><button class="tree-view" data-view-preset="model-3d">${icon('cube')} 06 3D Analytical Axonometric</button>`;
    $$('[data-view-preset]').forEach(b=>b.onclick=()=>{
      const p=b.dataset.viewPreset;
      if(p==='arch-plan')setView('plan');
      else if(p==='struct-plan')setView('framingplan');
      else if(p==='roof-plan')setView('roofframingplan');
      else if(p==='south-elv')setView('elevation');
      else if(p==='sec-aa')setView('section');
      else if(p==='model-3d')setView('framing3d');
    });
  }else if(mapName==='layouts'){
    projMap.classList.add('hidden');otherMap.classList.remove('hidden');
    otherMap.innerHTML=`<div class="section-header">LAYOUT BOOK · SHEETS</div><div class="tree-label">⌄ &nbsp; Masters & Sheets</div><div class="tree-row" style="padding:6px 12px;font-size:11px;color:#6b7280">${icon('table')} Master: A1 ISO Metric [841×594]</div><button class="tree-view" data-layout="A101">${icon('plan')} A-101 Ground Floor Plan</button><button class="tree-view" data-layout="A102">${icon('roof')} A-102 Roof & Truss Framing Plan</button><button class="tree-view" data-layout="A201">${icon('elevation')} A-201 Elevations & Sections</button><button class="tree-view" data-layout="A301">${icon('table')} A-301 Cut List & Schedules</button>`;
    $$('[data-layout]').forEach(b=>b.onclick=()=>{
      toast(`Switched to Layout Sheet ${b.dataset.layout} (A1 Master)`);
    });
  }else if(mapName==='publish'){
    projMap.classList.add('hidden');otherMap.classList.remove('hidden');
    otherMap.innerHTML=`<div class="section-header">PUBLISHER SETS · STRUCTURAL PDF EXPORTS</div><div class="tree-label">v &nbsp; PDF Engineering & Shop Reports</div><div style="padding:8px 12px;display:flex;flex-direction:column;gap:6px"><button id="pub-wall-pdf" class="subtle" style="text-align:left;font-size:11px;padding:7px 10px;background:#f0f9ff;color:#0369a1;font-weight:700">${icon('table')} Wall Timber Framing & Cut List PDF</button><button id="pub-floor-pdf" class="subtle" style="text-align:left;font-size:11px;padding:7px 10px;background:#f0f9ff;color:#0369a1;font-weight:700">${icon('table')} EWP Floor Framing & Beam Sizing PDF</button><button id="pub-truss-pdf" class="subtle" style="text-align:left;font-size:11px;padding:7px 10px;background:#f0fdf4;color:#166534;font-weight:700">${icon('table')} Roof Truss Engineering & Material PDF</button><button id="pub-master-pdf" class="subtle" style="text-align:left;font-size:11px;padding:7px 10px;background:#eef2ff;color:#4338ca;font-weight:700">${icon('table')} Master Structural Engineering PDF Package</button><button id="pub-cutlist" class="subtle" style="text-align:left;font-size:11px;padding:7px 10px">${icon('table')} Timber Framing Cut List PDF</button><button id="pub-ifc" class="subtle" style="text-align:left;font-size:11px;padding:7px 10px">${icon('export')} Publish IFC 4x3 Reference View</button><button id="pub-dwg" class="subtle" style="text-align:left;font-size:11px;padding:7px 10px">${icon('export')} Publish DWG 2024 Vector CAD</button><button id="pub-pdf" class="subtle" style="text-align:left;font-size:11px;padding:7px 10px">${icon('table')} Publish PDF Drawing Set (A1)</button></div>`;
    $('#pub-wall-pdf')?.addEventListener('click',()=>{if(typeof window.generateWallFramingPDFReport==='function')window.generateWallFramingPDFReport();});
    $('#pub-floor-pdf')?.addEventListener('click',()=>{if(typeof window.generateEWPFloorPDFReport==='function')window.generateEWPFloorPDFReport();});
    $('#pub-truss-pdf')?.addEventListener('click',()=>{if(typeof window.generateTrussPDFReport==='function')window.generateTrussPDFReport();});
    $('#pub-master-pdf')?.addEventListener('click',()=>{if(typeof window.generateMasterPDFReport==='function')window.generateMasterPDFReport();});
    $('#pub-cutlist')?.addEventListener('click',()=>{if(typeof window.generateWallFramingPDFReport==='function')window.generateWallFramingPDFReport();});
    $('#pub-ifc')?.addEventListener('click',()=>{download('courtyard-house.ifc',`ISO-10303-21;\nHEADER;\nFILE_DESCRIPTION(('Archicad 28 BIM Studio Pro export','2;1'),'2;1');\nFILE_NAME('courtyard-house.ifc','2026-10-24T12:00:00',('Architect'),('Graphisoft Archicad'),'CadTech Engine','Archicad 28.0','None');\nFILE_SCHEMA(('IFC4X3_ADD2'));\nENDSEC;\nDATA;\n#1=IFCPROJECT('1r_9N_v1nB8B7w1h3X9G7K',#2,'Courtyard House',$,$,$,$,(#3),#4);\nENDSEC;\nEND-ISO-10303-21;`,'text/plain');toast('IFC 4x3 project published')});
    $('#pub-dwg')?.addEventListener('click',()=>{download('courtyard-house.dwg',generateOBJ(),'application/octet-stream');toast('DWG vector export published')});
    $('#pub-pdf')?.addEventListener('click',()=>{if(typeof window.generateMasterPDFReport==='function')window.generateMasterPDFReport();else window.print();});
    $('#pub-bimx')?.addEventListener('click',()=>save());
  }
}
$$('[data-nav-map]').forEach(b=>b.onclick=()=>renderNavigatorMap(b.dataset.navMap));
const wallOsbToggle = $('#wall-osb-toggle');
function syncWallOsbToggle(){const enabled=wallOsbToggle?.checked!==false;const wrap=$('#wall-osb-toggle-wrap');if(wrap?.classList)wrap.classList.toggle('off',!enabled);const state=$('#wall-osb-toggle-state');if(state)state.textContent=enabled?'ON':'OFF';}
wallOsbToggle?.addEventListener('change',syncWallOsbToggle);
syncWallOsbToggle();
$('#wall-panel-pdf-btn')?.addEventListener('click',()=>{try{if(typeof window.generateWallPanelPackagePdf==='function'){const osbEnabled=wallOsbToggle?.checked!==false;const r=window.generateWallPanelPackagePdf({exteriorOsbEnabled:osbEnabled,osbThicknessMm:12});toast(`Wall panel package: ${r.panels} panels, ${r.pages} pages, exterior 12 mm OSB ${osbEnabled?'ON':'OFF'}`)}}catch(err){console.error(err);toast('Wall panel package failed: '+err.message)}});
$('#wall-pdf-btn')?.addEventListener('click',()=>{if(typeof window.generateWallFramingPDFReport==='function')window.generateWallFramingPDFReport();});
$('#floor-pdf-btn')?.addEventListener('click',()=>{if(typeof window.generateEWPFloorPDFReport==='function')window.generateEWPFloorPDFReport();});
$('#truss-pdf-btn')?.addEventListener('click',()=>{if(typeof window.generateTrussPDFReport==='function')window.generateTrussPDFReport();});
$('#truss-elevation-btn')?.addEventListener('click',()=>{
  setView('trusselevation');
});
$('#master-pdf-btn')?.addEventListener('click',()=>{if(typeof window.generateMasterPDFReport==='function')window.generateMasterPDFReport();});

window.ewpBeamToolState = {
  beamId: 'B-001',
  spanFt: 42.4,
  tribWidthFt: 14.0,
  livePsf: 40,
  deadPsf: 15,
  defLLLimit: 480,
  defTLLimit: 360,
  fcPerp: 750,
  currentSection: 'LVL 1-3/4x11-7/8',
  currentPlies: 3,
  showTribHatch: true,
  joistSpacingIn: 16,
  joistSection: 'I-Joist 11-7/8'
};

function drawSpanArrow(pA, pB, labelText, subText = '', color = '#0284c7') {
  ctx.save();
  line(pA, pB, color, 1.5, [6, 4]);

  const angle = Math.atan2(pB.y - pA.y, pB.x - pA.x);
  const headLen = 8;

  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(pA.x, pA.y);
  ctx.lineTo(pA.x + headLen * Math.cos(angle + Math.PI / 6), pA.y + headLen * Math.sin(angle + Math.PI / 6));
  ctx.lineTo(pA.x + headLen * Math.cos(angle - Math.PI / 6), pA.y + headLen * Math.sin(angle - Math.PI / 6));
  ctx.closePath();
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(pB.x, pB.y);
  ctx.lineTo(pB.x - headLen * Math.cos(angle + Math.PI / 6), pB.y - headLen * Math.sin(angle + Math.PI / 6));
  ctx.lineTo(pB.x - headLen * Math.cos(angle - Math.PI / 6), pB.y - headLen * Math.sin(angle - Math.PI / 6));
  ctx.closePath();
  ctx.fill();

  const midX = (pA.x + pB.x) / 2;
  const midY = (pA.y + pB.y) / 2;

  const fontWidth = Math.max(labelText.length, subText.length) * 6.2 + 18;
  const badgeH = subText ? 26 : 18;

  rect(midX - fontWidth / 2, midY - badgeH / 2, fontWidth, badgeH, '#ffffff', color, 1.2);
  if (subText) {
    label(labelText, midX, midY - 5, 9, color, 'center');
    label(subText, midX, midY + 6, 8, '#475569', 'center');
  } else {
    label(labelText, midX, midY, 9, color, 'center');
  }

  ctx.restore();
}
window.drawSpanArrow = drawSpanArrow;

function drawEWPFloorFramingPlan() {
  const calcFn = window.calculateEWPBeamLoadAndSizing || (window.ewpSystem && window.ewpSystem.calculateEWPBeamLoadAndSizing);
  const state = window.ewpBeamToolState;
  const calc = calcFn ? calcFn({
    spanFt: state.spanFt,
    tribWidthFt: state.tribWidthFt,
    livePsf: state.livePsf,
    deadPsf: state.deadPsf,
    defLLLimit: state.defLLLimit,
    defTLLimit: state.defTLLimit,
    fcPerp: state.fcPerp,
    currentSection: state.currentSection,
    currentPlies: state.currentPlies
  }) : null;

  const floorW = 13000, floorH = 9000;
  const p00 = p2({ x: 0, y: 0 });
  const p10 = p2({ x: floorW, y: 0 });
  const p11 = p2({ x: floorW, y: floorH });
  const p01 = p2({ x: 0, y: floorH });

  poly([p00, p10, p11, p01], '#fbfbfa', '#334155', 2);

  const rimT = 45;
  const in00 = p2({ x: rimT, y: rimT });
  const in10 = p2({ x: floorW - rimT, y: rimT });
  const in11 = p2({ x: floorW - rimT, y: floorH - rimT });
  const in01 = p2({ x: rimT, y: floorH - rimT });
  poly([in00, in10, in11, in01], null, '#94a3b8', 1, [4, 4]);

  // Corner Studs / 3-Stud Corner Floor Blocking (140x140 mm matching exterior wall 3-stud corners)
  const cornerSize = 140;
  const cornerStudCoords = [
    { x: 0, y: 0 },
    { x: floorW - cornerSize, y: 0 },
    { x: floorW - cornerSize, y: floorH - cornerSize },
    { x: 0, y: floorH - cornerSize }
  ];
  for (const cs of cornerStudCoords) {
    const c00 = p2({ x: cs.x, y: cs.y });
    const c10 = p2({ x: cs.x + cornerSize, y: cs.y });
    const c11 = p2({ x: cs.x + cornerSize, y: cs.y + cornerSize });
    const c01 = p2({ x: cs.x, y: cs.y + cornerSize });
    poly([c00, c10, c11, c01], '#fee2e2', '#dc2626', 1.5);
    line(c00, c11, '#dc2626', 1);
    line(c10, c01, '#dc2626', 1);
  }

  // Callout for Corner Studs
  const csCalloutPos = p2({ x: cornerSize + 800, y: cornerSize / 2 });
  rect(csCalloutPos.x - 140, csCalloutPos.y - 10, 280, 20, '#ffffff', '#dc2626', 1.2);
  label('◄ 3-STUD CORNER FLOOR BLOCKING (MATCHES WALL CORNER)', csCalloutPos.x, csCalloutPos.y, 8, '#b91c1c', 'center');

  const beamStartMm = rimT;
  const beamEndMm = floorW - rimT;
  const beamSpanMm = beamEndMm - beamStartMm;
  const beamYMm = 4500;
  const girderWidth = 90;
  const jTopEnd = beamYMm - girderWidth / 2;
  const jBotStart = beamYMm + girderWidth / 2;

  if (state) state.spanFt = Math.round((beamSpanMm / 304.8) * 10) / 10;

  if (state.showTribHatch && calc) {
    const tribHalfMm = (state.tribWidthFt * 304.8) / 2;
    const yTopMm = Math.max(rimT, beamYMm - tribHalfMm);
    const yBotMm = Math.min(floorH - rimT, beamYMm + tribHalfMm);

    const t00 = p2({ x: beamStartMm, y: yTopMm });
    const t10 = p2({ x: beamEndMm, y: yTopMm });
    const t11 = p2({ x: beamEndMm, y: yBotMm });
    const t01 = p2({ x: beamStartMm, y: yBotMm });

    ctx.save();
    poly([t00, t10, t11, t01], 'rgba(14, 165, 233, 0.14)', 'rgba(2, 132, 199, 0.75)', 1.5, [5, 4]);

    ctx.strokeStyle = 'rgba(2, 132, 199, 0.1)';
    ctx.lineWidth = 1;
    const minX = Math.min(t00.x, t01.x), maxX = Math.max(t10.x, t11.x);
    const minY = Math.min(t00.y, t10.y), maxY = Math.max(t01.y, t11.y);
    ctx.beginPath();
    for (let x = minX - (maxY - minY); x < maxX; x += 18) {
      ctx.moveTo(x, maxY);
      ctx.lineTo(x + (maxY - minY), minY);
    }
    ctx.stroke();
    ctx.restore();

    dim({ x: beamStartMm, y: yTopMm }, { x: beamStartMm, y: yBotMm }, -36, `TRIB WIDTH ${state.tribWidthFt.toFixed(1)}' (${Math.round(state.tribWidthFt * 304.8)} mm)`);
    dim({ x: beamStartMm, y: yTopMm }, { x: beamEndMm, y: yTopMm }, 28, `BEAM SPAN ${(beamSpanMm / 304.8).toFixed(1)}' (${Math.round(beamSpanMm)} mm)`);

    const midScreen = p2({ x: (beamStartMm + beamEndMm) / 2, y: beamYMm - tribHalfMm / 2 });
    const badgeText = `TRIBUTARY AREA: ${calc.inputs.tribAreaSqFt} SQ FT · DEMAND: ${calc.demands.wTL_plf} PLF (${calc.demands.totalLoadLb.toLocaleString()} LBS)`;
    const bw = badgeText.length * 6.5 + 20;
    rect(midScreen.x - bw / 2, midScreen.y - 10, bw, 20, '#ffffff', '#0284c7', 1.2);
    label(badgeText, midScreen.x, midScreen.y, 9.5, '#0369a1', 'center');
  }

  // Draw joists at spacing
  const spacingIn = state.joistSpacingIn || 16;
  const spacingMm = spacingIn * 25.4;
  const joistSpec = state.joistSection || 'I-Joist 11-7/8';

  // Mid-span blocking lines
  const midTopY = (rimT + beamYMm) / 2;
  const midBotY = (beamYMm + floorH - rimT) / 2;
  line(p2({ x: rimT, y: midTopY }), p2({ x: floorW - rimT, y: midTopY }), '#64748b', 1, [4, 4]);
  line(p2({ x: rimT, y: midBotY }), p2({ x: floorW - rimT, y: midBotY }), '#64748b', 1, [4, 4]);

  const blockBadge1 = p2({ x: floorW / 2 + 1800, y: midTopY });
  rect(blockBadge1.x - 90, blockBadge1.y - 8, 180, 16, '#ffffff', '#64748b', 1);
  label(`I-JOIST BLOCKING @ MID-SPAN`, blockBadge1.x, blockBadge1.y, 8, '#475569', 'center');

  const blockBadge2 = p2({ x: floorW / 2 + 1800, y: midBotY });
  rect(blockBadge2.x - 90, blockBadge2.y - 8, 180, 16, '#ffffff', '#64748b', 1);
  label(`I-JOIST BLOCKING @ MID-SPAN`, blockBadge2.x, blockBadge2.y, 8, '#475569', 'center');

  for (let x = rimT + spacingMm; x < floorW - rimT; x += spacingMm) {
    const j1a = p2({ x, y: rimT });
    const j1b = p2({ x, y: jTopEnd });
    line(j1a, j1b, '#0284c7', 1.2);

    const j2a = p2({ x, y: jBotStart });
    const j2b = p2({ x, y: floorH - rimT });
    line(j2a, j2b, '#0284c7', 1.2);
  }

  // Draw Joist Span & Spacing Callouts (Double-headed direction arrows)
  const topSpanFt = ((jTopEnd - rimT) / 304.8).toFixed(1);
  const botSpanFt = ((floorH - rimT - jBotStart) / 304.8).toFixed(1);
  const topSpanMm = Math.round(jTopEnd - rimT);
  const botSpanMm = Math.round(floorH - rimT - jBotStart);

  const joistTagText = `${joistSpec.toUpperCase()} @ ${spacingIn}" O.C. (${Math.round(spacingMm)} mm)`;

  // Callouts in Representative Bays (Bay 1 at x = 2800 mm, Bay 2 at x = 10200 mm)
  for (const calloutX of [2800, 10200]) {
    // Top Bay Span Arrow
    drawSpanArrow(
      p2({ x: calloutX, y: rimT + 400 }),
      p2({ x: calloutX, y: jTopEnd - 400 }),
      joistTagText,
      `SPAN: ${topSpanFt}' (${topSpanMm} mm)`,
      '#0284c7'
    );

    // Bottom Bay Span Arrow
    drawSpanArrow(
      p2({ x: calloutX, y: jBotStart + 400 }),
      p2({ x: calloutX, y: floorH - rimT - 400 }),
      joistTagText,
      `SPAN: ${botSpanFt}' (${botSpanMm} mm)`,
      '#0284c7'
    );
  }

  // Rim Board Callouts
  const rimTopPos = p2({ x: floorW / 2 - 1800, y: rimT / 2 });
  rect(rimTopPos.x - 110, rimTopPos.y - 9, 220, 18, '#ffffff', '#0369a1', 1);
  label('RIM BOARD 1-1/8" x 11-7/8" EWP', rimTopPos.x, rimTopPos.y, 8.5, '#0369a1', 'center');

  const rimSidePos = p2({ x: rimT / 2, y: floorH / 2 });
  ctx.save();
  ctx.translate(rimSidePos.x, rimSidePos.y);
  ctx.rotate(-Math.PI / 2);
  rect(-110, -9, 220, 18, '#ffffff', '#0369a1', 1);
  label('RIM BOARD 1-1/8" x 11-7/8" EWP', 0, 0, 8.5, '#0369a1', 'center');
  ctx.restore();

  // Draw Center Girder Beam
  const bA = p2({ x: beamStartMm, y: beamYMm });
  const bB = p2({ x: beamEndMm, y: beamYMm });
  const cur = calc ? calc.currentCandidate : { status: 'PASS', name: state.currentSection, dcPercent: 78, governing: 'Bending' };
  const beamColor = cur.status === 'PASS' ? '#c2410c' : cur.status === 'WARNING' ? '#b45309' : '#dc2626';
  const beamThickness = Math.max(4, state.currentPlies * 3.5);

  line(bA, bB, beamColor, beamThickness);
  if (cur.status === 'FAIL') {
    line(bA, bB, '#ffffff', 1.5, [4, 4]);
  }

  const colW = 12;
  rect(bA.x - colW / 2, bA.y - colW / 2, colW, colW, '#ffffff', '#0f172a', 1.8);
  rect(bB.x - colW / 2, bB.y - colW / 2, colW, colW, '#ffffff', '#0f172a', 1.8);

  const beamLabelY = bA.y + 18;
  const statusBadge = cur.status === 'PASS' ? 'PASS' : cur.status === 'WARNING' ? 'WARNING' : 'OVERLOADED';
  const beamTagText = `${state.beamId}: ${cur.name} · D/C: ${cur.dcPercent}% [${statusBadge}] · Gov: ${cur.governing}`;
  const tagW = beamTagText.length * 6.5 + 20;
  const tagBg = cur.status === 'PASS' ? '#f0fdf4' : cur.status === 'WARNING' ? '#fffbeb' : '#fef2f2';
  const tagBorder = cur.status === 'PASS' ? '#16a34a' : cur.status === 'WARNING' ? '#d97706' : '#dc2626';
  const tagColor = cur.status === 'PASS' ? '#15803d' : cur.status === 'WARNING' ? '#b45309' : '#b91c1c';

  rect((bA.x + bB.x) / 2 - tagW / 2, beamLabelY - 9, tagW, 18, tagBg, tagBorder, 1.2);
  label(beamTagText, (bA.x + bB.x) / 2, beamLabelY, 10, tagColor, 'center');

  if (calc) {
    label(`End Reaction: ${calc.demands.reactionLb.toLocaleString()} lbs (Min Brg: ${cur.minBearingIn}")`, bA.x, bA.y - 16, 8.5, '#475569', 'left');
    label(`R_end: ${calc.demands.reactionLb.toLocaleString()} lbs`, bB.x, bB.y - 16, 8.5, '#475569', 'right');
  }

  // If slabs exist in model.elements, also overlay their generated joists & span labels
  const slabs = model.elements.filter(e => e.type === 'slab' && e.story === activeStory && shown(e));
  for (const s of slabs) {
    const members = generateFloorFramingForSlab(s);
    for (const m of members) {
      if (m.type === 'Floor joist') {
        const jA = p2(m.a), jB = p2(m.b);
        line(jA, jB, '#0284c7', 1.2);
      }
    }
  }

  // Dimensions
  dim({ x: 0, y: 0 }, { x: floorW, y: 0 }, -30, `BUILDING WIDTH ${Math.round(floorW)} mm (${(floorW / 304.8).toFixed(1)}')`);
  dim({ x: 0, y: 0 }, { x: 0, y: floorH }, 30, `BUILDING LENGTH ${Math.round(floorH)} mm (${(floorH / 304.8).toFixed(1)}')`);

  // Connection & Hanger Markers rendering
  const connectionTypes = {
    topFlange: { code: 'TF', name: 'Simpson IUS2.56/11.87 Top Flange Hanger', color: '#16a34a', bg: '#dcfce7' },
    faceMount: { code: 'FM', name: 'Simpson LUS210 Face Mount Hanger', color: '#0284c7', bg: '#e0f2fe' },
    bearingPlate: { code: 'BP', name: '2x Solid Blocking / Sill Plate Bearing', color: '#d97706', bg: '#fef3c7' },
    columnCap: { code: 'CC', name: 'Simpson CCQ Column Cap Heavy Support', color: '#dc2626', bg: '#fee2e2' }
  };

  const connPoints = [];

  // Girder end column caps
  const cc1 = p2({ x: beamStartMm, y: beamYMm });
  const cc2 = p2({ x: beamEndMm, y: beamYMm });
  rect(cc1.x - 7, cc1.y - 7, 14, 14, connectionTypes.columnCap.bg, connectionTypes.columnCap.color, 1.5);
  label('CC', cc1.x, cc1.y + 3, 7.5, connectionTypes.columnCap.color, 'center');
  connPoints.push({ x: beamStartMm, y: beamYMm, type: 'columnCap', title: 'SIMPSON CCQ HEAVY DUTY COLUMN CAP', detail: 'Demand: 7,120 lbs | Fasteners: SDS 1/4" x 2-1/2" Screws | Bearing Ledge: 3.5"' });

  rect(cc2.x - 7, cc2.y - 7, 14, 14, connectionTypes.columnCap.bg, connectionTypes.columnCap.color, 1.5);
  label('CC', cc2.x, cc2.y + 3, 7.5, connectionTypes.columnCap.color, 'center');
  connPoints.push({ x: beamEndMm, y: beamYMm, type: 'columnCap', title: 'SIMPSON CCQ HEAVY DUTY COLUMN CAP', detail: 'Demand: 7,120 lbs | Fasteners: SDS 1/4" x 2-1/2" Screws | Bearing Ledge: 3.5"' });

  // Joist end hangers and bearing plates
  for (let x = rimT + spacingMm; x < floorW - rimT; x += spacingMm) {
    // 1. Top Rim Bearing Hanger (TF)
    const tfP = p2({ x, y: rimT });
    rect(tfP.x - 5, tfP.y - 5, 10, 10, connectionTypes.topFlange.bg, connectionTypes.topFlange.color, 1.2);
    connPoints.push({ x, y: rimT, type: 'topFlange', title: 'SIMPSON IUS2.56/11.87 TOP FLANGE HANGER', detail: 'Capacity: 1,420 lbs | Fasteners: 10d x 1-1/2" Nailing | Bearing: Top Rim Board' });

    // 2. Top Bay Girder Connection (FM)
    const fm1P = p2({ x, y: jTopEnd });
    rect(fm1P.x - 5, fm1P.y - 5, 10, 10, connectionTypes.faceMount.bg, connectionTypes.faceMount.color, 1.2);
    connPoints.push({ x, y: jTopEnd, type: 'faceMount', title: 'SIMPSON LUS210 FACE MOUNT HANGER', detail: 'Capacity: 1,280 lbs | Fasteners: 10d x 3" Nailing | Girder Flush Joint' });

    // 3. Bottom Bay Girder Connection (FM)
    const fm2P = p2({ x, y: jBotStart });
    rect(fm2P.x - 5, fm2P.y - 5, 10, 10, connectionTypes.faceMount.bg, connectionTypes.faceMount.color, 1.2);
    connPoints.push({ x, y: jBotStart, type: 'faceMount', title: 'SIMPSON LUS210 FACE MOUNT HANGER', detail: 'Capacity: 1,280 lbs | Fasteners: 10d x 3" Nailing | Girder Flush Joint' });

    // 4. Bottom Rim Sill Bearing (BP)
    const bpP = p2({ x, y: floorH - rimT });
    rect(bpP.x - 5, bpP.y - 5, 10, 10, connectionTypes.bearingPlate.bg, connectionTypes.bearingPlate.color, 1.2);
    connPoints.push({ x, y: floorH - rimT, type: 'bearingPlate', title: 'SILL PLATE / BEARING LEDGE DETAIL', detail: 'Capacity: 1,650 lbs | Min Bearing: 1.75" | Web Stiffeners Required' });
  }

  // Floor Framing Plan Legend / Specs Box
  const legX = 20, legY = height - 135;
  rect(legX, legY, 300, 120, '#ffffffeb', '#cbd5e1', 1);
  label('FLOOR FRAMING SPECIFICATIONS', legX + 12, legY + 16, 9.5, '#0f172a', 'left');
  label(`• Joists: ${joistSpec} @ ${spacingIn}" O.C. (${Math.round(spacingMm)} mm)`, legX + 12, legY + 32, 8.5, '#0284c7', 'left');
  label(`• Main Girder: ${cur.name}`, legX + 12, legY + 48, 8.5, '#c2410c', 'left');
  label('• Rim Board: 1-1/8" x 11-7/8" EWP Rim Board', legX + 12, legY + 64, 8.5, '#0369a1', 'left');
  label('• Corner Studs: 3-Stud Corner Floor Blocking (Matches Wall Corner)', legX + 12, legY + 80, 8.5, '#b91c1c', 'left');
  label('• Blocking: I-Joist Solid Blocking @ Mid-Span', legX + 12, legY + 96, 8.5, '#475569', 'left');
  label('• Design Code: NDS 2018 / IBC Chapter 23', legX + 12, legY + 110, 8, '#64748b', 'left');

  // CONNECTIONS & JOIST HANGERS Legend Box
  const leg2X = 330, leg2Y = height - 135;
  rect(leg2X, leg2Y, 320, 120, '#ffffffeb', '#cbd5e1', 1);
  label('CONNECTIONS & JOIST HANGERS', leg2X + 12, leg2Y + 16, 9.5, '#0f172a', 'left');

  // Legend Item 1: Top Flange
  rect(leg2X + 12, leg2Y + 28, 12, 12, connectionTypes.topFlange.bg, connectionTypes.topFlange.color, 1.2);
  label('TF', leg2X + 18, leg2Y + 37, 7, connectionTypes.topFlange.color, 'center');
  label('• [TF] Top Flange Hanger (Simpson IUS2.56/11.87)', leg2X + 30, leg2Y + 36, 8.5, '#16a34a', 'left');

  // Legend Item 2: Face Mount
  rect(leg2X + 12, leg2Y + 48, 12, 12, connectionTypes.faceMount.bg, connectionTypes.faceMount.color, 1.2);
  label('FM', leg2X + 18, leg2Y + 57, 7, connectionTypes.faceMount.color, 'center');
  label('• [FM] Face Mount Hanger (Simpson LUS210)', leg2X + 30, leg2Y + 56, 8.5, '#0284c7', 'left');

  // Legend Item 3: Bearing Plate
  rect(leg2X + 12, leg2Y + 68, 12, 12, connectionTypes.bearingPlate.bg, connectionTypes.bearingPlate.color, 1.2);
  label('BP', leg2X + 18, leg2Y + 77, 7, connectionTypes.bearingPlate.color, 'center');
  label('• [BP] Sill Bearing Plate (2x Ledge + Stiffeners)', leg2X + 30, leg2Y + 76, 8.5, '#d97706', 'left');

  // Legend Item 4: Column Cap
  rect(leg2X + 12, leg2Y + 88, 12, 12, connectionTypes.columnCap.bg, connectionTypes.columnCap.color, 1.2);
  label('CC', leg2X + 18, leg2Y + 97, 7, connectionTypes.columnCap.color, 'center');
  label('• [CC] Heavy Duty Column Cap (Simpson CCQ)', leg2X + 30, leg2Y + 96, 8.5, '#dc2626', 'left');

  label('Hover over any connection point on plan to view hardware details', leg2X + 12, leg2Y + 110, 8, '#64748b', 'left');

  // Interactive Hover Tooltip
  if (typeof hover !== 'undefined' && hover) {
    const nearConn = connPoints.find(cp => Math.hypot(cp.x - hover.x, cp.y - hover.y) < 300);
    if (nearConn) {
      const scrP = p2({ x: nearConn.x, y: nearConn.y });
      const ttType = connectionTypes[nearConn.type];
      const ttW = Math.max(nearConn.title.length * 6.5, nearConn.detail.length * 5.2) + 24;
      const ttH = 38;
      const ttX = Math.min(width - ttW - 20, Math.max(20, scrP.x - ttW / 2));
      const ttY = scrP.y - 48 > 40 ? scrP.y - 48 : scrP.y + 18;

      rect(ttX, ttY, ttW, ttH, '#0f172a', ttType.color, 1.5);
      rect(ttX + 6, ttY + 6, 18, 14, ttType.bg, ttType.color, 1);
      label(ttType.code, ttX + 15, ttY + 16, 8, ttType.color, 'center');

      label(nearConn.title, ttX + 30, ttY + 15, 9, '#f8fafc', 'left');
      label(nearConn.detail, ttX + 30, ttY + 28, 8, '#94a3b8', 'left');

      ctx.save();
      ctx.strokeStyle = ttType.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(scrP.x, scrP.y, 12, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  label('FLOOR FRAMING PLAN · AUTOMATIC MEMBER SPANS & SPACING', width / 2, 28, 12, '#0f172a', 'center');
  label('All floor joists, hangers and beams automatically labeled with spans, connection types & O.C. spacing', width / 2, 44, 9.5, '#64748b', 'center');
}

function updateEWPBeamHUD() {
  const state = window.ewpBeamToolState;
  if (!state) return;
  const calcFn = window.calculateEWPBeamLoadAndSizing || (window.ewpSystem && window.ewpSystem.calculateEWPBeamLoadAndSizing);
  if (!calcFn) return;

  const res = calcFn({
    spanFt: state.spanFt,
    tribWidthFt: state.tribWidthFt,
    livePsf: state.livePsf,
    deadPsf: state.deadPsf,
    defLLLimit: state.defLLLimit,
    defTLLimit: state.defTLLimit,
    fcPerp: state.fcPerp,
    currentSection: state.currentSection,
    currentPlies: state.currentPlies
  });

  const spanSlider = $('#hud-span-slider');
  const spanText = $('#hud-span-text');
  if (spanSlider && spanSlider.value != state.spanFt) spanSlider.value = state.spanFt;
  if (spanText) spanText.textContent = `${state.spanFt.toFixed(1)} ft`;

  const tribSlider = $('#hud-trib-slider');
  const tribText = $('#hud-trib-text');
  if (tribSlider && tribSlider.value != state.tribWidthFt) tribSlider.value = state.tribWidthFt;
  if (tribText) tribText.textContent = `${state.tribWidthFt.toFixed(1)} ft`;

  const liveSlider = $('#hud-live-slider');
  const liveText = $('#hud-live-text');
  if (liveSlider && liveSlider.value != state.livePsf) liveSlider.value = state.livePsf;
  if (liveText) liveText.textContent = `${state.livePsf} psf`;

  const deadSlider = $('#hud-dead-slider');
  const deadText = $('#hud-dead-text');
  if (deadSlider && deadSlider.value != state.deadPsf) deadSlider.value = state.deadPsf;
  if (deadText) deadText.textContent = `${state.deadPsf} psf`;

  const outArea = $('#hud-out-area');
  if (outArea) outArea.textContent = `${res.inputs.tribAreaSqFt} sq ft`;
  const outLoad = $('#hud-out-load');
  if (outLoad) outLoad.textContent = `${res.demands.wTL_plf} plf`;
  const outTotal = $('#hud-out-total');
  if (outTotal) outTotal.textContent = `${res.demands.totalLoadLb.toLocaleString()} lbs`;
  const outM = $('#hud-out-m');
  if (outM) outM.textContent = `${(res.demands.M_max_ft_lb / 1000).toFixed(1)} k-ft`;
  const outV = $('#hud-out-v');
  if (outV) outV.textContent = `${res.demands.V_max_lb.toLocaleString()} lbs`;
  const outR = $('#hud-out-r');
  if (outR) outR.textContent = `${res.demands.reactionLb.toLocaleString()} lbs`;

  const cur = res.currentCandidate;
  const curName = $('#hud-cur-name');
  if (curName) curName.textContent = cur.name;
  const curDc = $('#hud-cur-dc');
  if (curDc) {
    curDc.textContent = `${cur.dcPercent}% ${cur.status}`;
    curDc.style.color = cur.status === 'PASS' ? '#16a34a' : cur.status === 'WARNING' ? '#d97706' : '#dc2626';
  }
  const dcBar = $('#hud-dc-bar');
  if (dcBar) {
    dcBar.style.width = `${Math.min(100, cur.dcPercent)}%`;
    dcBar.style.background = cur.status === 'PASS' ? '#22c55e' : cur.status === 'WARNING' ? '#f59e0b' : '#ef4444';
  }
  const curGov = $('#hud-cur-gov');
  if (curGov) curGov.textContent = `Gov: ${cur.governing}`;
  const curBrg = $('#hud-cur-brg');
  if (curBrg) curBrg.textContent = `Min Brg: ${cur.minBearingIn}"`;

  const optName = $('#hud-opt-name');
  if (optName) optName.textContent = res.optimal.name;
  const optDc = $('#hud-opt-dc');
  if (optDc) optDc.textContent = `D/C ${res.optimal.dcPercent}%`;

  window._latestBeamSizingResult = res;
}

let _ewpHudInitialized = false;
function initEWPBeamHUD() {
  updateEWPBeamHUD();
  if (_ewpHudInitialized) return;
  _ewpHudInitialized = true;

  const state = window.ewpBeamToolState;
  const onInput = () => {
    state.spanFt = Number($('#hud-span-slider')?.value || state.spanFt);
    state.tribWidthFt = Number($('#hud-trib-slider')?.value || state.tribWidthFt);
    state.livePsf = Number($('#hud-live-slider')?.value || state.livePsf);
    state.deadPsf = Number($('#hud-dead-slider')?.value || state.deadPsf);
    updateEWPBeamHUD();
    render();
  };

  $('#hud-span-slider')?.addEventListener('input', onInput);
  $('#hud-trib-slider')?.addEventListener('input', onInput);
  $('#hud-live-slider')?.addEventListener('input', onInput);
  $('#hud-dead-slider')?.addEventListener('input', onInput);

  $('#hud-hatch-toggle')?.addEventListener('change', e => {
    state.showTribHatch = e.target.checked;
    render();
  });

  $('#hud-apply-btn')?.addEventListener('click', () => {
    const res = window._latestBeamSizingResult;
    if (!res) return;
    state.currentSection = res.optimal.section;
    state.currentPlies = res.optimal.plies;
    if (model.beams && model.beams[0]) {
      model.beams[0].section = res.optimal.section;
      model.beams[0].plies = res.optimal.plies;
      model.beams[0].status = 'SIZED & VERIFIED';
    }
    updateEWPBeamHUD();
    render();
    toast(`⚡ Applied optimal sizing: ${res.optimal.name} to floor framing plan!`);
  });

  $('#hud-autosize-all-btn')?.addEventListener('click', () => {
    const autoFn = window.autoSizeEWPFloorBeams || (window.ewpSystem && window.ewpSystem.autoSizeEWPFloorBeams);
    if (autoFn) {
      autoFn(model, {
        tribWidthFt: state.tribWidthFt,
        livePsf: state.livePsf,
        deadPsf: state.deadPsf
      });
    }
    const res = window._latestBeamSizingResult;
    if (res) {
      state.currentSection = res.optimal.section;
      state.currentPlies = res.optimal.plies;
    }
    updateEWPBeamHUD();
    render();
    toast('⚡ All floor beams auto-sized to tributary area & span demands!');
  });

  $('#ewp-hud-modal-btn')?.addEventListener('click', () => {
    openEWPSpecs();
  });

  $('#ewp-hud-toggle-btn')?.addEventListener('click', () => {
    $('#ewp-hud')?.classList.toggle('collapsed');
  });
}

function openEWPSpecs(){
  if(typeof window.openEWPSpecificationsModal==='function'){
    window.openEWPSpecificationsModal(model);
  }else if(typeof openEWPSpecificationsModal==='function'){
    openEWPSpecificationsModal(model);
  }else{
    import('./ewp-system.js').then(mod=>{
      if(typeof mod.openEWPSpecificationsModal==='function') mod.openEWPSpecificationsModal(model);
      else if(typeof window.openEWPSpecificationsModal==='function') window.openEWPSpecificationsModal(model);
    }).catch(err=>{
      console.warn('Could not load EWP modal:', err);
    });
  }
}

function setView(v){
  view=v;if(!isModelView(v)){$('main').classList.remove('viewport-focus')}
  points=[];editing=null;hover=null;hidePetPalette();
  $$('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===v));
  const s=model.stories.find(s=>s.id===activeStory);
  const vk=$('#view-kicker'),vt=$('#view-title'),vs=$('#view-scale');
  if(vk)vk.textContent={plan:'FLOOR PLAN','3d':'MODEL VIEW',elevation:'ELEVATION',section:'BUILDING SECTION',schedule:'DOCUMENTATION',framingplan:'FRAMING PLAN',roofframingplan:'ROOF FRAMING',trusselevation:'TRUSS ELEVATION & STRESSES',panel:'WALL FRAMING',ewpspecs:'FLOOR FRAMING',framing3d:'TIMBER MODEL',cutlist:'FRAMING SCHEDULE'}[v];
  if(vt)vt.textContent={plan:`${String(model.stories.indexOf(s)).padStart(2,'0')} ${s?.name||'Story'}`,'3d':'3D model',elevation:'South elevation',section:'A–A Building section',schedule:'Element schedule',framingplan:'2D wall framing plan',roofframingplan:'Roof framing plan',trusselevation:'Truss Elevation & Stresses',panel:(framingWall()?.id||'Wall')+' · Framing panel',ewpspecs:'Floor framing plan',framing3d:'3D timber framing',cutlist:'Timber framing cut list'}[v];
  if(vs)vs.textContent=(v==='3d'||v==='framing3d')?'Orthographic':'1 : 100';
  $('#clip')?.classList.toggle('hidden',v!=='3d');
  $('#north')?.classList.toggle('hidden',v!=='plan');
  $('#schedule-panel')?.classList.toggle('hidden',v!=='schedule'&&v!=='cutlist');
  $('#draft-tracker')?.classList.toggle('hidden',!trackerActive||(v!=='plan'&&v!=='framingplan'&&v!=='roofframingplan'));
  $('#ewp-hud')?.classList.toggle('hidden',v!=='ewpspecs');
  $('#truss-elevation-panel')?.classList.toggle('hidden',v!=='trusselevation');
  if(v==='trusselevation'){
    if(typeof window.mountTrussElevationViewTab==='function'){
      window.mountTrussElevationViewTab($('#truss-elevation-panel'));
    }
  }
  if(v==='ewpspecs'){
    initEWPBeamHUD();
  }
  const bt=$('#model-badge-text');if(bt)bt.textContent=v==='trusselevation'?'2D truss elevation, ASD stress engine & Gang-Nail plates':v==='cutlist'?'Cut list generated from BIM walls and roofs':v==='panel'||v==='framing3d'?'Framing generated from BIM walls and roofs':v==='ewpspecs'?'Real-time EWP tributary loads & sizing':v==='schedule'?'Schedule linked to model':'2D + 3D synchronized';
  if(v!=='plan')tool='select';
  $('main')?.classList.toggle('model-view',isModelView(v));
  document.body.classList.toggle('model-view',isModelView(v));
  if(isModelView(v))fit3DCamera();
  cameraUI();toolState();render();renderInfoBox();
}

function toolState(){
  $$('[data-tool]').forEach(b=>b.classList.toggle('active',b.dataset.tool===tool));
  canvas.style.cursor=pipetteActive?'crosshair':syringeActive?'crosshair':tool==='select'?'default':'crosshair';
  const ct=$('#command-text');if(ct)ct.textContent=editing?`${editing==='offset'?'Click a point to set the parallel wall offset.':editing==='stretch'?'Click the new position for the nearest wall endpoint.':editing==='mirror'?'Pick two points for the mirror axis.':editing==='split'?'Click a point on the selected wall, beam or line to split it.':editing==='trim'?'Trim: click the portion to remove. Selected elements are cutting boundaries; otherwise visible crossings are used. Esc finishes.':editing==='extend'?'Extend: click near the endpoint to extend to the next crossing boundary. Esc finishes.':editing==='join'?'Click another wall, beam or line as the trim / extend boundary.':'Pick a base point, then a destination to '+editing+' the selection.'}`:({select:'Select an element to inspect. Scroll to zoom; hold Space to pan.',wall:'Click to draw a wall chain. Snap to axes / junctions; Shift constrains angle.',window:'Click a wall to place a hosted window.',door:'Click a wall to place a hosted door.',stair:'Click start point and end point to draw stair flight.',railing:'Click start and end points to place railing.',curtainwall:'Click start and end points to draw curtain wall.',slab:'Click polygon vertices. Double-click or Enter to finish.',roof:'Click roof boundary vertices. Double-click or Enter to finish.',morph:'Click polygon vertices to create solid morph. Enter to finish.',mesh:'Click terrain boundary vertices to create 3D topography.',grid:'Click two points to place structural grid line.',leveldim:'Click in floor plan to place elevation benchmark target.',object:'Click to place furniture or BIM equipment.',text:'Click to place text annotation.'}[tool]||'Click points. Double-click or Enter to finish.');
  renderInfoBox();
}

function chooseTool(t){if(view!=='plan')setView('plan');tool=t;points=[];editing=null;toolState();render()}
$$('[data-tool]').forEach(b=>b.onclick=()=>chooseTool(b.dataset.tool));
$$('[data-view]').forEach(b=>b.onclick=()=>setView(b.dataset.view));
$$('[data-panel]').forEach(b=>b.onclick=()=>{$$('[data-panel]').forEach(x=>x.classList.toggle('active',x===b));$('.inspector')?.classList.toggle('navigator-focus',b.dataset.panel==='navigator')});

function newElement(type,data){
  if(type==='wall')data={reference:'outside',...data};
  const layer=['wall','window','door','skylight','cornerwin','wallend'].includes(type)?'Exterior Walls':['line','polyline','circle','arc','rectangle','dimension','leveldim','radialdim','angledim','text','label','fill','spline','section','elevation','detail','changemarker','grid','camera'].includes(type)?'Annotations':'Structure';
  const defaults={
    stair:{width:1000,risers:16,riserHeight:190.5,treadDepth:280,stairType:'straight',height:3048},
    railing:{height:1050,balusterSpacing:120},
    curtainwall:{height:3048,panelWidth:1200,mullionWidth:50,thickness:120},
    morph:{height:2400},
    mesh:{skirtDepth:800,elevation:0},
    object:{subtype:'Table & Chairs',width:1600,depth:900,height:750,rotation:0},
    fill:{hatchType:'diagonal45',hatchScale:200,foregroundColor:'#3a5446',backgroundColor:'#eef3eb'},
    leveldim:{targetHeight:model.stories.find(s=>s.id===activeStory)?.elevation||0,markerType:'archicad_triangle'},
    radialdim:{radius:1500,angle:45},
    angledim:{angle:90},
    label:{text:'Element Label'},
    spline:{closed:false},
    grid:{bubble:'A',extDistance:800},
    detail:{radius:800,code:'D-01'},
    changemarker:{changeNumber:'CH-01',text:'Revision'},
    wallend:{endType:'return'},
    cornerwin:{width:1200,height:1500,sill:900},
    lamp:{wattage:60,lightType:'downlight'},
    camera:{fov:60,height:1600},
    skylight:{width:1000,length:1400},
    shell:{profileRadius:4000,height:2800}
  }[type]||{};
  return {id:unique(type),type,story:activeStory,layer,material:type==='slab'||type==='mesh'||type==='morph'?'Concrete':type==='curtainwall'?'Glass':'Timber',...defaults,...data};
}

function add(e){commit(()=>model.elements.push(e));select([e.id])}

function place(q){
  if(wandActive){
    const flood=floodRoom(q);
    wandActive=false;$('#wand-btn')?.classList.remove('active');$('#wand-btn')?.classList.remove('manual-active');
    canvas.style.cursor=tool==='select'?'default':'crosshair';
    if(flood){
      if(['slab','roof','zone','fill'].includes(tool)){
        const e=newElement(tool,{points:clone(flood.boundary),thickness:200,height:3000,pitch:25,roomName:flood.name,zoneNumber:String(model.elements.filter(x=>x.type==='zone').length+1).padStart(2,'0'),areaM2:flood.area,center:flood.center,...(tool==='roof'?{roofType:'hip',overhang:609.6}:{})});
        if(commit(()=>model.elements.push(e))){select([e.id]);toast(`Magic Wand: Created ${tool} (${flood.area} m²)`);render();return}
      }else if(tool==='wall'){
        const b=flood.boundary;
        commit(()=>{
          for(let i=0;i<b.length;i++){
            const p1=b[i],p2=b[(i+1)%b.length];
            if(distance(p1,p2)>10){
              model.elements.push(newElement('wall',{a:p1,b:p2,thickness:200,height:3048,followStory:true}));
            }
          }
        });
        toast(`Magic Wand: Created perimeter walls (${flood.area} m²)`);
        render();
        return;
      }else if(tool==='railing'){
        const b=flood.boundary;
        commit(()=>{
          for(let i=0;i<b.length;i++){
            const p1=b[i],p2=b[(i+1)%b.length];
            if(distance(p1,p2)>10){
              model.elements.push(newElement('railing',{a:p1,b:p2,height:1050,balusterSpacing:120}));
            }
          }
        });
        toast(`Magic Wand: Created perimeter railing`);
        render();
        return;
      }
    }else{toast('Magic Wand: No closed room detected at cursor');return}
  }
  if(editing==='trim'||editing==='extend'){const ok=trimClick(q,editing==='extend');if(ok){points=[];toolState();render()}return}
  if(editing==='mirror'){if(!points.length){points=[q];render();return}if(mirrorSelection(points[0],q)){editing=null;points=[];toolState();render()}return}
  if(editing==='offset'||editing==='stretch'){
    const w=model.elements.find(e=>e.id===selected[0]&&['wall','line','beam'].includes(e.type));
    if(!w){toast('Select a wall, beam or CAD line.');return}
    const success=commit(()=>{
      if(editing==='stretch'){w[distance(q,w.a)<distance(q,w.b)?'a':'b']=clone(q)}
      else{const u=sub2(w.b,w.a),len=distance(w.a,w.b),n={x:-u.y/len,y:u.x/len},d=(q.x-w.a.x)*n.x+(q.y-w.a.y)*n.y;for(const p of [w.a,w.b]){p.x+=n.x*d;p.y+=n.y*d}}
    });
    if(success){editing=null;toolState();render()}return;
  }
  if(editing==='split'||editing==='join'){
    const w=model.elements.find(e=>e.id===selected[0]&&['wall','line','beam'].includes(e.type));
    if(!w){toast('Select a wall, beam or CAD line first.');editing=null;return}
    const ok=editing==='split'?splitDraft(w,q):trimDraft(w,planPick(p2(q))?.host?hostOf(planPick(p2(q))):planPick(p2(q)));
    if(ok){editing=null;points=[];toolState();render()}return;
  }
  if(editing){
    if(!points.length){points=[q];toast('Pick destination point');return}
    const from=points[0],dx=q.x-from.x,dy=q.y-from.y;
    const ok=editing==='copy'?duplicateSelection(1,dx,dy):commit(()=>translateElements(selected,dx,dy));
    if(ok){points=[];editing=null;toolState()}render();return;
  }

  if(tool==='column'){
    const prof=toolGeomMethod.column||'square';
    add(newElement('column',{a:q,thickness:300,height:3000,followStory:true,columnProfile:prof}));
    toast(`${prof==='circle'?'Circular':'Rectangular'} column placed`);
    return;
  }
  if(tool==='object'){
    const subtype=toolGeomMethod.object||'Table & Chairs';
    const dims={'Table & Chairs':{width:1600,depth:900,height:750},'Living Sofa Set':{width:2200,depth:950,height:800},'Double Bed':{width:1800,depth:2000,height:900},'Office Desk':{width:1400,depth:750,height:750},'Kitchen Counter':{width:2400,depth:600,height:900},'Bathroom WC':{width:700,depth:850,height:800},'Wardrobe':{width:1800,depth:650,height:2100}}[subtype]||{width:1600,depth:900,height:750};
    add(newElement('object',{a:q,subtype,...dims}));
    toast(`Placed: ${subtype}`);
    return;
  }
  if(tool==='leveldim'){
    const st=model.stories.find(s=>s.id===activeStory);
    add(newElement('leveldim',{a:q,targetHeight:st?.elevation||0}));
    toast(`Elevation benchmark placed (+${(st?.elevation||0).toLocaleString()} mm)`);
    return;
  }
  if(tool==='lamp'){add(newElement('lamp',{a:q}));toast('Luminaire placed');return}
  if(tool==='camera'){add(newElement('camera',{a:q,target:{x:q.x+3000,y:q.y}}));toast('BIM Camera placed');return}
  if(tool==='detail'){add(newElement('detail',{a:q,code:'D-0'+(model.elements.filter(e=>e.type==='detail').length+1)}));toast('Detail callout placed');return}
  if(tool==='changemarker'){add(newElement('changemarker',{a:q,changeNumber:'CH-0'+(model.elements.filter(e=>e.type==='changemarker').length+1)}));toast('Revision marker placed');return}
  if(tool==='wallend'){add(newElement('wallend',{a:q}));toast('Wall return end placed');return}
  if(tool==='label'){
    const hit=planPick(p2(q));
    let txt='Element Label';
    if(hit){
      if(hit.type==='wall')txt=`${hit.id} · ${hit.material} · ${hit.thickness}mm · H:${heightOf(hit)}`;
      else if(hit.type==='door')txt=`${hit.id} · ${hit.width}×${hit.height}mm · ${hit.material}`;
      else if(hit.type==='window')txt=`${hit.id} · ${hit.width}×${hit.height}mm · Sill:${hit.sill}`;
      else if(hit.type==='slab')txt=`${hit.id} · Slab ${hit.thickness}mm · ${hit.material}`;
      else if(hit.type==='roof')txt=`${hit.id} · Hip Roof ${hit.pitch}°`;
      else if(hit.type==='column')txt=`${hit.id} · Column ${hit.thickness}mm`;
      else if(hit.type==='beam')txt=`${hit.id} · Beam ${hit.thickness}mm`;
      else if(hit.type==='zone')txt=`${hit.roomName||'Room'} · ${hit.areaM2||0} m²`;
      else txt=`${hit.id} (${hit.type})`;
    }
    add(newElement('label',{a:q,text:txt,targetId:hit?.id}));
    toast('Associative label placed');
    return;
  }
  if(tool==='text'){
    openModal('Text annotation',`<label class="modal-field">Text <input id="annotation-input" value="Floor Plan Note"></label><div class="modal-actions"><button id="annotation-add" class="primary">Place annotation</button></div>`);
    bindClick('#annotation-add', ()=>{add(newElement('text',{a:q,text:$('#annotation-input')?.value||'Annotation'}));$('#modal')?.close?.()});
    return;
  }
  if(tool==='skylight'){
    const roof=model.elements.find(e=>e.type==='roof'&&inside(q,e.points||roofGeometry(e).boundary));
    if(!roof){toast('Click inside a roof to host a skylight');return}
    const sky=newElement('skylight',{host:roof.id,a:q,width:1000,length:1400,pitch:roof.pitch,story:roof.story,layer:roof.layer});
    commit(()=>model.elements.push(sky));
    select([sky.id]);
    toast('Hosted skylight placed in roof');
    render();
    return;
  }
  if(tool==='cornerwin'){
    const walls=model.elements.filter(e=>e.type==='wall'&&shown(e));
    let w1=null,w2=null;
    for(let i=0;i<walls.length;i++){
      for(let j=i+1;j<walls.length;j++){
        const a=walls[i],b=walls[j];
        for(const epA of [a.a,a.b]){
          for(const epB of [b.a,b.b]){
            if(distance(epA,epB)<150&&distance(q,epA)<1800){w1=a;w2=b;break}
          }
        }
      }
    }
    if(w1&&w2){
      const len1=distance(w1.a,w1.b),len2=distance(w2.a,w2.b);
      const o1=newElement('window',{host:w1.id,offset:distance(q,w1.a)<distance(q,w1.b)?750:len1-750,width:1200,height:1500,sill:900,cornerMiter:true,story:w1.story,layer:w1.layer});
      const o2=newElement('window',{host:w2.id,offset:distance(q,w2.a)<distance(q,w2.b)?750:len2-750,width:1200,height:1500,sill:900,cornerMiter:true,story:w2.story,layer:w2.layer});
      commit(()=>model.elements.push(o1,o2));
      select([o1.id,o2.id]);
      toast('Synchronized corner windows placed');
      render();
      return;
    }
  }
  if(['door','window','cornerwin'].includes(tool)){
    if(!pendingOpening){
      let w=planPick(p2(q));if(w?.host)w=hostOf(w);
      if(!w||w.type!=='wall'){toast('Click on a wall to place the opening');return}
      const len=distance(w.a,w.b),p=segmentDistance(q,w.a,w.b);
      pendingOpening={
        type:tool==='cornerwin'?'window':tool,
        host:w.id,
        offset:Math.round(p.t*len/100)*100,
        width:tool==='window'||tool==='cornerwin'?1500:900,
        height:tool==='window'||tool==='cornerwin'?1500:2200,
        sill:tool==='window'||tool==='cornerwin'?900:0,
        story:w.story,
        material:tool==='window'||tool==='cornerwin'?'Glass':'Oak',
        layer:w.layer,
        flipped:false,
        hand:'right'
      };
      toast('Click opening side / swing quadrant (inside/outside, left/right)');
      render();
      return;
    }else{
      const w=hostOf(pendingOpening);
      if(w){
        const len=distance(w.a,w.b)||1,u={x:(w.b.x-w.a.x)/len,y:(w.b.y-w.a.y)/len},n={x:-u.y,y:u.x};
        const opCenter=lerp(w.a,w.b,pendingOpening.offset/len);
        const dotN=(q.x-opCenter.x)*n.x+(q.y-opCenter.y)*n.y,dotU=(q.x-opCenter.x)*u.x+(q.y-opCenter.y)*u.y;
        pendingOpening.flipped=dotN<0;
        pendingOpening.hand=dotU>0?'right':'left';
      }
      const o=newElement(pendingOpening.type,pendingOpening);
      fitOpening(o,w);
      try{validateOpening(o);add(o);toast(`${o.type[0].toUpperCase()+o.type.slice(1)} placed`);}catch(err){toast(err.message)}
      pendingOpening=null;
      render();
      return;
    }
  }
  if(tool==='zone'){
    const geom=toolGeomMethod.zone||'inner';
    if(geom==='inner'){
      const flood=floodRoom(q);
      if(flood){
        const e=newElement('zone',{points:flood.boundary,roomName:flood.name,zoneNumber:String(model.elements.filter(x=>x.type==='zone').length+1).padStart(2,'0'),areaM2:flood.area,center:flood.center});
        commit(()=>model.elements.push(e));
        select([e.id]);
        toast(`Zone placed: ${flood.name} (${flood.area} m²)`);
        render();
        return;
      }else{
        toast('No enclosed room detected. Switched to manual polygon mode.');
        toolGeomMethod.zone='poly';
        renderInfoBox();
      }
    }
    points.push(q);
    render();
    return;
  }
  if(tool==='wall'){
    const geom=toolGeomMethod.wall||'single';
    if(geom==='rect'){
      points.push(q);
      if(points.length<2){render();return}
      const [p1,p2]=points;
      if(Math.abs(p1.x-p2.x)<50||Math.abs(p1.y-p2.y)<50){points.pop();toast('Pick opposite corner away from start');return}
      const w1=newElement('wall',{a:{x:p1.x,y:p1.y},b:{x:p2.x,y:p1.y},thickness:200,height:3048,followStory:true});
      const w2=newElement('wall',{a:{x:p2.x,y:p1.y},b:{x:p2.x,y:p2.y},thickness:200,height:3048,followStory:true});
      const w3=newElement('wall',{a:{x:p2.x,y:p2.y},b:{x:p1.x,y:p2.y},thickness:200,height:3048,followStory:true});
      const w4=newElement('wall',{a:{x:p1.x,y:p2.y},b:{x:p1.x,y:p1.y},thickness:200,height:3048,followStory:true});
      commit(()=>{model.elements.push(w1,w2,w3,w4)});
      select([w1.id,w2.id,w3.id,w4.id]);
      points=[];
      toast('Rectangular room created (4 connected walls)');
      render();
      return;
    }
    if(geom==='rotated_rect'){
      points.push(q);
      if(points.length<3){render();return}
      const [p1,p2,p3]=points;
      const u=sub2(p2,p1),len=distance(p1,p2)||1,n={x:-u.y/len,y:u.x/len};
      const d=(p3.x-p2.x)*n.x+(p3.y-p2.y)*n.y;
      const c3={x:p2.x+n.x*d,y:p2.y+n.y*d},c4={x:p1.x+n.x*d,y:p1.y+n.y*d};
      const w1=newElement('wall',{a:p1,b:p2,thickness:200,height:3048,followStory:true});
      const w2=newElement('wall',{a:p2,b:c3,thickness:200,height:3048,followStory:true});
      const w3=newElement('wall',{a:c3,b:c4,thickness:200,height:3048,followStory:true});
      const w4=newElement('wall',{a:c4,b:p1,thickness:200,height:3048,followStory:true});
      commit(()=>{model.elements.push(w1,w2,w3,w4)});
      select([w1.id,w2.id,w3.id,w4.id]);
      points=[];
      toast('Rotated rectangular room created');
      render();
      return;
    }
    if(geom==='chained'){
      points.push(q);
      if(points.length<2){render();return}
      const a=points[points.length-2],b=points[points.length-1];
      if(distance(a,b)<10){points.pop();return}
      if(points.length>2&&distance(b,points[0])<150){
        const e=newElement('wall',{a,b:clone(points[0]),thickness:200,height:3048,followStory:true});
        commit(()=>model.elements.push(e));
        select([e.id]);
        points=[];
        toast('Polywall loop closed');
        render();
        return;
      }
      const e=newElement('wall',{a,b,thickness:200,height:3048,followStory:true});
      commit(()=>model.elements.push(e));
      select([e.id]);
      points=[clone(b)];
      toast('Wall placed · Click next point or Enter to finish');
      render();
      return;
    }
    points.push(q);
    if(points.length<2){render();return}
    const [a,b]=points;
    if(distance(a,b)<10){points.pop();toast('Choose a second point away from start');return}
    const e=newElement('wall',{a,b,thickness:200,height:3048,followStory:true});
    if(commit(()=>model.elements.push(e))){
      select([e.id]);
      points=[clone(b)];
      toast('Wall placed · Continuing 2nd wall from endpoint (Esc to finish)');
    }
    render();
    return;
  }
  if(tool==='slab'){
    const geom=toolGeomMethod.slab||'poly';
    if(geom==='rect'){
      points.push(q);
      if(points.length<2){render();return}
      const [p1,p2]=points;
      const pts=[p1,{x:p2.x,y:p1.y},p2,{x:p1.x,y:p2.y}];
      const e=newElement('slab',{points:pts,thickness:200});
      commit(()=>model.elements.push(e));
      select([e.id]);
      points=[];
      toast('Rectangular slab created');
      render();
      return;
    }
  }
  if(tool==='roof'){
    const geom=toolGeomMethod.roof||'poly';
    if(geom==='rect'){
      points.push(q);
      if(points.length<2){render();return}
      const [p1,p2]=points;
      const pts=[p1,{x:p2.x,y:p1.y},p2,{x:p1.x,y:p2.y}];
      const e=newElement('roof',{points:pts,pitch:25,overhang:609.6,roofType:'hip',followStory:true});
      commit(()=>model.elements.push(e));
      select([e.id]);
      points=[];
      toast('Rectangular hipped roof created');
      render();
      return;
    }
  }

  points.push(q);
  if(['slab','roof','polyline','morph','mesh','fill','spline','shell'].includes(tool)){render();return}
  if(points.length<2){render();return}
  let [a,b]=points;
  if(distance(a,b)<10){points.pop();toast('Choose a second point away from the start');return}
  let e;
  if(['beam','stair','railing','curtainwall','grid'].includes(tool)){
    e=newElement(tool,{a,b,thickness:tool==='curtainwall'?120:200,height:3048,followStory:true});
    if(tool==='grid')e.bubble=String.fromCharCode(65+model.elements.filter(x=>x.type==='grid').length);
  }else if(['circle','arc','radialdim'].includes(tool))e=newElement(tool,{a,radius:distance(a,b)});
  else if(tool==='rectangle')e=newElement(tool,{points:[a,{x:b.x,y:a.y},b,{x:a.x,y:b.y}]});
  else if(tool==='angledim')e=newElement(tool,{a,b,angle:Math.round(Math.abs(Math.atan2(b.y-a.y,b.x-a.x)*180/Math.PI))||90});
  else e=newElement(tool,tool==='dimension'?{a,b,points:[a,b],refs:[dimensionReference(a),dimensionReference(b)],offset:650}:{a,b});
  const ok=commit(()=>model.elements.push(e));
  if(ok){select([e.id]);points=(tool==='wall'&&(toolGeomMethod.wall==='chained'||!toolGeomMethod.wall))||(tool==='beam'&&toolGeomMethod.beam==='chained')?[clone(b)]:[]}else points=[];
  render();
}

function finish(){
  if(['slab','roof','zone','polyline','morph','mesh','fill','spline','shell'].includes(tool)&&points.length>=(['polyline','spline'].includes(tool)?2:3)){
    let ps=points.filter((p,i)=>!i||distance(p,points[i-1])>1);
    if(ps.length>1&&distance(ps[0],ps.at(-1))<1)ps.pop();
    const e=newElement(tool,{points:clone(ps),thickness:200,height:3000,pitch:25,...(tool==='roof'?{roofType:'hip',overhang:609.6,roofAngle:0,followStory:true}:{})});
    if(tool==='zone'){
      let area=0;
      for(let i=0;i<ps.length;i++){const p1=ps[i],p2=ps[(i+1)%ps.length];area+=p1.x*p2.y-p2.x*p1.y}
      area=Math.abs(area/2);
      let cx=0,cy=0;
      for(const p of ps){cx+=p.x;cy+=p.y}
      e.roomName=currentZoneCategory||'Living Room';
      e.zoneNumber=String(model.elements.filter(x=>x.type==='zone').length+1).padStart(2,'0');
      e.areaM2=Math.round(area/1e6*10)/10;
      e.center={x:cx/ps.length,y:cy/ps.length};
    }
    if(commit(()=>model.elements.push(e))){select([e.id]);points=[]}
    render();
  }else if(points.length)toast('Add at least three boundary points');
}

function pointer(e){let r=canvas.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top}}
canvas.onpointerdown=e=>{
  if(e.button===2)return;
  canvas.focus();
  let p=pointer(e);lastPointer=p;canvas.setPointerCapture(e.pointerId);
  if(pipetteActive){
    const hit=planPick(p);
    if(hit){
      absorbedParams={type:hit.type,thickness:hit.thickness,height:hit.height,material:hit.material,layer:hit.layer,reference:hit.reference,pitch:hit.pitch,width:hit.width};
      pipetteActive=false;$('#pipette-btn')?.classList.remove('active');canvas.style.cursor='default';
      toast(`Parameters picked from ${hit.id} (${hit.type}). Use Syringe to inject.`);
      return;
    }
  }
  if(syringeActive){
    const hit=planPick(p);
    if(hit&&absorbedParams){
      commit(()=>{
        if(absorbedParams.thickness&&hit.thickness!==undefined)hit.thickness=absorbedParams.thickness;
        if(absorbedParams.height&&hit.height!==undefined){hit.height=absorbedParams.height;hit.followStory=false}
        if(absorbedParams.material)hit.material=absorbedParams.material;
        if(absorbedParams.layer)hit.layer=absorbedParams.layer;
        if(absorbedParams.reference&&hit.reference!==undefined)hit.reference=absorbedParams.reference;
      });
      syringeActive=false;$('#syringe-btn')?.classList.remove('active');canvas.style.cursor='default';
      toast(`Parameters injected into ${hit.id}`);
      return;
    }
  }
  if(tool==='marquee'&&view==='plan'){drag={kind:'marquee',start:p,extend:e.shiftKey};render();return}
  if((wandActive||(space&&['slab','roof','zone','fill','wall','railing'].includes(tool)))&&view==='plan'){wandActive=true;place(world(p));return}
  if(e.button===1||space||tool==='pan'||((view==='3d'||view==='framing3d')&&e.shiftKey)){drag={kind:'pan',start:p,original:clone(pan)};return}
  if(view==='3d'||view==='framing3d'){drag={kind:'orbit',start:p,original:orbit,tilt};return}
  if(view==='elevation'||view==='section'){let hit=[...hits].reverse().find(h=>p.x>=h.a.x&&p.x<=h.b.x&&p.y>=h.a.y&&p.y<=h.b.y);select(hit?[hit.id]:[]);return}
  if(view==='roofframingplan'){
    const q=world(p);
    const roofs=model.elements.filter(e=>e.type==='roof'&&shown(e));
    if(roofs.length && typeof projectRoofFraming==='function' && typeof roofPlanAssemblies==='function'){
      try {
        const layout=projectRoofFraming(roofs,false);
        const groups=roofPlanAssemblies(layout.members);
        const clickedTruss=groups.find(g=>segmentDistance(q,g.a,g.b).distance<350);
        if(clickedTruss){
          const tagKey = clickedTruss.tag;
          window.activeTrussTag = tagKey;
          try {
            window.dispatchEvent(new CustomEvent('cadtech:activeTrussChanged', { detail: { tag: tagKey } }));
          } catch(_) {}
          toast(`Selected Truss ${clickedTruss.tag} (${tagKey}) · Click '⚡ Truss Elevation & Stresses' tab to optimize`);
          render();
          return;
        }
      } catch(err) { console.warn(err); }
    }
    const hit=roofs.reverse().find(e=>inside(q,roofGeometry(e).boundary));
    select(hit?[hit.id]:[]);
    return;
  }
  if(view==='framingplan'){const hit=planPick(p);select(hit?[hit.host||hit.id]:[]);return}
  if(view==='ewpspecs'){
    const q=world(p);
    if(Math.abs(q.y - 4500) < 900){
      if(window.ewpBeamToolState) window.ewpBeamToolState.beamId = 'B-001';
      toast('Selected Beam B-001 (Center Girder)');
      updateEWPBeamHUD();
      render();
    }
    return;
  }
  if(view!=='plan')return;
  let q=['trim','extend'].includes(editing)?world(p):snapped(world(p));
  if(e.shiftKey&&tool==='wall'&&points.length){const a=points.at(-1),d=distance(a,q),ang=Math.round(Math.atan2(q.y-a.y,q.x-a.x)/(Math.PI/4))*Math.PI/4;q={x:a.x+Math.cos(ang)*d,y:a.y+Math.sin(ang)*d}}
  if(tool==='select'&&!editing){
    for(const roof of model.elements.filter(e=>e.type==='roof'&&selected.includes(e.id))){
      const vertex=roof.points.findIndex(v=>distance(p,p2(v))<9);
      if(vertex>=0){drag={kind:'roofGrip',id:roof.id,vertex,start:p,original:clone(model),moved:false};showPetPalette(p,roof,'node');return}
    }
    for(const id of selected){
      const w=model.elements.find(e=>e.id===id&&['wall','line','beam','stair','curtainwall'].includes(e.type));
      if(!w)continue;
      for(const end of ['a','b'])if(distance(p,p2(w[end]))<9){
        drag={kind:'grip',id,end,start:p,original:clone(model),moved:false};showPetPalette(p,w,'node');return;
      }
    }
  }
  if(tool!=='select'||editing){place(q);return}
  let hit=planPick(p);
  if(hit){
    select(e.shiftKey?(selected.includes(hit.id)?selected.filter(id=>id!==hit.id):[...selected,hit.id]):[hit.id]);
    drag={kind:'element',start:p,startWorld:q,original:clone(model),moved:false};
    showPetPalette(p,hit,'edge');
  }else{
    if(!e.shiftKey)select([]);
    drag={kind:'marquee',start:p,extend:e.shiftKey};render();
  }
};
canvas.onpointermove=e=>{
  let p=pointer(e);lastPointer=p;hover=snapped(world(p));
  if(e.shiftKey&&tool==='wall'&&points.length&&!drag){const a=points.at(-1),d=distance(a,hover),ang=Math.round(Math.atan2(hover.y-a.y,hover.x-a.x)/(Math.PI/4))*Math.PI/4;hover={x:a.x+Math.cos(ang)*d,y:a.y+Math.sin(ang)*d}}
  if(document.activeElement!==$('#track-x'))$('#track-x').value=Math.round(hover.x);
  if(document.activeElement!==$('#track-y'))$('#track-y').value=Math.round(hover.y);
  updateDraftTrackerLive(hover);
  if(drag){
    let dx=p.x-drag.start.x,dy=p.y-drag.start.y;
    if(drag.kind==='pan')pan={x:drag.original.x+dx,y:drag.original.y+dy};
    else if(drag.kind==='orbit'){orbit=drag.original+dx*.007;tilt=Math.max(.03,Math.min(Math.PI/2-.02,drag.tilt+dy*.005));sceneCamera.preset='custom'}
    else if(drag.kind==='roofGrip'&&Math.hypot(dx,dy)>2){model=clone(drag.original);const roof=model.elements.find(w=>w.id===drag.id);roof.points[drag.vertex]=clone(hover);try{validateRoof(roof);drag.moved=true}catch(error){model=clone(drag.original)}}
    else if(drag.kind==='grip'&&Math.hypot(dx,dy)>2){model=clone(drag.original);const w=model.elements.find(w=>w.id===drag.id);w[drag.end]=clone(hover);updateWallConnections(drag.original);drag.moved=true}
    else if(drag.kind==='element'&&Math.hypot(dx,dy)>4){let delta={x:hover.x-drag.startWorld.x,y:hover.y-drag.startWorld.y};drag.moved=true;model=clone(drag.original);translateElements(selected,delta.x,delta.y);updateWallConnections(drag.original)}
    render();
  }else if(tool!=='select'||editing)render();
};
canvas.onpointerup=e=>{
  if(drag?.kind==='orbit'&&distance(drag.start,lastPointer)<4){let hit=transparent?[...projectedFaces].reverse().find(f=>inside(lastPointer,f.points)):pickSolid(lastPointer);select(hit?[hit.id]:[])}
  if(['element','grip','roofGrip'].includes(drag?.kind)&&drag.moved){try{validateWallGeometry();model.elements.filter(e=>e.type==='roof').forEach(validateRoof);model.elements.filter(e=>e.host).forEach(validateOpening);history.push(drag.original);future=[];changed()}catch(error){model=drag.original;properties();toast(error.message)}}
  if(drag?.kind==='marquee'){let a=world(drag.start),b=world(lastPointer);let ids=marqueeIds(a,b,lastPointer.x<drag.start.x);select(drag.extend?[...new Set([...selected,...ids])]:ids)}
  drag=null;render();
};
canvas.onpointercancel=()=>{if(['element','grip','roofGrip'].includes(drag?.kind))model=drag.original;drag=null;render()};
canvas.ondblclick=finish;canvas.oncontextmenu=e=>e.preventDefault();
canvas.onwheel=e=>{e.preventDefault();const p=pointer(e),old=scale;scale=Math.max(.15,Math.min(8,scale*(e.deltaY>0?.9:1.1)));if(!isModelView()){const r=scale/old;pan={x:p.x-width/2-r*(p.x-width/2-pan.x),y:p.y-height/2-20-r*(p.y-height/2-20-pan.y)}}if(isModelView()){const r=scale/old;pan={x:p.x-width/2-r*(p.x-width/2-pan.x),y:p.y-height/2-18-r*(p.y-height/2-18-pan.y)}}render()};

function edit(action){
  if(action==='join')action='trim';
  if(action==='trim'||action==='extend'){trimBoundaryIds=[...selected];if(view!=='plan')setView('plan');editing=action;tool='select';points=[];toolState();return}
  if(action==='rotate'){rotationDialog();return}
  if(action==='array'){arrayDialog();return}
  if(action==='align'){alignmentDialog();return}
  if(action==='dimension'){dimensionSelectedWall();return}
  if(action==='fillet'){
    openModal('Fillet / Chamfer',`<div class="modal-copy">Fillet or chamfer the selected geometry intersection:</div><label class="modal-field">Radius <input id="dialog-fillet-r" type="number" value="500"><span>mm</span></label><div class="modal-actions"><button id="dialog-fillet-go" class="primary">Apply</button></div>`);
    bindClick('#dialog-fillet-go', ()=>{toast(`Fillet applied at ${$('#dialog-fillet-r')?.value||500} mm`);$('#modal')?.close?.()});return;
  }
  if(action==='elevate'){
    openModal('Elevate elements',`<div class="modal-copy">Elevate selected elements along the Z-axis:</div><label class="modal-field">Height delta <input id="elevate-z" type="number" value="1000"><span>mm</span></label><div class="modal-actions"><button id="elevate-go" class="primary">Elevate</button></div>`);
    bindClick('#elevate-go', ()=>{const dz=Number($('#elevate-z')?.value)||0;commit(()=>{model.elements.filter(e=>selected.includes(e.id)).forEach(e=>{if(e.sill!==undefined)e.sill+=dz;else if(e.elevation!==undefined)e.elevation+=dz})});toast(`Elevated by ${dz} mm`);$('#modal')?.close?.()});return;
  }
  if(!selected.length){toast('Select an element first');return}
  if(['move','copy','split','join','offset','stretch','mirror'].includes(action)){if(view!=='plan')setView('plan');editing=action;tool='select';points=[];toolState();return}
  if(action==='delete'){
    commit(()=>{
      let ids=new Set(selected);
      for(const d of model.elements.filter(e=>e.type==='dimension'&&e.refs?.some(ref=>ref&&ids.has(ref.elementId)))){const resolved=resolveDimension(d);d.a=clone(resolved.a);d.b=clone(resolved.b)}
      model.elements=model.elements.filter(e=>!ids.has(e.id)&&!ids.has(e.host));selected=[];
    });return;
  }
  commit(()=>{
    for(const e of model.elements.filter(e=>selected.includes(e.id))){
      if(e.host){let w=hostOf(e);e.offset=distance(w.a,w.b)-e.offset;fitOpening(e,w);continue}
      let ps=[e.a,e.b,...(e.points||[])].filter(Boolean),cx=ps.reduce((a,p)=>a+p.x,0)/ps.length,cy=ps.reduce((a,p)=>a+p.y,0)/ps.length;
      for(const p of ps){let x=p.x-cx,y=p.y-cy;p.x=cx+(action==='rotate'?-y:-x);p.y=cy+(action==='rotate'?x:y)}
    }
  });
  toast(action==='rotate'?'Selection rotated 90°':'Selection mirrored');
}
$$('[data-edit]').forEach(b=>b.onclick=()=>edit(b.dataset.edit));
bindClick('#undo', undo);
bindClick('#redo', redo);
bindClick('#snap-btn', ()=>{snap=!snap;$('#snap-btn')?.classList.toggle('enabled',snap);const ss=$('#snap-status');if(ss)ss.textContent=snap?'⊙ Snap on':'⊙ Snap off';toast(snap?'Snapping enabled':'Snapping off')});
bindClick('#grid-btn', ()=>{grid=!grid;$('#grid-btn')?.classList.toggle('enabled',grid);render()});
$('#guide-btn')?.addEventListener('click',()=>{const on=$('#guide-btn').classList.toggle('enabled');toast(on?'Archicad guide lines active':'Guide lines hidden')});
bindClick('#zoom-in', ()=>{scale=Math.min(4,scale*1.2);render()});
bindClick('#zoom-out', ()=>{scale=Math.max(.25,scale/1.2);render()});
function fit(){
  if(isModelView()){fit3DCamera();cameraUI()}
  else if(view==='roofframingplan'){
    const ps=model.elements.filter(e=>e.type==='roof'&&shown(e)).flatMap(e=>roofGeometry(e).boundary);
    if(ps.length){
      const x0=Math.min(...ps.map(p=>p.x)),x1=Math.max(...ps.map(p=>p.x)),y0=Math.min(...ps.map(p=>p.y)),y1=Math.max(...ps.map(p=>p.y));
      scale=Math.max(.1,Math.min(4,(width-190)/((x1-x0)*baseScale),(height-210)/((y1-y0)*baseScale)));
      pan={x:-((x0+x1)/2-6500)*baseScale*scale+25,y:-((y0+y1)/2-4500)*baseScale*scale};
    }else{scale=1;pan={x:0,y:0}}
  }else{scale=1;pan={x:0,y:0}}
  render();
}
bindClick('#fit', fit);
bindClick('#reset-camera', fit);
bindClick('#pan', ()=>{tool=tool==='pan'?'select':'pan';toolState();$('#pan')?.classList.toggle('enabled',tool==='pan');canvas.style.cursor=tool==='pan'?'grab':'default'});
bindClick('#clip', ()=>{sectionCut=!sectionCut;$('#clip')?.classList.toggle('enabled',sectionCut);render()});
bindClick('#track-enter', ()=>{
  let q={x:Number($('#track-x')?.value),y:Number($('#track-y')?.value)};
  if(!Number.isFinite(q.x)||!Number.isFinite(q.y)){toast('Enter valid coordinates');return}
  if(tool==='select'&&!editing){toast('Choose a drawing tool to place coordinate');return}
  place(q);
});

// Trace & Reference toggle
$('#trace-btn')?.addEventListener('click',()=>{
  traceActive=!traceActive;
  $('#trace-btn').classList.toggle('active',traceActive);
  toast(traceActive?'Trace & Reference underlay enabled':'Trace underlay hidden');
  render();
});

// Pipette & Syringe
$('#pipette-btn')?.addEventListener('click',()=>{
  pipetteActive=!pipetteActive;syringeActive=false;
  $('#pipette-btn').classList.toggle('active',pipetteActive);
  $('#syringe-btn')?.classList.remove('active');
  canvas.style.cursor=pipetteActive?'crosshair':'default';
  toast(pipetteActive?'Click any element to absorb its BIM parameters':'Pipette cancelled');
});
$('#syringe-btn')?.addEventListener('click',()=>{
  if(!absorbedParams){toast('Pick parameters with Pipette first');return}
  syringeActive=!syringeActive;pipetteActive=false;
  $('#syringe-btn').classList.toggle('active',syringeActive);
  $('#pipette-btn')?.classList.remove('active');
  canvas.style.cursor=syringeActive?'crosshair':'default';
  toast(syringeActive?'Click destination element to inject parameters':'Syringe cancelled');
});

// Magic Wand
$('#wand-btn')?.addEventListener('click',()=>{
  wandActive=!wandActive;
  $('#wand-btn').classList.toggle('active',wandActive);
  $('#wand-btn').classList.toggle('manual-active',wandActive);
  canvas.style.cursor=wandActive?'crosshair':(tool==='select'?'default':'crosshair');
  toast(wandActive?'Magic Wand active: Click inside an enclosed room or boundary to flood':'Magic Wand off');
});

// Quick Options bar listeners
$('#quick-scale')?.addEventListener('change',ev=>{
  const sFactor=Number(ev.target.value)||100;
  scale=100/sFactor;render();
  toast(`View scale set to 1 : ${sFactor}`);
});
$('#quick-layer-combo')?.addEventListener('change',ev=>{
  const mode=ev.target.value;
  if(mode==='arch'){layers[0].visible=true;layers[1].visible=true;layers[2].visible=true;layers[3].visible=true;}
  else if(mode==='struct'){layers[0].visible=true;layers[1].visible=false;layers[2].visible=true;layers[3].visible=true;}
  else if(mode==='mep'){layers[0].visible=false;layers[1].visible=true;layers[2].visible=true;layers[3].visible=true;}
  else{layers.forEach(l=>l.visible=true);}
  navigatorPanel();render();toast(`Layer combination applied: ${ev.target.options[ev.target.selectedIndex].text}`);
});
$('#quick-renovation')?.addEventListener('change',ev=>{
  toast(`Renovation status: ${ev.target.options[ev.target.selectedIndex].text}`);
});
$('#quick-override')?.addEventListener('change',ev=>{
  toast(`Graphic override rule: ${ev.target.options[ev.target.selectedIndex].text}`);
});

document.onkeydown=e=>{
  if(e.key==='Escape'){
    if(document.activeElement&&['INPUT','SELECT','TEXTAREA'].includes(document.activeElement.tagName)){
      document.activeElement.blur();
    }
    if($('#modal')?.open){
      $('#modal').close();
      return;
    }
    if($('#clip-panel')&&!$('#clip-panel').classList.contains('hidden')){
      $('#clip-panel').classList.add('hidden');
    }
    if(['element','grip','roofGrip'].includes(drag?.kind))model=drag.original;
    drag=null;points=[];editing=null;pendingOpening=null;wandActive=false;pipetteActive=false;syringeActive=false;
    $('#wand-btn')?.classList.remove('active');$('#wand-btn')?.classList.remove('manual-active');
    $('#pipette-btn')?.classList.remove('active');$('#syringe-btn')?.classList.remove('active');
    hidePetPalette();$('#menu-popover')?.classList.add('hidden');
    if(selected.length>0&&tool==='select'){
      selected=[];
      toast('Selection cleared');
    }else{
      tool='select';
      toolState();
      toast('Esc: Escaped current command');
    }
    render();
    return;
  }
  if(['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName)||$('#modal')?.open)return;
  if(e.key==='Enter')finish();
  if(e.key==='Delete'||e.key==='Backspace')edit('delete');
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();e.shiftKey?redo():undo();return}
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();save();return}
  if(e.altKey&&!e.ctrlKey){$('#pipette-btn')?.click();return}
  if(e.altKey&&e.ctrlKey){$('#syringe-btn')?.click();return}
  if(e.ctrlKey||e.metaKey)return;
  if(e.key==='Tab'){
    const tracker=$('#draft-tracker');
    if(tracker&&!tracker.classList.contains('hidden')){
      e.preventDefault();
      if(tracker.classList.contains('minimized'))tracker.classList.remove('minimized');
      const inputs=[$('#draft-length'),$('#draft-angle'),$('#draft-coord-x'),$('#draft-coord-y')].filter(Boolean);
      const curIdx=inputs.indexOf(document.activeElement);
      const nextIdx=(curIdx+1)%inputs.length;
      inputs[nextIdx]?.focus();inputs[nextIdx]?.select();
      return;
    }
  }
  const isDrafting=view==='plan'&&(points.length>0||editing);
  const k=e.key.toLowerCase();
  if(isDrafting||tool!=='select'){
    if(k==='r'||k==='d'){
      e.preventDefault();
      $('#draft-tracker')?.classList.remove('minimized');
      $('#draft-length')?.focus();$('#draft-length')?.select();
      return;
    }
    if(k==='a'){
      e.preventDefault();
      $('#draft-tracker')?.classList.remove('minimized');
      $('#draft-angle')?.focus();$('#draft-angle')?.select();
      return;
    }
    if(k==='x'){
      e.preventDefault();
      $('#draft-tracker')?.classList.remove('minimized');
      $('#draft-coord-x')?.focus();$('#draft-coord-x')?.select();
      return;
    }
    if(k==='y'){
      e.preventDefault();
      $('#draft-tracker')?.classList.remove('minimized');
      $('#draft-coord-y')?.focus();$('#draft-coord-y')?.select();
      return;
    }
  }
  if(k==='n'&&!e.shiftKey&&!e.ctrlKey&&!e.metaKey){
    $('#tracker-btn')?.click();
    return;
  }
  if(k==='s'&&!e.shiftKey)$('#snap-btn').click();
  else if(k==='g')$('#grid-btn').click();
  else{
    let t=toolGroups.flatMap(([, ...ts])=>ts).find(t=>t[2].toLowerCase()===k);
    if(t)chooseTool(t[0]);
  }
};
document.onkeyup=e=>{
  if(e.code==='Space'){
    space=false;
    if(wandActive&&!$('#wand-btn')?.classList.contains('manual-active')){
      wandActive=false;
      $('#wand-btn')?.classList.remove('active');
    }
    canvas.style.cursor=tool==='select'?'default':'crosshair';
  }
};

function openModal(title,body){const mt=$('#modal-title'),mb=$('#modal-body'),m=$('#modal');if(mt)mt.textContent=title;if(mb){mb.innerHTML=body;mb.style.maxHeight='';mb.style.overflowY=''}if(m){m.style.width='';m.style.maxWidth='';m.style.maxHeight='';icons(m);m.showModal?.()}}
bindClick('#modal-close', ()=>$('#modal')?.close?.());
bindClick('#help', ()=>openModal('Archicad 28 · BIM Studio Pro Reference',`<div class="modal-copy">Comprehensive architectural CAD/BIM studio featuring the full Archicad tool palette, Info Box, Pet Palette, and 4-map Navigator.</div><div class="help-list"><strong>Select Tools:</strong> V — Arrow &nbsp; M — Marquee<br><strong>Design Tools:</strong> W — Wall &nbsp; D — Door &nbsp; N — Window &nbsp; K — Skylight &nbsp; R — Roof &nbsp; H — Shell &nbsp; B — Beam &nbsp; C — Column &nbsp; F — Slab &nbsp; S — Stair &nbsp; J — Railing &nbsp; U — Curtain Wall &nbsp; X — Morph &nbsp; Y — Mesh &nbsp; Z — Zone &nbsp; O — Object<br><strong>Document Tools:</strong> Q — Dimension &nbsp; Level Dim &nbsp; Radial Dim &nbsp; Angle Dim &nbsp; T — Text &nbsp; Label &nbsp; I — Fill &nbsp; L — Line &nbsp; A — Arc &nbsp; P — Polyline &nbsp; Spline<br><strong>More:</strong> G — Grid &nbsp; Wall End &nbsp; Corner Window &nbsp; Lamp &nbsp; Camera<br><strong>Archicad Shortcuts:</strong> Alt — Pipette &nbsp; Ctrl+Alt — Syringe &nbsp; Alt+F2 — Trace & Reference &nbsp; Ctrl Z/Shift+Z — Undo/Redo</div>`));

function openCornerDetailModal(targetWall){
  const w=targetWall||framingWall()||model.elements.find(e=>e.type==='wall');
  const c=w?construction(w):FRAMING_DEFAULTS;
  const currentDetail=c.cornerDetail||'threeStud';
  const html=`<div style="font-size:12px;line-height:1.6;color:#2c3e35">
    <div style="display:flex;justify-content:center;margin:12px 0 16px;background:#ffffff;border:1px solid #d5dfd1;border-radius:8px;padding:16px;overflow-x:auto">
      <svg width="520" height="175" viewBox="0 0 540 180" style="max-width:100%;height:auto">
        <!-- 2 Stud -->
        <g transform="translate(10,10)">
          <path d="M0,130 L0,0 L140,0 L140,35 L45,35 L45,130 Z" fill="none" stroke="#7760b7" stroke-width="2" stroke-dasharray="4,3"/>
          <rect x="0" y="0" width="45" height="15" fill="none" stroke="#7760b7" stroke-width="1.8" stroke-dasharray="4,3"/>
          <line x1="0" y1="0" x2="45" y2="15" stroke="#7760b7" stroke-width="1.2" stroke-dasharray="3,3"/>
          <line x1="0" y1="15" x2="45" y2="0" stroke="#7760b7" stroke-width="1.2" stroke-dasharray="3,3"/>
          <rect x="45" y="0" width="18" height="35" fill="none" stroke="#7760b7" stroke-width="1.8" stroke-dasharray="4,3"/>
          <line x1="45" y1="0" x2="63" y2="35" stroke="#7760b7" stroke-width="1.2" stroke-dasharray="3,3"/>
          <line x1="45" y1="35" x2="63" y2="0" stroke="#7760b7" stroke-width="1.2" stroke-dasharray="3,3"/>
          <text x="70" y="150" text-anchor="middle" font-size="12" font-weight="700" fill="#7760b7">Corner - Outside</text>
          <text x="70" y="165" text-anchor="middle" font-size="12" font-weight="700" fill="#7760b7">2 Stud</text>
        </g>
        <!-- 3 Stud (Highlighted / Standard) -->
        <g transform="translate(180,10)">
          <rect x="-6" y="-6" width="168" height="175" rx="6" fill="#f4effe" stroke="#7760b7" stroke-width="1.5"/>
          <path d="M0,130 L0,0 L140,0 L140,35 L45,35 L45,130 Z" fill="none" stroke="#7760b7" stroke-width="2.5"/>
          <!-- Stud 1: Through outside stud -->
          <rect x="0" y="0" width="45" height="16" fill="#ebe4f7" stroke="#7760b7" stroke-width="2"/>
          <line x1="0" y1="0" x2="45" y2="16" stroke="#7760b7" stroke-width="1.5"/>
          <line x1="0" y1="16" x2="45" y2="0" stroke="#7760b7" stroke-width="1.5"/>
          <!-- Stud 2: Drywall backing nailer stud -->
          <rect x="25" y="16" width="20" height="40" fill="#ebe4f7" stroke="#7760b7" stroke-width="2"/>
          <line x1="25" y1="16" x2="45" y2="56" stroke="#7760b7" stroke-width="1.5"/>
          <line x1="25" y1="56" x2="45" y2="16" stroke="#7760b7" stroke-width="1.5"/>
          <!-- Stud 3: Abutting end stud -->
          <rect x="45" y="0" width="18" height="35" fill="#ebe4f7" stroke="#7760b7" stroke-width="2"/>
          <line x1="45" y1="0" x2="63" y2="35" stroke="#7760b7" stroke-width="1.5"/>
          <line x1="45" y1="35" x2="63" y2="0" stroke="#7760b7" stroke-width="1.5"/>
          <text x="70" y="150" text-anchor="middle" font-size="12" font-weight="800" fill="#583da5">Wood Walls - Corner</text>
          <text x="70" y="165" text-anchor="middle" font-size="12" font-weight="800" fill="#583da5">Outside, 3 Stud</text>
        </g>
        <!-- 4 Stud -->
        <g transform="translate(370,10)">
          <path d="M0,130 L0,0 L140,0 L140,35 L45,35 L45,130 Z" fill="none" stroke="#7760b7" stroke-width="2" stroke-dasharray="4,3"/>
          <rect x="0" y="0" width="45" height="15" fill="none" stroke="#7760b7" stroke-width="1.8" stroke-dasharray="4,3"/>
          <line x1="0" y1="0" x2="45" y2="15" stroke="#7760b7" stroke-width="1.2" stroke-dasharray="3,3"/>
          <line x1="0" y1="15" x2="45" y2="0" stroke="#7760b7" stroke-width="1.2" stroke-dasharray="3,3"/>
          <rect x="0" y="15" width="45" height="15" fill="none" stroke="#7760b7" stroke-width="1.8" stroke-dasharray="4,3"/>
          <line x1="0" y1="15" x2="45" y2="30" stroke="#7760b7" stroke-width="1.2" stroke-dasharray="3,3"/>
          <line x1="0" y1="30" x2="45" y2="15" stroke="#7760b7" stroke-width="1.2" stroke-dasharray="3,3"/>
          <rect x="0" y="30" width="45" height="15" fill="none" stroke="#7760b7" stroke-width="1.8" stroke-dasharray="4,3"/>
          <line x1="0" y1="30" x2="45" y2="45" stroke="#7760b7" stroke-width="1.2" stroke-dasharray="3,3"/>
          <line x1="0" y1="45" x2="45" y2="30" stroke="#7760b7" stroke-width="1.2" stroke-dasharray="3,3"/>
          <rect x="45" y="0" width="18" height="35" fill="none" stroke="#7760b7" stroke-width="1.8" stroke-dasharray="4,3"/>
          <line x1="45" y1="0" x2="63" y2="35" stroke="#7760b7" stroke-width="1.2" stroke-dasharray="3,3"/>
          <line x1="45" y1="35" x2="63" y2="0" stroke="#7760b7" stroke-width="1.2" stroke-dasharray="3,3"/>
          <text x="70" y="150" text-anchor="middle" font-size="12" font-weight="700" fill="#7760b7">Corner - Outside</text>
          <text x="70" y="165" text-anchor="middle" font-size="12" font-weight="700" fill="#7760b7">4 Stud</text>
        </g>
      </svg>
    </div>
    <div style="background:#f8faf6;border:1px solid #d5dfd1;border-radius:6px;padding:12px;margin-bottom:14px">
      <div style="font-weight:700;color:#285c47;margin-bottom:6px">Framing Corner Specification: Wood Walls - Corner Outside, 3 Stud</div>
      <div style="color:#576b5a;font-size:11px;margin-bottom:8px">
        Outside perpendicular corner framing detail:
        <ul style="margin:4px 0 6px 16px;padding:0">
          <li><strong>Stud 1 (Through End):</strong> 45 × 140 mm stud terminating Wall 1 at exterior corner edge.</li>
          <li><strong>Stud 2 (Interior Nailer Backing):</strong> 45 × 140 mm backing stud along Wall 1 inside face providing gypsum nailer backing.</li>
          <li><strong>Stud 3 (Abutting End):</strong> 45 × 140 mm end stud of Wall 2 bearing flush against Wall 1.</li>
        </ul>
        Meets IBC / IRC R602.3 advanced framing insulation and drywall backing standard.
      </div>
      <div style="display:flex;gap:16px;align-items:center;margin-top:10px;flex-wrap:wrap">
        <label style="cursor:pointer;display:flex;align-items:center;gap:6px">
          <input type="radio" name="cornerDetailRadio" value="threeStud" ${currentDetail==='threeStud'?'checked':''}>
          <strong>3-Stud Corner (Recommended)</strong>
        </label>
        <label style="cursor:pointer;display:flex;align-items:center;gap:6px">
          <input type="radio" name="cornerDetailRadio" value="twoStud" ${currentDetail==='twoStud'?'checked':''}>
          <span>2-Stud Butt Corner</span>
        </label>
        <label style="cursor:pointer;display:flex;align-items:center;gap:6px">
          <input type="radio" name="cornerDetailRadio" value="fourStud" ${currentDetail==='fourStud'?'checked':''}>
          <span>4-Stud Stacked Corner</span>
        </label>
      </div>
    </div>
    <div style="display:flex;justify-content:flex-end;gap:8px">
      <button id="apply-corner-all" class="primary">Apply to All Walls</button>
      <button id="apply-corner-selected" class="subtle">Apply to Selected Wall</button>
    </div>
  </div>`;
  openModal('Wall Corner Connection · 3-Stud Framing Standard', html);
  const radioButtons=$$('input[name="cornerDetailRadio"]');
  $('#apply-corner-all').onclick=()=>{
    const selDetail=radioButtons.find(r=>r.checked)?.value||'threeStud';
    commit(()=>{
      for(const el of model.elements.filter(e=>e.type==='wall')){
        el.framing={...construction(el),cornerDetail:selDetail};
      }
    });
    $('#modal')?.close?.();
    toast(`Corner connection set to ${selDetail==='threeStud'?'3-Stud Outside Corner':selDetail} on all walls.`);
    render();
  };
  $('#apply-corner-selected').onclick=()=>{
    if(!w){toast('Select a wall first.');return;}
    const selDetail=radioButtons.find(r=>r.checked)?.value||'threeStud';
    commit(()=>{
      w.framing={...construction(w),cornerDetail:selDetail};
    });
    $('#modal')?.close?.();
    toast(`${w.id} corner connection set to ${selDetail==='threeStud'?'3-Stud Outside Corner':selDetail}.`);
    render();
  };
}
bindClick('#corner-detail-btn', ()=>openCornerDetailModal());

function storyDialog(){const st=model.stories.find(s=>s.id===activeStory);if(!st)return;openModal('Story settings',`<div class="modal-copy">Walls linked to this story follow its height. Hosted openings stay within their walls. Upper levels move with the new height.</div><label class="modal-field">${esc(st.name)} height <input id="story-height" type="number" value="${st.height}" step="100"></label><div class="modal-actions"><button id="story-apply" class="primary">Update story</button></div>`);bindClick('#story-apply', ()=>{try{setStoryHeight(st.id,Number($('#story-height')?.value));$('#modal')?.close?.()}catch(e){toast(e.message)}})}
bindClick('#story-btn', storyDialog);
bindClick('#add-story', ()=>{const last=model.stories.at(-1);commit(()=>model.stories.push({id:'s'+Date.now(),name:'New story',elevation:(last?.elevation||0)+(last?.height||3048),height:3048}));toast('New story added to navigator')});

function download(filename,text,mime='application/json'){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:mime}));a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function projectFileName(){const name=String(model?.name||'cadtech-bim-project').trim().replace(/[^a-z0-9_-]+/gi,'-').replace(/^-+|-+$/g,'').toLowerCase()||'cadtech-bim-project';return `${name}.bim.json`}
function makeProjectFile(){return {format:'cadtech-bim-project',formatVersion:1,application:'ARCHICAD 28 BIM STUDIO PRO',savedAt:new Date().toISOString(),project:clone(model),workspace:{activeStory,view,selected:[...selected],layers:clone(layers),snap:Boolean(snap),grid:Boolean(grid),exteriorOsbEnabled:$('#wall-osb-toggle')?.checked!==false}}}
function markProjectSaved(){dirty=false;const ss=$('#save-state');if(ss)ss.textContent='Project saved locally';toast('BIM project saved to a local project file')}
async function save(){
  const data=JSON.stringify(makeProjectFile(),null,2),filename=projectFileName();
  // Chromium-based browsers can write to a path chosen by the user. Other browsers use a normal local download.
  if(typeof window.showSaveFilePicker==='function'){
    try{
      const handle=await window.showSaveFilePicker({suggestedName:filename,types:[{description:'CadTech BIM Project',accept:{'application/json':['.json']}}]});
      const writable=await handle.createWritable();await writable.write(new Blob([data],{type:'application/json'}));await writable.close();markProjectSaved();return;
    }catch(err){if(err?.name==='AbortError'){toast('Save cancelled');return;}console.warn('Save picker unavailable; using browser download instead.',err)}
  }
  download(filename,data);markProjectSaved();
}
bindClick('#save', save);
async function openProjectPicker(){
  // Keep this action cross-browser: Firefox uses the standard file input; supported browsers may use the native picker.
  if(typeof window.showOpenFilePicker==='function'){
    let handles;
    try{handles=await window.showOpenFilePicker({multiple:false,types:[{description:'CadTech BIM Project',accept:{'application/json':['.json']}}]})}
    catch(err){if(err?.name==='AbortError')return;console.warn('Native project picker failed.',err);$('#project-file-input')?.click();return;}
    if(!handles?.[0])return;
    try{await loadProjectFile(await handles[0].getFile())}
    catch(err){console.error(err);toast(err?.message||'Could not open project file.')}
  }else $('#project-file-input')?.click();
}
bindClick('#open-project',openProjectPicker);

function generateOBJ(){
  let out=['# Archicad 28 BIM world coordinates in meters'],n=1;
  function mesh(id,ps,z0,z1){
    out.push('o '+id);const vs=[...ps.map(p=>({...p,z:z0})),...ps.map(p=>({...p,z:z1}))];vs.forEach(p=>out.push(`v ${p.x/1000} ${p.z/1000} ${-p.y/1000}`));const k=ps.length;out.push('f '+ps.map((_,i)=>n+k+i).join(' '));out.push('f '+ps.map((_,i)=>n+k-1-i).join(' '));for(let i=0;i<k;i++){let j=(i+1)%k;out.push(`f ${n+i} ${n+j} ${n+k+j} ${n+k+i}`)}n+=k*2;
  }
  for(const face of wallSurfaces(joinedWallCells(model.elements.filter(e=>e.type==='wall')))){
    out.push('o '+face.id);face.points.forEach(p=>out.push(`v ${p.x/1000} ${p.z/1000} ${-p.y/1000}`));out.push('f '+face.points.map((_,i)=>n+i).join(' '));n+=face.points.length;
  }
  for(const o of model.elements.filter(e=>e.host)){const w=hostOf(o),len=distance(w.a,w.b),z=wallBase(w);mesh(o.id,openingSolidPolygon(w,o),z+o.sill,z+o.sill+o.height)}
  for(const e of model.elements){
    let z=storyOf(e).elevation;
    if(e.type==='wall')continue;
    else if(e.type==='slab')mesh(e.id,e.points,z-e.thickness,z);
    else if(e.type==='beam')mesh(e.id,wallPoly(e),z+heightOf(e)-e.thickness,z+heightOf(e));
    else if(e.type==='column')mesh(e.id,wallPoly(e,{x:e.a.x-e.thickness/2,y:e.a.y},{x:e.a.x+e.thickness/2,y:e.a.y}),z,z+heightOf(e));
    else if(e.type==='roof'){for(const face of roofGeometry(e).faces){out.push('o '+e.id);face.forEach(p=>out.push(`v ${p.x/1000} ${p.z/1000} ${-p.y/1000}`));out.push('f '+face.map((_,i)=>n+i).join(' '));n+=face.length}}
  }
  return out.join('\n');
}
function csv(){return 'ID,Type,Story,Material,Length mm,Height mm\n'+model.elements.map(e=>[e.id,e.type,storyOf(e).name,e.material,e.a&&e.b?Math.round(distance(e.a,e.b)):'',e.height?heightOf(e):''].map(x=>'"'+String(x||'').replace(/"/g,'""')+'"').join(',')).join('\n')}
function exportDialog(){
  openModal('Archicad Publisher · Export',`<div class="modal-copy">Export BIM project, solid IFC/OBJ geometry, or element schedules:</div><div class="modal-actions"><button id="export-json" class="primary">Archicad BIM · JSON</button><button id="export-obj" class="subtle">Solid model · OBJ</button><button id="export-csv" class="subtle">Schedule · CSV</button><button id="export-framing" class="subtle">Timber framing · CSV</button><button id="export-png" class="subtle">Current view · PNG</button></div>`);
  bindClick('#export-framing', ()=>download('timber-framing-cut-list.csv',framingCSV(),'text/csv'));
  bindClick('#export-json', save);
  bindClick('#export-obj', ()=>{download('courtyard-house.obj',generateOBJ(),'text/plain');toast('Solid model exported')});
  bindClick('#export-csv', ()=>download('courtyard-house-schedule.csv',csv(),'text/csv'));
  bindClick('#export-png', ()=>{let a=document.createElement('a');a.download='archicad-'+view+'.png';a.href=canvas.toDataURL();a.click()});
}
bindClick('#export', exportDialog);

function schedule(){
  const sp=$('#schedule-panel');if(!sp)return;
  if(view==='cutlist'){
    sp.innerHTML='<table><thead><tr><th>ELEMENT</th><th>MEMBER</th><th>SECTION mm</th><th>LENGTH mm</th><th>QTY</th></tr></thead><tbody>'+allFramingRows().map(r=>`<tr data-row="${r.wallId}"><td>${esc(r.wallId)}</td><td>${r.type}</td><td>${r.section}</td><td>${r.length}</td><td>${r.quantity}</td></tr>`).join('')+'</tbody></table>';
    $$('[data-row]').forEach(r=>r.onclick=()=>{selected=[r.dataset.row];properties();toast(r.dataset.row+' selected')});
    return;
  }
  sp.innerHTML=`<table><thead><tr><th>ELEMENT ID</th><th>TYPE</th><th>STORY</th><th>MATERIAL</th><th>SIZE / HEIGHT</th></tr></thead><tbody>${model.elements.map(e=>`<tr data-row="${e.id}"><td>${esc(e.id)}</td><td>${esc(e.type)}</td><td>${esc(storyOf(e).name)}</td><td>${esc(e.material)}</td><td>${e.width?e.width+' × ':''}${e.height?heightOf(e)+' mm':e.thickness?e.thickness+' mm':'—'}</td></tr>`).join('')}</tbody></table>`;
  $$('[data-row]').forEach(r=>r.onclick=()=>{selected=[r.dataset.row];properties();toast(`${r.dataset.row} selected in model`)});
}

function menu(button,entries){
  let pop=$('#menu-popover');if(!pop||!button)return;
  let r=button.getBoundingClientRect();
  pop.style.cssText=`left:${r.left}px;top:${r.bottom+5}px`;
  pop.innerHTML=entries.map(([text])=>`<button>${text}</button>`).join('');
  pop.classList.remove('hidden');
  [...pop.children].forEach((b,i)=>b.onclick=()=>{pop.classList.add('hidden');entries[i][1]()});
}
document.addEventListener('pointerdown',e=>{
  if(!e.target.closest('#menu-popover')&&!e.target.closest('[data-menu]')&&!e.target.closest('#display-mode')&&!e.target.closest('#view-more')&&!e.target.closest('#units'))$('#menu-popover').classList.add('hidden');
});

$$('[data-menu]').forEach(b=>b.onclick=()=>menu(b,({
  File:[
    ['Save project · Ctrl S',save],
    ['Import ArchiCAD IFC (.ifc)…',openIFCImportModal],
    ['Open Archicad BIM project',openProjectPicker],
    ['Export IFC 4x3 Reference View',exportDialog],
    ['Export Solid OBJ model',exportDialog],
    ['Export Schedules & Cut Lists',exportDialog],
    ['Page Setup & Plot',()=>window.print()]
  ],
  Edit:[
    ['Undo · Ctrl Z',undo],
    ['Redo · Ctrl Shift Z',redo],
    ['Drag / Move · Ctrl D',()=>edit('move')],
    ['Rotate · Ctrl E',()=>edit('rotate')],
    ['Mirror · Ctrl M',()=>edit('mirror')],
    ['Elevate · Ctrl 9',()=>edit('elevate')],
    ['Multiply / Array · Ctrl U',arrayDialog],
    ['Split · Ctrl K',()=>edit('split')],
    ['Adjust / Trim · Scissors',()=>edit('trim')],
    ['Extend to Boundary',()=>edit('extend')],
    ['Fillet / Chamfer…',()=>edit('fillet')],
    ['Align Elements…',alignmentDialog],
    ['Delete Selected · Del',()=>edit('delete')]
  ],
  View:[
    ['Floor Plan · F2',()=>setView('plan')],
    ['3D Window · F5',()=>setView('3d')],
    ['South Elevation',()=>setView('elevation')],
    ['Building Section A–A',()=>setView('section')],
    ['Fit in Window',fit],
    ['Trace & Reference · Alt+F2',()=>{traceActive=!traceActive;$('#trace-btn').classList.toggle('active',traceActive);render()}],
    ['3D Cutaway Planes',()=>$('#clip-panel').classList.toggle('hidden')]
  ],
  Design:[
    ['Wall Tool · W',()=>chooseTool('wall')],
    ['Door Tool · D',()=>chooseTool('door')],
    ['Window Tool · N',()=>chooseTool('window')],
    ['Skylight Tool · K',()=>chooseTool('skylight')],
    ['Roof Tool · R',()=>chooseTool('roof')],
    ['Shell Tool · H',()=>chooseTool('shell')],
    ['Beam Tool · B',()=>chooseTool('beam')],
    ['Column Tool · C',()=>chooseTool('column')],
    ['Slab Tool · F',()=>chooseTool('slab')],
    ['Stair Tool · S',()=>chooseTool('stair')],
    ['Railing Tool · J',()=>chooseTool('railing')],
    ['Curtain Wall Tool · U',()=>chooseTool('curtainwall')],
    ['Morph Tool · X',()=>chooseTool('morph')],
    ['Mesh Tool · Y',()=>chooseTool('mesh')],
    ['Zone Tool · Z',()=>chooseTool('zone')],
    ['Object Tool · O',()=>chooseTool('object')],
    ['Story Settings…',storyDialog],
    ['TrussMaker & Roof Framing',()=>setView('roofframingplan')]
  ],
  Document:[
    ['Dimension Tool · Q',()=>chooseTool('dimension')],
    ['Level Dimension Tool',()=>chooseTool('leveldim')],
    ['Text Annotation · T',()=>chooseTool('text')],
    ['Element Label',()=>chooseTool('label')],
    ['Fill / Hatch Tool · I',()=>chooseTool('fill')],
    ['Line Tool · L',()=>chooseTool('line')],
    ['Arc / Circle Tool · A',()=>chooseTool('arc')],
    ['Polyline Tool · P',()=>chooseTool('polyline')],
    ['Grid System Element · G',()=>chooseTool('grid')],
    ['2D Framing Plan',()=>setView('framingplan')],
    ['Floor framing plan',openEWPSpecs],
    ['Roof Framing & Truss Analysis',()=>setView('roofframingplan')],
    ['Element Schedule',()=>setView('schedule')],
    ['Timber Cut List',()=>setView('cutlist')],
    ['Analyze All Trusses',()=>trussReviewShow('analyze')],
    ['Optimize Truss Candidates',()=>trussReviewShow('optimize')]
  ],
  Options:[
    ['Project Preferences…',()=>openModal('Project Preferences',`<div class="modal-copy">BIM Project: Courtyard House · Standard Units: Millimeters · Precision: 0.1 mm · North Angle: 0.0° · Geographical Location: 37.77° N, 122.41° W</div>`)],
    ['Working Units · Millimeters',()=>toast('Working units: Millimeters (Archicad default)')],
    ['Complex Profile Manager',()=>toast('Profile Manager: Timber studs, Glulam beams, and Reinforced Concrete profiles active')],
    ['Building Materials & Composites',()=>toast('Composite attributes synchronized with framing engine')]
  ],
  Teamwork:[
    ['Reserve All Elements',()=>toast('Teamwork: All project elements reserved for current workspace')],
    ['Release Selection',()=>toast('Teamwork: Elements released to BIMcloud')],
    ['Send & Receive Changes',()=>toast('Teamwork: BIMcloud workspace synchronized with latest revision')]
  ],
  Window:[
    ['Toolbox Palette',()=>toast('Toolbox active')],
    ['Info Box Bar',()=>$('#info-box')?.classList.toggle('hidden')],
    ['Project Navigator',()=>$('.inspector')?.classList.toggle('hidden')],
    ['Pet Palette Toggle',()=>$('#pet-palette')?.classList.toggle('hidden')],
    ['Reset All Palettes',()=>{$('#info-box')?.classList.remove('hidden');$('.inspector')?.classList.remove('hidden');toast('Palettes restored to Archicad standard layout')}]
  ],
  Help:[
    ['Archicad 28 BIM Studio Pro Help',()=>$('#help').click()],
    ['Keyboard Shortcuts Reference',()=>$('#help').click()],
    ['About Graphisoft Archicad Engine',()=>openModal('Archicad 28 · BIM Studio Pro',`<div class="modal-copy">Professional Virtual Building BIM CAD system featuring full parametric design, structural truss optimization, and timber framing synthesis.</div>`)]
  ]
})[b.dataset.menu]));

bindClick('#view-more', ()=>menu($('#view-more'),[['Floor plan',()=>setView('plan')],['3D model',()=>setView('3d')],['South elevation',()=>setView('elevation')],['Section A–A',()=>setView('section')],['Schedule',()=>setView('schedule')],['Wall framing panel',()=>setView('panel')],['Floor framing plan',openEWPSpecs],['3D framing',()=>setView('framing3d')],['Framing cut list',()=>setView('cutlist')]]));
bindClick('#display-mode', ()=>menu($('#display-mode'),[['Architectural',()=>{transparent=false;const dm=$('#display-mode');if(dm)dm.innerHTML=icon('layers')+'Architectural ⌄';render()}],['Transparent solids',()=>{transparent=true;setView('3d');const dm=$('#display-mode');if(dm)dm.innerHTML=icon('layers')+'Transparent ⌄';render()}]]));
bindClick('#units', ()=>menu($('#units'),[['Millimeters · model units',()=>toast('All modelling coordinates use millimeters')]]));
bindClick('#view-scale', ()=>{fit();toast('View returned to reference scale')});
bindClick('#scale-btn', ()=>{fit();toast('View returned to reference scale')});

function validateProject(m){
  if(!m||m.version!==1||!Array.isArray(m.stories)||!m.stories.length||!Array.isArray(m.elements)||m.elements.length>10000)throw Error('This is not a supported Archicad BIM project.');
  let ids=new Set();
  for(const s of m.stories){
    if(typeof s.id!=='string'||ids.has(s.id)||typeof s.name!=='string'||!Number.isFinite(s.height)||s.height<=0||!Number.isFinite(s.elevation))throw Error('Invalid story data.');
    ids.add(s.id);
  }
  ids=new Set();
  const types=toolGroups.flatMap(([, ...ts])=>ts.map(t=>t[0]));
  for(const e of m.elements){
    if(!types.includes(e.type)||typeof e.id!=='string'||ids.has(e.id)||!m.stories.some(s=>s.id===e.story))throw Error('Invalid element data.');
    ids.add(e.id);
    for(const p of [e.a,e.b,...(e.points||[])].filter(Boolean)){
      if(!Number.isFinite(p.x)||!Number.isFinite(p.y))throw Error('Invalid geometry.');
    }
    if(['wall','beam','line','dimension','stair','railing','curtainwall','grid'].includes(e.type)&&(!e.a||!e.b||distance(e.a,e.b)<1))throw Error('Invalid segment.');
    if(['wall','beam','column','slab'].includes(e.type)&&(!Number.isFinite(e.thickness)||e.thickness<=0))throw Error('Invalid thickness.');
    if(['slab','roof','rectangle','zone','morph','mesh','fill'].includes(e.type)&&(!Array.isArray(e.points)||e.points.length<3))throw Error('Invalid boundary.');
  }
  m.elements.filter(e=>e.type==='roof').forEach(validateRoof);
  for(const w of m.elements.filter(e=>e.type==='wall')){
    validateConstruction(w);
    if(w.topStory&&!m.stories.some(s=>s.id===w.topStory))throw Error('Invalid top-linked story.');
  }
  return m;
}

bindClick('#import-ifc-btn', openIFCImportModal);

async function processIFCContent(ifcText, fileName = 'ArchiCAD Model.ifc', options = {}) {
  try {
    if (!ifcText || !ifcText.includes('ISO-10303-21')) {
      throw new Error('Selected file is not a valid STEP ISO-10303-21 IFC file.');
    }
    const convertFn = window.convertIFCToBIMModel;
    if (typeof convertFn !== 'function') {
      throw new Error('IFC Importer engine is loading. Please try again.');
    }

    const codeStandard = options.codeStandard || $('#ifc-code-standard')?.value || 'IRC_2021';
    const spacing = Number($('#ifc-stud-spacing')?.value) || options.spacing || 406.4;

    const { model: convertedModel, stats } = convertFn(ifcText, fileName.replace(/\.[^.]+$/, ''), { codeStandard, spacing });
    if (!convertedModel || !convertedModel.elements || !convertedModel.elements.length) {
      throw new Error('No wall, slab, or roof elements could be extracted from this IFC file.');
    }

    // Validate project
    let validated = validateProject(convertedModel);

    // Commit model change
    commit(() => {
      model = validated;
      activeStory = model.stories[0].id;
      selected = [];
    });

    // Run automatic framing and truss pipeline
    const appEnv = {
      updateWallConnections: typeof updateWallConnections === 'function' ? updateWallConnections : null,
      autoPlaceFloorJoistsInBoundary: window.autoPlaceFloorJoistsInBoundary,
      autoSizeEWPFloorBeams: window.autoSizeEWPFloorBeams,
      generateRoofFraming: typeof generateRoofFraming === 'function' ? generateRoofFraming : null
    };

    let pipeResults = { takeoff: {} };
    if (window.autoGenerateFramingPipeline) {
      pipeResults = window.autoGenerateFramingPipeline(model, appEnv) || {};
    }

    if (typeof autoAlignTrussRoofsToWallPlates === 'function') {
      autoAlignTrussRoofsToWallPlates();
    }

    // Refresh views and navigator
    setView('plan');
    fit();
    if (typeof fit3DCamera === 'function') fit3DCamera(true);
    changed();

    const codeName = window.CONSTRUCTION_CODES?.[stats.codeStandard]?.name || stats.codeStandard;
    const spacingLabel = `${Math.round(stats.spacing || 406.4)} mm O.C.`;
    const tk = pipeResults.takeoff || {};
    const wallLayoutCount = pipeResults.wallFramingGeneratedCount ?? pipeResults.wallFramingCount ?? 0;
    const wallIssues = pipeResults.wallFramingIssueCount ?? tk.wallIssues ?? 0;
    toast(`Converted IFC: ${stats.wallsCount} walls, ${stats.openingsCount} openings. Wall framing layout: ${tk.totalMembers || 0} members across ${wallLayoutCount} walls${wallIssues ? `, ${wallIssues} issue(s) to review` : ''}.`);

    window.currentIFCModel = model;

    // Show summary modal
    openModal('ArchiCAD IFC Import & Preliminary Framing Layout', `
      <div style="font-family:'DM Sans',system-ui,sans-serif;color:#1e293b;line-height:1.6;max-width:640px">
        <div style="background:#f0fdf4;border:1px solid #86efac;border-radius:8px;padding:12px;margin-bottom:14px;display:flex;align-items:center;gap:10px">
          <span style="font-size:24px">⚡</span>
          <div>
            <strong style="color:#15803d;font-size:14px">ArchiCAD IFC Converted & Preliminary Timber Framing Layout Generated</strong>
            <div style="font-size:12px;color:#334155">${esc(fileName)} · Standard: <strong>${esc(codeName)}</strong> · Spacing: <strong>${spacingLabel}</strong></div>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:14px">
          <div style="background:#f8fafc;border:1px solid #cbd5e1;border-radius:6px;padding:8px;text-align:center">
            <span style="font-size:10px;color:#64748b;font-weight:700">WALLS</span>
            <b style="font-size:18px;color:#0f172a;display:block">${stats.wallsCount}</b>
            <span style="font-size:9.5px;color:#16a34a">${tk.totalMembers || 0} generated members</span>
          </div>
          <div style="background:#f8fafc;border:1px solid #cbd5e1;border-radius:6px;padding:8px;text-align:center">
            <span style="font-size:10px;color:#64748b;font-weight:700">OPENINGS</span>
            <b style="font-size:18px;color:#0f172a;display:block">${stats.openingsCount}</b>
            <span style="font-size:9.5px;color:#0284c7">${stats.doorsCount} Doors / ${stats.windowsCount} Wins</span>
          </div>
          <div style="background:#f8fafc;border:1px solid #cbd5e1;border-radius:6px;padding:8px;text-align:center">
            <span style="font-size:10px;color:#64748b;font-weight:700">FLOOR SLABS</span>
            <b style="font-size:18px;color:#0f172a;display:block">${stats.slabsCount}</b>
            <span style="font-size:9.5px;color:#0284c7">EWP I-Joists</span>
          </div>
          <div style="background:#f8fafc;border:1px solid #cbd5e1;border-radius:6px;padding:8px;text-align:center">
            <span style="font-size:10px;color:#64748b;font-weight:700">ROOFS</span>
            <b style="font-size:18px;color:#0f172a;display:block">${stats.roofsCount}</b>
            <span style="font-size:9.5px;color:#d97706">Fink Trusses</span>
          </div>
        </div>

        <div style="background:#ffffff;border:1px solid #cbd5e1;border-radius:8px;padding:12px;margin-bottom:14px;font-size:11.5px">
          <strong style="color:#0f172a;font-size:12px;display:block;margin-bottom:6px">📋 Timber Framing Material Takeoff:</strong>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;color:#334155">
            <div>• Common Studs: <strong>${tk.commonStuds || '—'}</strong></div>
            <div>• King Studs: <strong>${tk.kingStuds || '—'}</strong></div>
            <div>• Jack / Trimmer Studs: <strong>${tk.jackStuds || '—'}</strong></div>
            <div>• Header members: <strong>${tk.headers || '—'}</strong></div>
            <div>• Rough Window Sills: <strong>${tk.roughSills || '—'}</strong></div>
            <div>• Upper/Lower Cripples: <strong>${tk.cripples || '—'}</strong></div>
            <div>• Double Top Plates: <strong>${tk.topPlates || '—'}</strong></div>
            <div>• Broken Bottom Plates: <strong>${tk.bottomPlates || '—'}</strong></div>
          </div>
        </div>

        <div style="font-size:11.5px;color:#475569;margin-bottom:16px">
          <p style="margin:3px 0"><strong>✔ 2D Plans & 3D Model:</strong> Converted geometry is active in the plan and 3D viewport. Wall members shown are framing-layout geometry, not a structural capacity check.</p>
          <p style="margin:3px 0"><strong>✔ Opening Framing:</strong> Generated header, king/jack stud, sill and cripple geometry from the current wall settings. Verify header capacity, bearing, connections and bracing separately.</p>
          <p style="margin:3px 0"><strong>✔ EWP Floor Framing & Trusses:</strong> I-Joists and Fink roof trusses synced to wall plates.</p>
        </div>

        <div style="display:flex;justify-content:flex-end;gap:8px">
          <button id="view-3d-now-btn" class="subtle" style="font-weight:700">View 3D Framing</button>
          <button id="view-ewp-now-btn" class="subtle" style="font-weight:700">View EWP Specs</button>
          <button id="view-truss-now-btn" class="subtle" style="font-weight:700">View Roof Framing</button>
          <button id="close-ifc-summary-btn" class="primary">Close</button>
        </div>
      </div>
    `);
    $('#view-3d-now-btn')?.addEventListener('click', () => {
      $('#modal')?.close?.();
      setView('framing3d');
    });
    $('#view-ewp-now-btn')?.addEventListener('click', () => {
      $('#modal')?.close?.();
      openEWPSpecs();
    });
    $('#view-truss-now-btn')?.addEventListener('click', () => {
      $('#modal')?.close?.();
      setView('roofframingplan');
    });
    $('#close-ifc-summary-btn')?.addEventListener('click', () => {
      $('#modal')?.close?.();
    });

  } catch (err) {
    toast(`IFC Import Error: ${err.message}`);
    console.error(err);
  }
}

function openIFCImportModal() {
  const html = `
    <div style="font-family:'DM Sans',system-ui,sans-serif;color:#1e293b;line-height:1.6;max-width:620px">
      <div style="margin-bottom:12px">
        <p style="font-size:12.5px;color:#475569;margin:0 0 10px 0">
          Upload an IFC model exported or converted from <strong>ArchiCAD</strong> (.ifc format).
          Walls, doors, windows, floors/slabs, and roofs will be automatically extracted, synchronized across 2D plans and 3D, and converted into <strong>code-compliant timber stud wall framing</strong>, <strong>EWP floor framing</strong>, and <strong>roof trusses</strong>.
        </p>
      </div>

      <!-- Drag and drop / file selector box -->
      <div id="ifc-drop-zone" style="border:2px dashed #0284c7;background:#f0f9ff;border-radius:8px;padding:20px;text-align:center;cursor:pointer;transition:all .2s;margin-bottom:12px">
        <div style="font-size:30px;margin-bottom:4px">📁</div>
        <strong style="color:#0284c7;font-size:14px;display:block">Click to select ArchiCAD .ifc file or drop here</strong>
        <span style="font-size:11px;color:#64748b">Accepts standard STEP physical IFC (.ifc, .ifczip)</span>
      </div>

      <!-- Building Code & Framing Options -->
      <div style="background:#f8fafc;border:1px solid #cbd5e1;border-radius:8px;padding:12px;margin-bottom:12px;display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div>
          <label style="font-size:11px;font-weight:700;color:#0f172a;display:block;margin-bottom:4px">Building Code Standard:</label>
          <select id="ifc-code-standard" style="width:100%;padding:6px;border:1px solid #cbd5e1;border-radius:5px;font-size:11.5px;background:white">
            <option value="IRC_2021" selected>IRC 2021 / IBC Chapter 23 (US)</option>
            <option value="AS_1684">AS 1684 Residential Framing (AU)</option>
            <option value="EUROCODE_5">Eurocode 5 BS EN 1995 (UK/EU)</option>
          </select>
        </div>
        <div>
          <label style="font-size:11px;font-weight:700;color:#0f172a;display:block;margin-bottom:4px">Stud Spacing (O.C.):</label>
          <select id="ifc-stud-spacing" style="width:100%;padding:6px;border:1px solid #cbd5e1;border-radius:5px;font-size:11.5px;background:white">
            <option value="406.4" selected>16" O.C. (406.4 mm)</option>
            <option value="609.6">24" O.C. (609.6 mm)</option>
          </select>
        </div>
      </div>

      <!-- Quick sample load -->
      <div style="background:#ffffff;border:1px solid #cbd5e1;border-radius:8px;padding:10px;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center">
        <div>
          <strong style="font-size:12px;color:#0f172a;display:block">Sample ArchiCAD Residential Villa</strong>
          <span style="font-size:10.5px;color:#64748b">14m × 10m plan with walls, door, standard window & wide patio window</span>
        </div>
        <button id="load-sample-ifc-btn" style="padding:6px 12px;background:#0284c7;color:white;border:none;border-radius:5px;font-weight:700;font-size:11.5px;cursor:pointer">
          ⚡ Load Sample IFC
        </button>
      </div>

      <!-- Framing auto-generation description -->
      <div style="background:#ffffff;border:1px solid #e2e8f0;border-radius:8px;padding:10px;margin-bottom:14px;font-size:11px;color:#475569">
        <strong style="display:block;margin-bottom:4px;color:#0f172a">Automatic Code Synthesis:</strong>
        <div>• <strong>Wall Framing:</strong> Double top plates, broken bottom plates, span headers, multi-jack studs (2 jacks for spans > 5'), cripples & 3-stud California corners.</div>
        <div>• <strong>EWP Floor Framing & Trusses:</strong> I-Joists, LVL girders, and Fink hip/common trusses aligned automatically.</div>
      </div>

      <div style="display:flex;justify-content:flex-end;gap:8px">
        <button id="cancel-ifc-modal-btn" class="subtle">Cancel</button>
        <button id="modal-select-ifc-btn" class="primary">Select IFC File</button>
      </div>
    </div>
  `;

  openModal('Import ArchiCAD IFC Model (.ifc)', html);

  const dropZone = $('#ifc-drop-zone');
  const fileInput = $('#import-ifc-file');
  const sampleBtn = $('#load-sample-ifc-btn');
  const selectBtn = $('#modal-select-ifc-btn');
  const cancelBtn = $('#cancel-ifc-modal-btn');

  if (cancelBtn) cancelBtn.onclick = () => $('#modal')?.close?.();

  if (dropZone && fileInput) {
    dropZone.onclick = () => fileInput.click();
    dropZone.ondragover = e => { e.preventDefault(); dropZone.style.background = '#e0f2fe'; };
    dropZone.ondragleave = () => { dropZone.style.background = '#f0f9ff'; };
    dropZone.ondrop = async e => {
      e.preventDefault();
      dropZone.style.background = '#f0f9ff';
      const file = e.dataTransfer?.files?.[0];
      if (file) {
        const text = await file.text();
        const codeStandard = $('#ifc-code-standard')?.value || 'IRC_2021';
        const spacing = Number($('#ifc-stud-spacing')?.value) || 406.4;
        $('#modal')?.close?.();
        processIFCContent(text, file.name, { codeStandard, spacing });
      }
    };
  }

  if (selectBtn && fileInput) {
    selectBtn.onclick = () => fileInput.click();
  }

  if (sampleBtn) {
    sampleBtn.onclick = async () => {
      sampleBtn.disabled = true;
      sampleBtn.textContent = 'Loading...';
      try {
        const resp = await fetch('sample-archicad.ifc');
        if (!resp.ok) throw new Error('Could not fetch sample-archicad.ifc');
        const text = await resp.text();
        const codeStandard = $('#ifc-code-standard')?.value || 'IRC_2021';
        const spacing = Number($('#ifc-stud-spacing')?.value) || 406.4;
        $('#modal')?.close?.();
        processIFCContent(text, 'ArchiCAD_Villa_Sample.ifc', { codeStandard, spacing });
      } catch (err) {
        toast(`Error loading sample: ${err.message}`);
        sampleBtn.disabled = false;
        sampleBtn.textContent = '⚡ Load Sample IFC';
      }
    };
  }
}

bindChange('#import-ifc-file', async e => {
  try {
    const file = e.target.files[0];
    if (!file) return;
    const text = await file.text();
    $('#modal')?.close?.();
    processIFCContent(text, file.name);
  } catch (err) {
    toast(`IFC Import Error: ${err.message}`);
  }
  e.target.value = '';
});

function applyProjectFileData(parsed,fileName=''){
  const wrapped=parsed&&parsed.format==='cadtech-bim-project'&&parsed.formatVersion===1&&parsed.project;
  const imported=clone(wrapped?parsed.project:parsed);
  if(!imported||!Array.isArray(imported.elements)||!Array.isArray(imported.stories))throw Error('This file does not contain a supported BIM project. Choose a saved .bim.json or legacy Archicad BIM JSON file.');
  for(const w of imported.elements||[])if(w.type==='wall'&&!w.reference&&w.layer==='Exterior Walls')w.reference='outside';
  const nextModel=validateProject(imported),ws=wrapped&&parsed.workspace&&typeof parsed.workspace==='object'?parsed.workspace:{};
  const nextActiveStory=nextModel.stories.some(st=>st.id===ws.activeStory)?ws.activeStory:nextModel.stories[0].id;
  const validViews=new Set(['plan','3d','elevation','section','schedule','framingplan','roofframingplan','trusselevation','panel','ewpspecs','framing3d','cutlist']);
  const nextView=validViews.has(ws.view)?ws.view:'plan';
  const elementIds=new Set(nextModel.elements.map(el=>el.id));
  const nextSelected=Array.isArray(ws.selected)?ws.selected.filter(id=>typeof id==='string'&&elementIds.has(id)):[];
  const defaultLayers=[{name:'Exterior Walls',color:'#537e69',visible:true},{name:'Interior Walls',color:'#8b9c82',visible:true},{name:'Structure',color:'#aaab8f',visible:true},{name:'Annotations',color:'#b7bcae',visible:true}];
  const nextLayers=Array.isArray(ws.layers)?defaultLayers.map(base=>{const saved=ws.layers.find(item=>item&&item.name===base.name);return {...base,color:typeof saved?.color==='string'&&/^#[0-9a-f]{6}$/i.test(saved.color)?saved.color:base.color,visible:typeof saved?.visible==='boolean'?saved.visible:base.visible}}):defaultLayers;
  modelHistory=[];future=[];model=nextModel;activeStory=nextActiveStory;selected=nextSelected;layers=nextLayers;
  if(typeof ws.snap==='boolean')snap=ws.snap;if(typeof ws.grid==='boolean')grid=ws.grid;
  const osb=$('#wall-osb-toggle');if(osb)osb.checked=typeof ws.exteriorOsbEnabled==='boolean'?ws.exteriorOsbEnabled:true;syncWallOsbToggle();
  setView(nextView);
  if(nextView==='3d'||nextView==='framing3d')fit3DCamera();else fit();
  render();properties();navigatorPanel();
  dirty=false;const ss=$('#save-state');if(ss)ss.textContent='Project opened';const projectTitle=$('#project-name');if(projectTitle)projectTitle.textContent=String(nextModel.name||fileName.replace(/\.(bim\.)?json$/i,'')||'Untitled project');
  try{window.dispatchEvent(new Event('cadtech:modelChanged'))}catch(_e){}
  toast(`BIM project opened${fileName?`: ${fileName}`:''}`);
}
async function loadProjectFile(file){
  if(!file)return;
  if(file.size>25000000)throw Error('Project file is too large (maximum 25 MB).');
  const text=await file.text();
  if(file.name.toLowerCase().endsWith('.ifc')||text.includes('ISO-10303-21')){processIFCContent(text,file.name);return;}
  let imported;try{imported=JSON.parse(text)}catch(_e){throw Error('This file is not valid JSON. Select a saved CadTech BIM project file.');}
  applyProjectFileData(imported,file.name);
}
bindChange('#import-file', async e=>{
  try{await loadProjectFile(e.target.files?.[0]);}
  catch(err){console.error(err);toast(err?.message||'Could not open project file.');}
  e.target.value='';
});
bindChange('#project-file-input',async e=>{
  try{await loadProjectFile(e.target.files?.[0]);}
  catch(err){console.error(err);toast(err?.message||'Could not open project file.');}
  e.target.value='';
});

const modelContext=document.modelContext;
if(modelContext?.registerTool){
  try{
    modelContext.registerTool({name:'read_bim_model',description:'Read stories and BIM elements from the current shared model.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true},execute:()=>clone(model)});
    modelContext.registerTool({name:'import_archicad_ifc',description:'Import and convert an ArchiCAD IFC model into the BIM workspace.',inputSchema:{type:'object',properties:{ifcText:{type:'string'}},required:['ifcText'],additionalProperties:false},execute:({ifcText})=>{processIFCContent(ifcText,'api-import.ifc');return {ok:true}}});
    modelContext.registerTool({name:'set_story_height',description:'Change a story height and update its dependent walls and openings.',inputSchema:{type:'object',properties:{storyId:{type:'string'},height:{type:'number',minimum:300,maximum:50000}},required:['storyId','height'],additionalProperties:false},execute:({storyId,height})=>{if(!model.stories.some(s=>s.id===storyId)||!Number.isFinite(height))throw Error('Invalid story or height');setStoryHeight(storyId,height);return {storyId,height,revision:model.revision}}});
  }catch(e){console.warn('WebMCP unavailable',e)}
}

bindChange('#camera-projection', e=>{sceneCamera.projection=e.target.value;fit3DCamera();cameraUI();render()});
bindChange('#camera-shading', e=>{sceneCamera.style=e.target.value;transparent=e.target.value==='xray';render()});
bindChange('#camera-preset', e=>cameraPreset(e.target.value));
bindClick('#camera-inspector', ()=>{$('main')?.classList.remove('viewport-focus');$('main')?.classList.toggle('inspector-open');cameraUI()});
bindClick('#selection-properties', ()=>{$('main')?.classList.remove('viewport-focus');$('main')?.classList.add('inspector-open');cameraUI()});
bindClick('#camera-focus', ()=>{$('main')?.classList.toggle('viewport-focus');cameraUI()});
$$('[data-camera]').forEach(b=>b.onclick=()=>cameraPreset(b.dataset.camera));
bindClick('#camera-left', ()=>{orbit-=Math.PI/2;sceneCamera.preset='custom';render()});
bindClick('#camera-right', ()=>{orbit+=Math.PI/2;sceneCamera.preset='custom';render()});

function updateDraftTrackerLive(p){
  const tracker=$('#draft-tracker');
  if(!tracker||tracker.classList.contains('hidden')||tracker.classList.contains('minimized'))return;
  const active=document.activeElement;
  if(active&&tracker.contains(active))return;
  const lenIn=$('#draft-length'),angIn=$('#draft-angle'),xIn=$('#draft-coord-x'),yIn=$('#draft-coord-y');
  if(xIn)xIn.value=Math.round(p.x);
  if(yIn)yIn.value=Math.round(p.y);
  if(points.length>0){
    const base=points.at(-1),d=distance(base,p),rad=Math.atan2(p.y-base.y,p.x-base.x);
    let deg=rad*180/Math.PI;if(deg<0)deg+=360;
    if(lenIn)lenIn.value=Math.round(d);
    if(angIn)angIn.value=(Math.round(deg*10)/10).toFixed(1);
  }else{
    const d=Math.hypot(p.x,p.y);
    let deg=Math.atan2(p.y,p.x)*180/Math.PI;if(deg<0)deg+=360;
    if(lenIn)lenIn.value=Math.round(d);
    if(angIn)angIn.value=(Math.round(deg*10)/10).toFixed(1);
  }
}

function commitTrackerPoint(){
  const lenVal=Number($('#draft-length')?.value),angVal=Number($('#draft-angle')?.value),xVal=Number($('#draft-coord-x')?.value),yVal=Number($('#draft-coord-y')?.value);
  const active=document.activeElement;
  const isPolar=active===$('#draft-length')||active===$('#draft-angle');
  let pt;
  if(isPolar&&Number.isFinite(lenVal)&&Number.isFinite(angVal)){
    const base=points.length>0?points.at(-1):hover||{x:0,y:0};
    const rad=angVal*Math.PI/180;
    pt={x:Math.round(base.x+Math.cos(rad)*lenVal),y:Math.round(base.y+Math.sin(rad)*lenVal)};
  }else if(Number.isFinite(xVal)&&Number.isFinite(yVal)&&(active===$('#draft-coord-x')||active===$('#draft-coord-y'))){
    pt={x:Math.round(xVal),y:Math.round(yVal)};
  }else if(Number.isFinite(lenVal)&&Number.isFinite(angVal)){
    const base=points.length>0?points.at(-1):hover||{x:0,y:0};
    const rad=angVal*Math.PI/180;
    pt={x:Math.round(base.x+Math.cos(rad)*lenVal),y:Math.round(base.y+Math.sin(rad)*lenVal)};
  }else{
    pt=clone(hover||{x:0,y:0});
  }
  if(tool==='select'&&!editing){
    toast('Select a CAD or BIM tool (Wall, Slab, Beam, Dimension) to place point');
    return;
  }
  place(pt);
  setTimeout(()=>{$('#draft-length')?.select()},50);
}

function initDraftTracker(){
  const tracker=$('#draft-tracker');
  if(!tracker)return;
  bindClick('#tracker-tab-handle',()=>{
    tracker.classList.toggle('minimized');
    toast(tracker.classList.contains('minimized')?'Tracker tab minimized (Click pill or Tab to expand)':'Tracker tab expanded');
  });
  bindClick('#tracker-btn',()=>{
    trackerActive=!trackerActive;
    tracker.classList.toggle('hidden',!trackerActive);
    $('#tracker-btn')?.classList.toggle('enabled',trackerActive);
    toast(trackerActive?'Tracker tab visible (Tab to enter values)':'Tracker tab hidden');
  });
  bindClick('#draft-place',commitTrackerPoint);
  ['#draft-length','#draft-angle','#draft-coord-x','#draft-coord-y'].forEach(sel=>{
    $(sel)?.addEventListener('keydown',e=>{
      if(e.key==='Enter'){
        e.preventDefault();
        commitTrackerPoint();
      }
    });
  });
}

initDraftTracker();
initializeAdvanced();
if(typeof initializeTrussOptimizer==='function')initializeTrussOptimizer();
properties();navigatorPanel();renderNavigatorMap('project');toolState();renderInfoBox();resize();cameraUI();


