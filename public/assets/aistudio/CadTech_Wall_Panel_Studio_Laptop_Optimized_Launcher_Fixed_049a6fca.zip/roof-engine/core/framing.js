/* Framing is regenerated from BIM walls and their hosted openings. These are
   construction layouts using specified member sizes, not load-sized designs. */
const WALL_COMPOSITES={timber140:{name:'Timber 140 · insulated',skins:[{name:'Gypsum',thickness:13},{name:'Structural timber',thickness:140,core:true},{name:'Sheathing',thickness:19},{name:'Air gap',thickness:25},{name:'Cladding',thickness:16}]},timber90:{name:'Timber 90 · internal',skins:[{name:'Gypsum',thickness:13},{name:'Structural timber',thickness:90,core:true},{name:'Gypsum',thickness:13}]}};
const FRAMING_DEFAULTS={enabled:true,studWidth:45,studDepth:140,spacing:406.4,plateThickness:45,topPlates:2,bottomPlates:1,headerDepth:190,headerPlies:2,cornerDetail:"threeStud",tDetail:"backingStud",blockingSpacing:600};
function construction(w){const depth=w.structure==='composite'?(wallLayers(w).find(s=>s.core)?.thickness||140):Math.min(FRAMING_DEFAULTS.studDepth,w.thickness),c={...FRAMING_DEFAULTS,enabled:['Timber','Oak'].includes(w.material),studDepth:depth,headerPlies:Math.max(1,Math.min(2,Math.floor(depth/45))),...w.framing};if(w.structure==='composite')c.studDepth=depth;return c}
function validateConstruction(w){if(w.structure&&!['basic','composite'].includes(w.structure))throw Error('Unsupported wall structure.');if(w.reference&&!['inside','center','outside','coreInside','coreCenter','coreOutside'].includes(w.reference))throw Error('Unsupported wall reference line.');if(w.structure==='composite'){const skins=wallLayers(w);if(!Array.isArray(skins)||!skins.length||skins.length>20||skins.filter(s=>s.core).length!==1||skins.some(s=>!Number.isFinite(s.thickness)||s.thickness<=0)||Math.abs(skins.reduce((a,s)=>a+s.thickness,0)-w.thickness)>JOIN_EPS)throw Error('Invalid composite layers.')}for(const k of ['baseOffset','topOffset'])if(w[k]!==undefined&&(!Number.isFinite(w[k])||Math.abs(w[k])>50000))throw Error('Invalid wall offset.');const c=construction(w);if(!["threeStud","twoStud","fourStud"].includes(c.cornerDetail)||!["backingStud","blocking"].includes(c.tDetail)||!Number.isFinite(c.blockingSpacing)||c.blockingSpacing<100||c.blockingSpacing>10000)throw Error("Invalid junction detail.");if(typeof c.enabled!=='boolean'||!['studWidth','studDepth','spacing','plateThickness','headerDepth'].every(k=>Number.isFinite(c[k])&&c[k]>0&&c[k]<=10000)||c.spacing<Math.max(20,c.studWidth)||c.studDepth>w.thickness||!['topPlates','bottomPlates','headerPlies'].every(k=>Number.isInteger(c[k])&&c[k]>0&&c[k]<=6)||c.headerPlies*c.studWidth>c.studDepth)throw Error('Member sizes, spacing and header plies must fit the wall core.');}
function wallLayers(w){return w.structure==='composite'?(w.skins||WALL_COMPOSITES[w.composite||'timber140']?.skins||WALL_COMPOSITES.timber140.skins):[{name:w.material||'Timber',thickness:w.thickness,core:true}]}
function coreGeometry(w){const skins=wallLayers(w),coreIndex=skins.findIndex(s=>s.core),insideFinish=skins.slice(0,Math.max(0,coreIndex)).reduce((a,s)=>a+s.thickness,0),depth=skins[coreIndex]?.thickness||w.thickness;return {insideFinish,depth,center:w.structure==='composite'?w.thickness/2-insideFinish-depth/2:0}}
function referenceOffset(w){const c=coreGeometry(w),r=w.reference||'center',offset={center:0,inside:-w.thickness/2,outside:w.thickness/2,coreInside:-w.thickness/2+c.insideFinish,coreCenter:-w.thickness/2+c.insideFinish+c.depth/2,coreOutside:-w.thickness/2+c.insideFinish+c.depth}[r]||0;return offset*(w.flipped?-1:1)}
function wallCenterPoint(w,p){const u=sub2(w.b,w.a),len=Math.hypot(u.x,u.y)||1,r=referenceOffset(w);return {x:p.x-u.y/len*r,y:p.y+u.x/len*r}}
function wallBase(w){return storyOf(w).elevation+(w.baseOffset||0)}
function openingSolidPolygon(w,o){const len=distance(w.a,w.b),ps=rawWallPoly(w,lerp(w.a,w.b,(o.offset-o.width/2)/len),lerp(w.a,w.b,(o.offset+o.width/2)/len),40),shift=((w.thickness-40)/2-(o.reveal??(w.thickness-40)/2))*(w.flipped?-1:1),u=sub2(w.b,w.a);return ps.map(p=>({x:p.x-u.y/len*shift,y:p.y+u.x/len*shift}))}
function wallFramingJunctions(w){const len=distance(w.a,w.b),found=[];for(const other of model.elements.filter(e=>e.type==='wall'&&e.id!==w.id&&e.story===w.story)){for(const p of [other.a,other.b]){const d=segmentDistance(p,w.a,w.b);if(d.distance<1)found.push({x:d.t*len,type:d.t>.001&&d.t<.999?'T-junction studs':'Corner pack',otherId:other.id,branchEnd:p===other.a?'a':'b'})}const h=axisIntersection(w.a,w.b,other.a,other.b);if(h&&h.t>.001&&h.t<.999&&h.s>.001&&h.s<.999)found.push({x:h.t*len,type:'Cross-junction studs'})}for(const other of model.elements.filter(e=>e.type==='wall'&&e.id!==w.id&&e.story===w.story)){const u=sub2(w.b,w.a),v=sub2(other.b,other.a);if(Math.abs(cross2(u,v))/(len*distance(other.a,other.b))<.05)continue;for(const k of ['a','b'])if([other.a,other.b].some(p=>distance(p,w[k])<=(w.thickness+other.thickness)/2+1))found.push({x:k==='a'?0:len,type:'Corner pack',otherId:other.id})}return found.filter((j,i)=>!found.slice(0,i).some(o=>Math.abs(o.x-j.x)<1))}
function generateWallFraming(w){if(!w||w.type!=='wall')return {wallId:w?.id,members:[],issues:[]};const c=construction(w),len=distance(w.a,w.b),h=heightOf(w),members=[],issues=[];if(!c.enabled)return {wallId:w.id,members,issues};const run=framingRun(w),sw=c.studWidth,bottom=c.bottomPlates*c.plateThickness,top=h-c.topPlates*c.plateThickness,allOpenings=hosted(w).map(o=>({...o,left:o.offset-o.width/2,right:o.offset+o.width/2,head:o.sill+o.height})),junctions=wallFramingJunctions(w);
  /* Reject invalid hosted openings before laying out members; do not create negative,
     out-of-wall or vertically impossible framing around malformed BIM openings. */
  const openings=[];for(const o of allOpenings){let problem='';if(!Number.isFinite(o.offset)||!Number.isFinite(o.width)||!Number.isFinite(o.height)||!Number.isFinite(o.sill)||o.width<=0||o.height<=0)problem='opening has invalid dimensions';else if(o.left<-.01||o.right>len+.01)problem='opening extends beyond its host wall';else if(o.sill<-.01||o.head>h+.01)problem='opening sill/head is outside the wall height';else if(o.type==='door'&&Math.abs(o.sill)>1)problem='door sill must start at floor level';if(problem){issues.push(`${o.id}: ${problem}; framing omitted for this opening.`);continue}openings.push(o)}
  /* Openings on one wall must not overlap: overlapping doors/windows make
     king/jack and header layouts ambiguous, so reject both affected openings. */
  const conflicted=new Set();
  for(let i=0;i<openings.length;i++)for(let j=i+1;j<openings.length;j++){
    const a=openings[i],b=openings[j];
    if(Math.min(a.right,b.right)-Math.max(a.left,b.left)>0.5){conflicted.add(a.id);conflicted.add(b.id);}
  }
  for(const id of conflicted)issues.push(`${id}: overlaps another opening on this wall; framing omitted for the conflicting openings.`);
  const usableOpenings=openings.filter(o=>!conflicted.has(o.id));
  const invalidRun=run.end-run.start<sw*2;if(invalidRun){issues.push('Connected wall run is too short for framing members.');return {wallId:w.id,members,issues}}
  function add(type,x0,x1,z0,z1,depth=c.studDepth){if(x1-x0<1||z1-z0<1)return;const member={id:`${w.id}:F-${String(members.length+1).padStart(4,'0')}`,wallId:w.id,type,x0,x1,z0,z1,depth,length:['Top plate','Bottom plate','Header','Sill'].includes(type)?x1-x0:z1-z0,section:['Top plate','Bottom plate','Sill'].includes(type)?`${c.plateThickness} × ${c.studDepth}`:type==='Header'?`${depth} × ${c.headerDepth}`:`${sw} × ${depth}`};members.push(member);return member}
  if(top<=bottom){issues.push('Wall is too short for the specified plates.');return {wallId:w.id,members,issues}}
  for(let i=0;i<c.topPlates;i++)add('Top plate',run.start,run.end,h-(i+1)*c.plateThickness,h-i*c.plateThickness);
  let bottomRuns=[[run.start,run.end]];for(const o of openings.filter(o=>o.type==='door'||o.sill<1))bottomRuns=bottomRuns.flatMap(([a,b])=>o.right<=a||o.left>=b?[[a,b]]:[[a,Math.max(a,o.left)],[Math.min(b,o.right),b]].filter(([a,b])=>b-a>1));for(let i=0;i<c.bottomPlates;i++)for(const [a,b] of bottomRuns)add('Bottom plate',a,b,i*c.plateThickness,(i+1)*c.plateThickness);
  const reserved=[];for(const o of usableOpenings){if(o.head+c.headerDepth>top+.01){issues.push(`${o.id}: specified header does not fit below the top plates.`);continue}if(o.left-2*sw<0||o.right+2*sw>len){issues.push(`${o.id}: not enough end clearance for king / jack studs.`);continue}reserved.push([o.left-2*sw,o.right+2*sw]);add('King stud',o.left-2*sw,o.left-sw,bottom,top);add('King stud',o.right+sw,o.right+2*sw,bottom,top);add('Jack stud',o.left-sw,o.left,bottom,o.head);add('Jack stud',o.right,o.right+sw,bottom,o.head);add('Header',o.left-sw,o.right+sw,o.head,o.head+c.headerDepth,c.headerPlies*sw);if(o.type==='window'&&o.sill>bottom+c.plateThickness)add('Sill',o.left,o.right,o.sill-c.plateThickness,o.sill);
    for(let x=run.start+sw/2;x<=run.end-sw/2+.01;x+=c.spacing)if(x-sw/2>=o.left-.01&&x+sw/2<=o.right+.01){add('Upper cripple',x-sw/2,x+sw/2,o.head+c.headerDepth,top);if(o.type==='window')add('Lower cripple',x-sw/2,x+sw/2,bottom,o.sill-c.plateThickness)}
  }
  for(const j of junctions){
    const other=model.elements.find(e=>e.id===j.otherId),atStart=j.x<len/2;
    if(j.type==='T-junction studs'&&other){
      const oc=construction(other),ol=distance(other.a,other.b),foot=framingMemberWorld(other,{x0:j.branchEnd==='a'?0:ol,x1:j.branchEnd==='a'?0:ol,depth:oc.studDepth}),p=lerp(foot[0],foot[2],.5),u=sub2(w.b,w.a),center=((p.x-w.a.x)*u.x+(p.y-w.a.y)*u.y)/len,half=oc.studDepth/2,left=center-half-sw,right=center+half+sw;
      if(left<run.start||right>run.end||openings.some(o=>right>o.left-2*sw&&left<o.right+2*sw))continue;
      reserved.push([left,right]);add(j.type,left,left+sw,bottom,top);add(j.type,right-sw,right,bottom,top);
      const dir=sub2(j.branchEnd==='a'?other.b:other.a,j.branchEnd==='a'?other.a:other.b),side=Math.sign((-u.y*dir.x+u.x*dir.y)/len)||1;
      if(c.tDetail==='backingStud'){const m=add(j.type,center-half,center+half,bottom,top,sw);if(m){m.lateralOffset=side*(c.studDepth-sw)/2;m.section=`${sw} × ${oc.studDepth}`;m.role='Perpendicular backing stud'}}
      else for(let z=bottom;z+sw<=top;z+=c.blockingSpacing){const m=add('T-junction blocking',center-half,center+half,z,z+sw);if(m){m.length=oc.studDepth;m.section=`${sw} × ${c.studDepth}`;m.role='Horizontal backing'}}
    }else if(j.type==='Corner pack'){
      const through=other&&w.id.localeCompare(other.id)<0,
            edge=atStart?run.start:run.end,
            sign=atStart?1:-1;
      if(c.cornerDetail==='threeStud'){
        // "Wood Walls - Corner Outside, 3 Stud":
        // 1 through end stud + 1 interior drywall backing stud on through wall,
        // and 1 abutting end stud on abutting wall. (Total 3 studs at corner).
        const extent=through?sw+c.studDepth:sw,
              left=atStart?edge:edge-extent,
              right=atStart?edge+extent:edge;
        if(right-left>run.end-run.start||openings.some(o=>right>o.left-2*sw&&left<o.right+2*sw))continue;
        reserved.push([left,right]);
        const xEnd=atStart?edge:edge-sw;
        const mEnd=add(j.type,xEnd,xEnd+sw,bottom,top,c.studDepth);
        if(mEnd)mEnd.role=through?'Corner outside end stud':'Corner abutting end stud';
        if(through){
          const xBack0=atStart?edge+sw:edge-sw-c.studDepth,
                xBack1=atStart?edge+sw+c.studDepth:edge-sw,
                mBack=add('Corner backing stud',xBack0,xBack1,bottom,top,sw);
          if(mBack){
            const u=sub2(w.b,w.a),
                  cornerPt=w[atStart?'a':'b'],
                  q=other.a===undefined?other.b:distance(other.a,cornerPt)<distance(other.b,cornerPt)?other.b:other.a;
            const side=Math.sign(-u.y*(q.x-cornerPt.x)+u.x*(q.y-cornerPt.y))||sign;
            mBack.lateralOffset=side*(c.studDepth-sw)/2;
            mBack.section=`${sw} × ${c.studDepth}`;
            mBack.role='Corner drywall backing stud';
          }
        }
      }else if(c.cornerDetail==='fourStud'){
        // "Corner - Outside 4 Stud": 3 stacked end studs on through wall, 1 on abutting wall.
        const count=through?3:1,
              extent=count*sw,
              left=atStart?edge:edge-extent,
              right=atStart?edge+extent:edge;
        if(right-left>run.end-run.start||openings.some(o=>right>o.left-2*sw&&left<o.right+2*sw))continue;
        reserved.push([left,right]);
        for(let i=0;i<count;i++){
          const x=atStart?edge+i*sw:edge-(i+1)*sw;
          add(j.type,x,x+sw,bottom,top,c.studDepth);
        }
      }else{
        // "Corner - Outside 2 Stud": 1 end stud on through wall, 1 on abutting wall.
        const left=atStart?edge:edge-sw,
              right=atStart?edge+sw:edge;
        if(right-left>run.end-run.start||openings.some(o=>right>o.left-2*sw&&left<o.right+2*sw))continue;
        reserved.push([left,right]);
        add(j.type,left,right,bottom,top,c.studDepth);
      }
    }else{const center=Math.max(run.start+1.5*sw,Math.min(run.end-1.5*sw,j.x));if(openings.some(o=>center+1.5*sw>o.left-2*sw&&center-1.5*sw<o.right+2*sw))continue;reserved.push([center-1.5*sw,center+1.5*sw]);for(let i=-1;i<=1;i++)add(j.type,center+i*sw-sw/2,center+i*sw+sw/2,bottom,top)}
  }
  const xs=[run.start+sw/2,run.end-sw/2];for(let x=run.start+sw/2;x<=run.end-sw/2+.01;x+=c.spacing)xs.push(x);for(const x of xs.filter((x,i)=>!xs.slice(0,i).some(y=>Math.abs(x-y)<sw-.01))){if(x-sw/2<run.start-.01||x+sw/2>run.end+.01)continue;if(openings.some(o=>x+sw/2>o.left-2*sw&&x-sw/2<o.right+2*sw)||reserved.some(([a,b])=>x+sw/2>a+.01&&x-sw/2<b-.01))continue;add('Common stud',x-sw/2,x+sw/2,bottom,top)}
  return {wallId:w.id,members,issues};
}
function auditWallFraming(w){
  const layout=generateWallFraming(w),members=layout.members,issues=[...layout.issues],tol=1,c=construction(w),sw=construction(w).studWidth;
  const openings=hosted(w).filter(o=>o.host===w.id);
  for(const m of members){if(!Number.isFinite(m.x0)||!Number.isFinite(m.x1)||!Number.isFinite(m.z0)||!Number.isFinite(m.z1)||m.x1-m.x0<tol||m.z1-m.z0<tol)issues.push(`${m.id}: invalid member extents.`);if(m.x0 < -tol||m.x1>distance(w.a,w.b)+tol)issues.push(`${m.id}: member extends beyond the wall axis.`)}
  const byOpening=new Map();for(const o of openings)byOpening.set(o.id,members.filter(m=>['King stud','Jack stud','Header','Sill','Upper cripple','Lower cripple'].includes(m.type)&&Math.abs((m.x0+m.x1)/2-o.offset)<o.width/2+2*construction(w).studWidth));
  for(const o of openings){const ms=byOpening.get(o.id)||[];if(o.width>0&&o.height>0&&!ms.some(m=>m.type==='Header'))issues.push(`${o.id}: no valid header generated; check header clearance, overlap and opening location.`);if(o.width>0&&o.height>0&&(!ms.some(m=>m.type==='King stud')||!ms.some(m=>m.type==='Jack stud')))issues.push(`${o.id}: king/jack support studs are incomplete.`);const hs=ms.filter(m=>m.type==='Header');for(const h of hs){if(h.x0>o.left-sw+tol||h.x1<o.right+sw-tol)issues.push(`${o.id}: header does not extend at least one stud width beyond the opening on both ends.`)}}
  const run=framingRun(w),len=distance(w.a,w.b);
  return {wallId:w.id,memberCount:members.length,issues:[...new Set(issues)],valid:issues.length===0};
}
function framingWall(){return model.elements.find(e=>e.id===selected[0]&&e.type==='wall')||hostOf(model.elements.find(e=>e.id===selected[0])||{})||model.elements.find(e=>e.type==='wall'&&e.story===activeStory)}
function framingMemberWorld(w,m){const u=sub2(w.b,w.a),len=distance(w.a,w.b)||1,n={x:-u.y/len,y:u.x/len},core=coreGeometry(w),offset=referenceOffset(w)+core.center*(w.flipped?-1:1)+(m.lateralOffset||0),center=x=>({x:w.a.x+u.x*x/len+n.x*offset,y:w.a.y+u.y*x/len+n.y*offset}),a=center(m.x0),b=center(m.x1),half=m.depth/2;return [{x:a.x+n.x*half,y:a.y+n.y*half},{x:b.x+n.x*half,y:b.y+n.y*half},{x:b.x-n.x*half,y:b.y-n.y*half},{x:a.x-n.x*half,y:a.y-n.y*half}]}
function drawWallPanel(){const w=framingWall();if(!w){label('Select a wall to inspect its framing.',width/2,height/2,14);return}const layout=generateWallFraming(w),audit=auditWallFraming(w),len=distance(w.a,w.b),h=heightOf(w),s=Math.min((width-120)/len,(height-185)/h)*scale,ox=width/2-len*s/2+pan.x,oy=height/2+h*s/2+pan.y+30;rect(ox,oy-h*s,len*s,h*s,'#fbfcf8','#c6d3c1');for(const m of layout.members){const color=m.type==='Header'?'#b99969':m.type.includes('junction')||m.type==='Corner pack'?'#86977b':m.type==='King stud'?'#a79975':'#d1be93';rect(ox+m.x0*s,oy-m.z1*s,(m.x1-m.x0)*s,(m.z1-m.z0)*s,color,'#8c84654f',.6)}for(const o of hosted(w)){ctx.setLineDash([3,3]);rect(ox+(o.offset-o.width/2)*s,oy-(o.sill+o.height)*s,o.width*s,o.height*s,null,'#91a491',.7);ctx.setLineDash([]);label(o.id,ox+o.offset*s,oy-(o.sill+o.height/2)*s,10,'#8e9d87')}line({x:ox,y:oy+24},{x:ox+len*s,y:oy+24},'#95a58d',.8);label(`${w.id} · ${Math.round(len).toLocaleString()} × ${Math.round(h).toLocaleString()} mm`,width/2+pan.x,oy+39,10,'#7b8d74');label(`${layout.members.length} members · ${construction(w).spacing} mm O.C. · Sizes from wall construction settings`,width/2,height-34,10,'#8a9b81');if(audit.issues.length){const visible=audit.issues.slice(0,3);visible.forEach((issue,i)=>label('⚠ '+issue,width/2,height-54-i*14,9,'#a47849'));if(audit.issues.length>visible.length)label(`+ ${audit.issues.length-visible.length} more framing issue(s)`,width/2,height-54-visible.length*14,9,'#a47849')}}
function framingCutRows(walls=model.elements.filter(e=>e.type==='wall')){const map=new Map();for(const w of walls)for(const m of generateWallFraming(w).members){const key=[m.wallId,m.type,m.section,Math.round(m.length*10)/10].join('|'),row=map.get(key)||{wallId:w.id,type:m.type,section:m.section,length:Math.round(m.length*10)/10,quantity:0};row.quantity++;map.set(key,row)}return [...map.values()]}
function framingCSV(){return 'Element,Member,Section mm,Length mm,Quantity\n'+allFramingRows().map(r=>[r.wallId,r.type,r.section,r.length,r.quantity].map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\n')}
function framingProperties(w){const c=construction(w);return `<div class="section-header">WALL CONSTRUCTION</div>${choice('Structure','structure',w.structure||'basic',[['basic','Basic wall'],['composite','Composite wall']])}${w.structure==='composite'?choice('Composite','composite',w.composite||'timber140',Object.entries(WALL_COMPOSITES).map(([id,c])=>[id,c.name])):''}${choice('Reference','reference',w.reference||'center',[['inside','Inside face'],['center','Centerline'],['outside','Outside face'],['coreInside','Core inside'],['coreCenter','Core center'],['coreOutside','Core outside']])}<div class="wall-property-actions"><button class="subtle" data-wall-action="flip">${icon('mirror')} Flip orientation</button></div>${field('Join priority','priority',w.priority??(w.layer==='Exterior Walls'?100:50))}${field('Base offset','baseOffset',w.baseOffset||0,'mm')}${field('Top offset','topOffset',w.topOffset||0,'mm')}${choice('Top level','topStory',w.topStory||'', [['','Home story top'],...model.stories.filter(s=>s.elevation>storyOf(w).elevation).map(s=>[s.id,s.name])])}<div class="section-header">TIMBER FRAMING</div>${choice('Generate','framing.enabled',String(c.enabled),[['true','Enabled'],['false','Disabled']])}${choice('L corner','framing.cornerDetail',c.cornerDetail,[['threeStud','Wood Walls - Corner Outside, 3 Stud'],['twoStud','Corner - Outside 2 Stud'],['fourStud','Corner - Outside 4 Stud']])}${choice('T junction','framing.tDetail',c.tDetail,[['backingStud','Perpendicular backing stud'],['blocking','Horizontal backing blocks']])}${c.tDetail==='blocking'?field('Block spacing','framing.blockingSpacing',c.blockingSpacing,'mm'):''}${field('Stud width','framing.studWidth',c.studWidth,'mm')}${field('Stud depth','framing.studDepth',c.studDepth,'mm')}${field('Spacing O.C.','framing.spacing',c.spacing,'mm')}${field('Top plates','framing.topPlates',c.topPlates)}${field('Bottom plates','framing.bottomPlates',c.bottomPlates)}${field('Plate size','framing.plateThickness',c.plateThickness,'mm')}${field('Header depth','framing.headerDepth',c.headerDepth,'mm')}${field('Header plies','framing.headerPlies',c.headerPlies)}<div class="wall-property-actions"><button class="subtle" data-wall-action="cornerDetail">Corner 3-stud detail</button><button class="subtle" data-wall-action="panel">Wall panel</button><button class="subtle" data-wall-action="cutlist">Cut list</button></div><div class="empty-prop">Framing regenerates from this wall and its openings. Member sizes are construction inputs.</div>`}
function setWallProperty(w,key,value){if(key.startsWith('framing.')){const k=key.split('.')[1];if(k==='enabled')value=value==='true';else if(k==='cornerDetail'||k==='tDetail'){if(!(k==='cornerDetail'?['threeStud','twoStud','fourStud']:['backingStud','blocking']).includes(value))throw Error('Invalid junction detail.')}else if(!Number.isFinite(value)||value<=0||value>10000||(k==='spacing'&&value<20)||(k==='studWidth'&&value<10)||(['topPlates','bottomPlates','headerPlies'].includes(k)&&(!Number.isInteger(value)||value>6)))throw Error('Enter valid member sizes, spacing, or plate counts.');if(k==='spacing'&&value<construction(w).studWidth)throw Error('Stud spacing must be at least the stud width.');if(k==='studDepth'&&w.structure==='composite')throw Error('Composite stud depth follows the structural timber core.');if(k==='studWidth'&&value>construction(w).spacing)throw Error('Stud width cannot exceed the spacing.');w.framing={...construction(w),[k]:value};return true}
  if(['structure','composite'].includes(key)){w[key]=value;if(w.structure==='composite'){const preset=WALL_COMPOSITES[w.composite||'timber140'];w.skins=clone(preset.skins);w.thickness=w.skins.reduce((a,s)=>a+s.thickness,0)}return true}return false;
}
function framingRun(w){const len=distance(w.a,w.b),c=construction(w),u=sub2(w.b,w.a),unit={x:u.x/len,y:u.y/len};let start=0,end=len;for(const other of model.elements.filter(e=>e.type==='wall'&&e.id!==w.id&&e.story===w.story&&construction(e).enabled)){const v=sub2(other.b,other.a),vl=distance(other.a,other.b);if(Math.abs((u.x*v.x+u.y*v.y)/(len*vl))>.01)continue;for(const k of ['a','b']){const joinTolerance=(w.thickness+other.thickness)/2+1;const nearEnd=[other.a,other.b].some(p=>distance(p,w[k])<=joinTolerance),hit=segmentDistance(w[k],other.a,other.b);if(!nearEnd&&!(hit.distance<1&&hit.t>.001&&hit.t<.999))continue;const footprint=framingMemberWorld(other,{x0:-10000,x1:vl+10000,depth:construction(other).studDepth}),values=footprint.map(p=>(p.x-w.a.x)*unit.x+(p.y-w.a.y)*unit.y),lo=Math.min(...values),hi=Math.max(...values),through=nearEnd&&w.id.localeCompare(other.id)<0;if(k==='a')start=through?lo:hi;else end=through?hi:lo}}return {start,end}}
