/*
 * Advanced truss analysis (design-assist, ASD)
 * ------------------------------------------------
 * Load combinations : ASCE 7-16 Section 2.4 (ASD), roof live vs snow, balanced and unbalanced snow.
 * Member forces      : pin-jointed truss analysis per load case (linear superposition across combinations).
 * Chord bending      : panel-point loads applied as simple spans between panel points (standard TPI-style method).
 * Adjustment factors : NDS 2018 Sections 4.3 / 3.3 / 3.7 / 3.9 (CD, CM, Ct, CL, CF, Cr, Cp).
 * Checks             : tension, compression (with Cp), bending (with CL), shear, combined tension+bending (3.9.1),
 *                      combined compression+bending (3.9.2), slenderness le/d <= 50, deflection L/240 live and L/180 total.
 *
 * Reference design values: NDS 2018 Supplement, Table 4A, SPF No. 2 (2 in. and wider), dry service, normal duration.
 * Size factors CF and repetitive factor Cr are from NDS 2018 Table 4A notes and Section 4.3.9.
 *
 * NOT included: connector / plate design (needs manufacturer capacity data), wind and seismic combinations,
 * drift and sloped-roof snow coefficients (Cs), bearing checks, and lateral bracing design.
 * Output is for review by a licensed engineer. It is not a sealed calculation.
 */

import type { TrussStructure } from '../types/trussElevation';

export interface LumberProps {
  Fb: number; Ft: number; Fv: number; Fcp: number; Fc: number; E: number; Emin: number; // psi
}

/** NDS 2018 Supplement Table 4A, Spruce-Pine-Fir No. 2, 2 in. and wider (dry, normal duration). */
export const SPF_NO2: LumberProps = { Fb: 875, Ft: 575, Fv: 135, Fcp: 425, Fc: 1150, E: 1_400_000, Emin: 510_000 };

export interface AdvNode { id: number; x: number; y: number } // mm

export interface AdvMember {
  id: string;
  a: number;              // node id
  b: number;              // node id
  kind: 'top' | 'bottom' | 'web';
  widthMm: number;        // b (least dimension for weak-axis buckling)
  depthMm: number;        // d
  latInPlaneMm?: number;  // unbraced length for buckling in the truss plane (default: member length)
  latOutMm?: number;      // unbraced length for buckling out of the plane / lateral torsional (default: chordLatMm)
}

export interface AdvInput {
  nodes: AdvNode[];
  members: AdvMember[];
  spanMm: number;
  spacingMm: number;      // truss spacing (c/c)
  leftHeelId: number;
  rightHeelId: number;
  deadRoofPsf?: number;   // roof dead load (default 15)
  deadCeilingPsf?: number; // bottom-chord ceiling dead load (default 5)
  snowPsf?: number;       // roof snow load on the roof plane (default 20). Sloped-roof Cs NOT applied.
  liveRoofPsf?: number;   // roof live load (default 20), used in place of snow
  chordLatMm?: number;    // out-of-plane lateral support spacing for chords (default 600, sheathing)
  props?: LumberProps;    // default SPF_NO2
}

export interface ComboResult {
  name: string;
  CD: number;
  ratio: number;
  check: string;
}

export interface MemberCheck {
  id: string;
  kind: AdvMember['kind'];
  lengthMm: number;
  sizeLabel: string;
  maxTensionN: number;
  maxCompressionN: number;
  maxMomentNmm: number;
  maxShearN: number;
  ratios: { tension: number; compression: number; bending: number; shear: number; combinedTension: number; combinedCompression: number };
  slendernessMax: number;
  slendernessOk: boolean;
  governing: ComboResult;
  status: 'PASS' | 'FAIL';
}

export interface AdvReport {
  members: MemberCheck[];
  reactionsN: { left: number; right: number; leftDead: number; leftSnow: number };
  deflection: { midspanNode: number; liveMm: number; liveLimitMm: number; totalMm: number; totalLimitMm: number; liveOk: boolean; totalOk: boolean };
  unstable: boolean;
  overall: 'PASS' | 'FAIL';
  assumptions: string[];
  warnings: string[];
}

// ---------------------------------------------------------------- unit helpers
const PSI_PER_MPA = 145.0377;          // 1 MPa = 145.04 psi
const psiToMpa = (p: number) => p / PSI_PER_MPA;
const mmToIn = (mm: number) => mm / 25.4;
const PSF_TO_KPA = 0.0478803;

// NDS 2018 Table 4A size factors for dimension lumber (depth in inches -> [Fb, Ft, Fc]).
const CF_TABLE: [number, [number, number, number]][] = [
  [3.5, [1.5, 1.5, 1.15]],
  [5.5, [1.3, 1.3, 1.1]],
  [7.25, [1.2, 1.2, 1.05]],
  [9.25, [1.1, 1.1, 1.0]],
  [11.25, [1.0, 1.0, 1.0]],
];
export function sizeFactors(depthIn: number): [number, number, number] {
  let best = CF_TABLE[0];
  for (const row of CF_TABLE) if (Math.abs(row[0] - depthIn) < Math.abs(best[0] - depthIn)) best = row;
  return best[1];
}

// ---------------------------------------------------------------- NDS factors
/** NDS 3.7.1 column stability factor Cp, c = 0.8 for sawn lumber. */
export function columnCp(FcStar: number, FcE: number): number {
  const c = 0.8;
  const r = FcE / FcStar;
  const t = (1 + r) / (2 * c);
  return t - Math.sqrt(t * t - r / c);
}

/** NDS 3.7.1 Euler buckling stress for slenderness le/d (MPa in, MPa out). */
export function columnFcE(EminMpa: number, leOverD: number): number {
  return (0.822 * EminMpa) / (leOverD * leOverD);
}

/** NDS 3.3.3 lateral stability factor CL for a rectangular beam (lengths in inches, stresses in MPa). */
export function beamCL(FbStar: number, EminMpa: number, leIn: number, dIn: number, bIn: number): number {
  const RB = Math.min(50, Math.sqrt((leIn * dIn) / (bIn * bIn)));
  const FbE = (1.2 * EminMpa) / (RB * RB);
  const t = (1 + FbE / FbStar) / 1.9;
  return t - Math.sqrt(t * t - FbE / (0.95 * FbStar));
}

// ---------------------------------------------------------------- linear algebra
/** Gaussian elimination with partial pivoting. A pivot below a relative tolerance marks the system singular
 *  (a mechanism). Singular systems are reported, never silently solved. */
function solveDense(A: number[][], b: number[]): { x: number[]; singular: boolean } {
  const n = b.length;
  const M = A.map((row, i) => [...row, b[i]]);
  let scale = 0;
  for (const row of A) for (const v of row) scale = Math.max(scale, Math.abs(v));
  const tol = Math.max(1e-300, scale * 1e-10);
  let singular = false;
  for (let c = 0; c < n; c++) {
    let p = c;
    for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
    [M[c], M[p]] = [M[p], M[c]];
    const piv = M[c][c];
    if (Math.abs(piv) <= tol) { singular = true; continue; }
    for (let r = c + 1; r < n; r++) {
      const f = M[r][c] / piv;
      if (f === 0) continue;
      for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
    }
  }
  const x = new Array(n).fill(0);
  for (let r = n - 1; r >= 0; r--) {
    let s = M[r][n];
    for (let k = r + 1; k < n; k++) s -= M[r][k] * x[k];
    if (Math.abs(M[r][r]) <= tol) { singular = true; x[r] = 0; } else x[r] = s / M[r][r];
  }
  return { x, singular };
}

interface Geo { a: number; b: number; L: number; c: number; s: number; dxh: number }

/** Pin-jointed axial solve. loads in N (per node, per DOF order x,y). Tension positive. */
function solveAxial(nodeIdx: Map<number, number>, nodes: AdvNode[], geo: Geo[], EA: number[], loadsN: number[][], lh: number, rh: number, extraFixed: number[] = []) {
  const n = nodes.length, N = 2 * n;
  const K: number[][] = Array.from({ length: N }, () => new Array(N).fill(0));
  geo.forEach((g, i) => {
    const k = EA[i] / g.L;
    const d = [2 * g.a, 2 * g.a + 1, 2 * g.b, 2 * g.b + 1];
    const v = [-g.c, -g.s, g.c, g.s];
    for (let p = 0; p < 4; p++) for (let q = 0; q < 4; q++) K[d[p]][d[q]] += k * v[p] * v[q];
  });
  const fixed = new Set([2 * lh, 2 * lh + 1, 2 * rh + 1, ...extraFixed]);
  const free: number[] = [];
  for (let i = 0; i < N; i++) if (!fixed.has(i)) free.push(i);
  const Kf = free.map(i => free.map(j => K[i][j]));
  const u = new Array(N).fill(0);
  let singular = false;
  const sols = loadsN.map(F => {
    const bf = free.map(i => F[i]);
    const { x, singular: s } = solveDense(Kf, bf);
    if (s) singular = true;
    const uu = new Array(N).fill(0);
    free.forEach((dof, i) => (uu[dof] = x[i]));
    return uu;
  });
  void u;
  const forces = sols.map(uu => geo.map((g, i) => (EA[i] / g.L) * ((uu[2 * g.b] - uu[2 * g.a]) * g.c + (uu[2 * g.b + 1] - uu[2 * g.a + 1]) * g.s)));
  const reactions = sols.map((uu, k) => {
    // reaction = (K u)_dof - applied load at that dof (loads can sit on a support node, e.g. heel top-chord load)
    const r: number[] = [];
    for (const dof of fixed) {
      let s = -loadsN[k][dof];
      for (let j = 0; j < N; j++) s += K[dof][j] * uu[j];
      r.push(s);
    }
    return r;
  });
  void nodeIdx;
  return { forces, sols, reactions, unstable: singular };
}

function buildGeo(nodes: AdvNode[], ends: { a: number; b: number }[]): Geo[] {
  const idx = new Map(nodes.map((nd, i) => [nd.id, i]));
  return ends.map(e => {
    const A = nodes[idx.get(e.a)!], B = nodes[idx.get(e.b)!];
    const L = Math.hypot(B.x - A.x, B.y - A.y);
    return { a: idx.get(e.a)!, b: idx.get(e.b)!, L, c: (B.x - A.x) / L, s: (B.y - A.y) / L, dxh: Math.abs(B.x - A.x) };
  });
}

// ---------------------------------------------------------------- main analysis
export function analyzeTruss(inp: AdvInput): AdvReport {
  const props = inp.props ?? SPF_NO2;
  const deadRoof = (inp.deadRoofPsf ?? 15) * PSF_TO_KPA;
  const deadCeil = (inp.deadCeilingPsf ?? 5) * PSF_TO_KPA;
  const snow = (inp.snowPsf ?? 20) * PSF_TO_KPA;
  const live = (inp.liveRoofPsf ?? 20) * PSF_TO_KPA;
  const chordLat = inp.chordLatMm ?? 600;
  const spacingM = inp.spacingMm / 1000;
  const warnings: string[] = [];

  const nodeIdx = new Map(inp.nodes.map((nd, i) => [nd.id, i]));
  const nodes = inp.nodes;
  const geo: Geo[] = buildGeo(nodes, inp.members.map(m => ({ a: m.a, b: m.b })));
  const E_MPa = psiToMpa(props.E);
  const EA = inp.members.map((m, i) => E_MPa * m.widthMm * m.depthMm);
  const midX = inp.spanMm / 2;
  const isTop = (m: AdvMember) => m.kind === 'top';

  // ---- cantilever overhang tails. A top-chord member with a free end beyond the bearing points is a cantilever tail.
  // The pin-jointed model cannot carry a free end, so tails are removed from the stiffness matrix and their load is
  // transferred to the heel joint: a vertical load W at the heel, plus the moment M_z = W * (lever from heel) as an
  // equal and opposite horizontal pair at the heel-top and heel-bottom joints.
  const degree = new Map<number, number>();
  for (const m of inp.members) {
    degree.set(m.a, (degree.get(m.a) ?? 0) + 1);
    degree.set(m.b, (degree.get(m.b) ?? 0) + 1);
  }
  const bottomXs = inp.members.filter(m => m.kind === 'bottom').flatMap(m => [nodes[nodeIdx.get(m.a)!].x, nodes[nodeIdx.get(m.b)!].x]);
  const bxMin = bottomXs.length ? Math.min(...bottomXs) : Math.min(...nodes.map(n => n.x));
  const bxMax = bottomXs.length ? Math.max(...bottomXs) : Math.max(...nodes.map(n => n.x));
  const outsideBearing = (p: AdvNode) => p.x < bxMin - 1 || p.x > bxMax + 1;
  const tailInfo: ({ tailNode: number; heelNode: number } | null)[] = inp.members.map(m => {
    if (m.kind !== 'top') return null;
    const A = nodes[nodeIdx.get(m.a)!], B = nodes[nodeIdx.get(m.b)!];
    if (degree.get(m.a) === 1 && outsideBearing(A) && (degree.get(m.b) ?? 0) >= 2) return { tailNode: m.a, heelNode: m.b };
    if (degree.get(m.b) === 1 && outsideBearing(B) && (degree.get(m.a) ?? 0) >= 2) return { tailNode: m.b, heelNode: m.a };
    return null;
  });
  // Bottom-chord joint directly below each heel joint: lever arm (depth) for the couple.
  const heelBottom = new Map<number, { id: number; h: number }>();
  for (const t of tailInfo) {
    if (!t || heelBottom.has(t.heelNode)) continue;
    const H = nodes[nodeIdx.get(t.heelNode)!];
    const below = nodes.find(n => Math.abs(n.x - H.x) < 1 && Math.abs(n.y - Math.min(...nodes.map(q => q.y))) < 1e-3);
    const h = below ? H.y - below.y : 0;
    if (!below || !(h > 1)) {
      throw new Error(`Overhang tail at joint ${t.heelNode}: no separate bottom-chord joint below the heel, so the tail moment cannot be transferred. Add the heel member or model the tail separately.`);
    }
    heelBottom.set(t.heelNode, { id: below.id, h });
  }
  const EAsolve = EA.map((v, i) => (tailInfo[i] ? 0 : v));
  const tailDofs = tailInfo.flatMap(t => (t ? [2 * nodeIdx.get(t.tailNode)!, 2 * nodeIdx.get(t.tailNode)! + 1] : []));

  // ---- load cases: per-member perpendicular and vertical load intensity (kPa)
  type Case = 'D' | 'S' | 'SL' | 'SR' | 'Lr';
  const qFor = (m: AdvMember, mi: number, cs: Case): number => {
    const mid = (nodes[nodeIdx.get(m.a)!].x + nodes[nodeIdx.get(m.b)!].x) / 2;
    if (cs === 'D') return m.kind === 'top' ? deadRoof : m.kind === 'bottom' ? deadCeil : 0;
    if (!isTop(m)) return 0;
    if (cs === 'S') return snow;
    if (cs === 'Lr') return live;
    if (cs === 'SL') return mid <= midX ? snow : 0;
    if (cs === 'SR') return mid > midX ? snow : 0;
    void mi;
    return 0;
  };
  const caseNames: Case[] = ['D', 'S', 'SL', 'SR', 'Lr'];
  const caseData = caseNames.map(cs => {
    const loadsN = nodes.map(() => [0, 0]);
    const Mc: number[] = [], Vc: number[] = [];
    const perpN: number[] = [];
    inp.members.forEach((m, i) => {
      const q = qFor(m, i, cs);
      // Roof dead load is quoted per sloped surface area, so its vertical weight on a top chord is q*s*L (sloped length).
      // Snow and roof live load act per horizontal projection, so they use dxh.
      const projMm = (cs === 'D' && m.kind === 'top') ? geo[i].L : geo[i].dxh;
      const Vm = q * spacingM * projMm; // N on this member (vertical); kPa * m * mm = N
      const tail = tailInfo[i];
      if (tail) {
        const H = nodes[nodeIdx.get(tail.heelNode)!];
        const tailMidX = (nodes[nodeIdx.get(m.a)!].x + nodes[nodeIdx.get(m.b)!].x) / 2;
        const Mz = -(tailMidX - H.x) * Vm;        // moment of the tail load about the heel joint (N*mm)
        const hb = heelBottom.get(tail.heelNode)!;
        loadsN[nodeIdx.get(tail.heelNode)!][1] -= Vm;
        loadsN[nodeIdx.get(tail.heelNode)!][0] += -Mz / hb.h;   // horizontal couple pair across the heel depth
        loadsN[nodeIdx.get(hb.id)!][0] += Mz / hb.h;
        perpN.push(0);
        Mc.push(Vm * geo[i].dxh / 2);                 // cantilever root moment for uniform load over horizontal extent
        Vc.push(Vm);
        return;
      }
      loadsN[nodeIdx.get(m.a)!][1] -= Vm / 2;
      loadsN[nodeIdx.get(m.b)!][1] -= Vm / 2;
      const w = (Vm / geo[i].L) * geo[i].dxh / geo[i].L;     // N/mm perpendicular to member
      perpN.push(w);
      Mc.push((w * geo[i].L * geo[i].L) / 8);
      Vc.push((w * geo[i].L) / 2);
    });
    return { cs, loadsN, M: Mc, V: Vc };
  });
  const Fvec = caseData.map(c => {
    const f = new Array(2 * nodes.length).fill(0);
    c.loadsN.forEach((l, i) => { f[2 * i] = l[0]; f[2 * i + 1] = l[1]; });
    return f;
  });
  const solved = solveAxial(nodeIdx, nodes, geo, EAsolve, Fvec, nodeIdx.get(inp.leftHeelId)!, nodeIdx.get(inp.rightHeelId)!, tailDofs);
  const caseN: Record<Case, number[]> = { D: [], S: [], SL: [], SR: [], Lr: [] } as any;
  caseData.forEach((c, k) => (caseN[c.cs] = solved.forces[k]));
  const caseM: Record<Case, number[]> = {} as any, caseV: Record<Case, number[]> = {} as any;
  caseData.forEach(c => { caseM[c.cs] = c.M; caseV[c.cs] = c.V; });

  // reactions (vertical) for dead and snow
  const reactionsN = (() => {
    const k = caseNames.indexOf('D'), s = caseNames.indexOf('S');
    const rD = solved.reactions[k], rS = solved.reactions[s];
    return { left: rD[1] + rS[1] + 0, right: rD[2] + rS[2] + 0, leftDead: rD[1], leftSnow: rS[1] };
  })();

  // ---- deflection: unit load at TRUE midspan on the bottom chord.
  // If no bottom-chord node sits at midspan, the bottom-chord member spanning midspan is split by a virtual node
  // (same EA, collinear, unloaded), which leaves the structure unchanged but gives a midspan displacement.
  // If no bottom-chord member spans midspan, deflection cannot be verified and fails closed.
  const yMin = Math.min(...nodes.map(q => q.y));
  const isBottomNode = (nd: AdvNode) => Math.abs(nd.y - yMin) < 1e-3;
  const nodeAtMid = nodes.find(nd => isBottomNode(nd) && Math.abs(nd.x - midX) < 1);
  let midId: number | null = nodeAtMid ? nodeAtMid.id : null;
  let augNodes: AdvNode[] = nodes;
  let augEnds: { a: number; b: number }[] = inp.members.map(m => ({ a: m.a, b: m.b }));
  let augEA: number[] = EA;
  let origToAug: number[][] = inp.members.map((_, i) => [i]);
  if (midId === null) {
    const splitIdx = inp.members.findIndex(m => {
      if (m.kind !== 'bottom') return false;
      const A = nodes[nodeIdx.get(m.a)!], B = nodes[nodeIdx.get(m.b)!];
      return isBottomNode(A) && isBottomNode(B) && Math.min(A.x, B.x) < midX && midX < Math.max(A.x, B.x);
    });
    if (splitIdx >= 0) {
      midId = Math.max(...nodes.map(nd => nd.id)) + 1;
      const vid = midId;
      augNodes = [...nodes, { id: vid, x: midX, y: yMin }];
      augEnds = []; augEA = []; origToAug = [];
      inp.members.forEach((m, i) => {
        if (i === splitIdx) {
          origToAug.push([augEnds.length, augEnds.length + 1]);
          augEnds.push({ a: m.a, b: vid }, { a: vid, b: m.b });
          augEA.push(EA[i], EA[i]);
        } else {
          origToAug.push([augEnds.length]);
          augEnds.push({ a: m.a, b: m.b });
          augEA.push(EAsolve[i]);
        }
      });
    }
  }
  // Midspan deflection is verified only if a midspan point exists AND the pin-jointed model is stable with a unit load there.
  // A bottom chord with no node/web at midspan leaves that point unrestrained in the pin-jointed model, so it fails closed.
  let deflFound = midId !== null;
  let liveMm = NaN, totalMm = NaN;
  if (deflFound) {
    const augIdx = new Map(augNodes.map((nd, i) => [nd.id, i]));
    const augGeo = buildGeo(augNodes, augEnds);
    const unitVec = new Array(2 * augNodes.length).fill(0);
    unitVec[2 * augIdx.get(midId!)! + 1] = -1;
    const augTailDofs = tailInfo.flatMap(t => (t ? [2 * augIdx.get(t.tailNode)!, 2 * augIdx.get(t.tailNode)! + 1] : []));
    const unitSolve = solveAxial(augIdx, augNodes, augGeo, augEA, [unitVec], augIdx.get(inp.leftHeelId)!, augIdx.get(inp.rightHeelId)!, augTailDofs);
    if (unitSolve.unstable) {
      deflFound = false;
    } else {
      const nUnit = unitSolve.forces[0];
      // Unit-load method. A split member's force N is carried unchanged by both collinear halves.
      const defl = (N: number[]) => inp.members.reduce((sum, _m, i) =>
        sum + origToAug[i].reduce((t, k) => t + (augEA[k] > 0 ? N[i] * nUnit[k] * augGeo[k].L / augEA[k] : 0), 0), 0);
      liveMm = Math.abs(defl(caseN.S));
      totalMm = Math.abs(defl(caseN.D.map((v, i) => v + caseN.S[i])));
    }
  }
  const liveLimit = inp.spanMm / 240, totalLimit = inp.spanMm / 180;

  // ---- combinations (ASCE 7-16 Sec 2.4 ASD, subset relevant to roof trusses without wind)
  const combos: { name: string; f: Partial<Record<Case, number>>; CD: number }[] = [
    { name: 'D', f: { D: 1 }, CD: 0.9 },
    { name: 'D + S', f: { D: 1, S: 1 }, CD: 1.15 },
    { name: 'D + S (unbalanced, left)', f: { D: 1, SL: 1 }, CD: 1.15 },
    { name: 'D + S (unbalanced, right)', f: { D: 1, SR: 1 }, CD: 1.15 },
    { name: 'D + Lr', f: { D: 1, Lr: 1 }, CD: 1.25 },
  ];
  if (inp.snowPsf === undefined && inp.liveRoofPsf === undefined) warnings.push('Default loads used (dead 15 psf, snow 20 psf, live 20 psf). Replace with site-specific loads.');
  warnings.push('Snow: ground-to-roof value applied directly; sloped-roof coefficient Cs not applied. Drift not included.');

  const members: MemberCheck[] = inp.members.map((m, i) => {
    const g = geo[i];
    const b = m.widthMm, d = m.depthMm;
    const A = b * d, S = (b * d * d) / 6;
    const bIn = mmToIn(b), dIn = mmToIn(d);
    const [CFb, CFt, CFc] = sizeFactors(dIn);
    // NDS 4.3.9: repetitive member factor applies to chords only when members are spaced 24 in (610 mm) or less.
    const Cr = (isTop(m) || m.kind === 'bottom') && inp.spacingMm <= 609.6 ? 1.15 : 1.0;
    const leIP = m.latInPlaneMm ?? g.L;
    // Webs are not assumed restrained out of plane: default is the full member length (no bracing modelled).
    const leOP = m.latOutMm ?? (m.kind === 'web' ? g.L : chordLat);
    const slIP = mmToIn(leIP) / dIn, slOP = mmToIn(leOP) / bIn;
    const slMax = Math.max(slIP, slOP);
    const EminMpa = psiToMpa(props.Emin);

    let worst: ComboResult = { name: '', CD: 0, ratio: 0, check: '' };
    let maxT = 0, maxC = 0, maxM = 0, maxV = 0;
    const r = { tension: 0, compression: 0, bending: 0, shear: 0, combinedTension: 0, combinedCompression: 0 };

    for (const cb of combos) {
      const N = caseNames.reduce((s, cs) => s + (cb.f[cs] ?? 0) * caseN[cs][i], 0);
      const M = caseNames.reduce((s, cs) => s + (cb.f[cs] ?? 0) * (caseM[cs]?.[i] ?? 0), 0);
      const V = caseNames.reduce((s, cs) => s + (cb.f[cs] ?? 0) * (caseV[cs]?.[i] ?? 0), 0);
      maxT = Math.max(maxT, N); maxC = Math.max(maxC, -N); maxM = Math.max(maxM, Math.abs(M)); maxV = Math.max(maxV, Math.abs(V));
      const CD = cb.CD;
      const CM = 1, Ct = 1, Ci = 1, Cfu = 1;
      const Ft = psiToMpa(props.Ft) * CD * CM * Ct * CFt * Cfu * Ci * Cr;
      const FbStar = psiToMpa(props.Fb) * CD * CM * Ct * CFb * Cfu * Ci * Cr; // before CL
      const FcStar = psiToMpa(props.Fc) * CD * CM * Ct * CFc * Ci;
      const Fv = psiToMpa(props.Fv) * CD * CM * Ct * Ci;
      const CL = isTop(m) || m.kind === 'bottom' ? beamCL(FbStar, EminMpa, mmToIn(leOP), dIn, bIn) : 1;
      const Fb = FbStar * CL;
      const FcEip = columnFcE(EminMpa, slIP), FcEop = columnFcE(EminMpa, slOP);
      const CpIP = columnCp(FcStar, FcEip), CpOP = columnCp(FcStar, FcEop);
      const Cp = Math.min(CpIP, CpOP);
      const FcE = slIP >= slOP ? FcEip : FcEop;
      const Fc = FcStar * Cp;

      const fb = M / S, fv = (1.5 * Math.abs(V)) / A;
      const rb = fb / Fb, rv = fv / Fv;
      let rt = 0, rc = 0, rct = 0, rcc = 0;
      if (N > 0) { const ft = N / A; rt = ft / Ft; rct = rt + rb; }
      if (N < 0) { const fc = -N / A; rc = fc / Fc; rcc = rc * rc + (Fb > 0 && fc / FcE < 1 ? fb / (Fb * (1 - fc / FcE)) : Infinity); }
      r.tension = Math.max(r.tension, rt);
      r.compression = Math.max(r.compression, rc);
      r.bending = Math.max(r.bending, rb);
      r.shear = Math.max(r.shear, rv);
      r.combinedTension = Math.max(r.combinedTension, rct);
      r.combinedCompression = Math.max(r.combinedCompression, rcc);
      const cands: [number, string][] = [[rt, 'tension'], [rc, 'compression'], [rb, 'bending'], [rv, 'shear'], [rct, 'combined tension + bending'], [rcc, 'combined compression + bending']];
      for (const [v, label] of cands) if (v > worst.ratio) worst = { name: cb.name, CD, ratio: v, check: label };
    }
    // NDS 3.7.1.4: le/d <= 50 applies to members that carry compression. Tension-only members use the tension limit
    // below (80 is a conservative value to verify against NDS 2018 section 4.4.1 for the edition in use).
    const slendernessLimit = maxC > 0 ? 50 : 80;
    const slenderOk = slMax <= slendernessLimit;
    if (!slenderOk) warnings.push(`${m.id}: slenderness ${slMax.toFixed(0)} exceeds ${slendernessLimit} (${maxC > 0 ? 'compression, NDS 3.7.1.4' : 'tension-only, verify NDS 4.4.1 limit'}).`);
    const status: 'PASS' | 'FAIL' = worst.ratio <= 1 && slenderOk ? 'PASS' : 'FAIL';
    return {
      id: m.id, kind: m.kind, lengthMm: Number(g.L.toFixed(1)), sizeLabel: `${b}x${d}`,
      maxTensionN: Number(maxT.toFixed(0)), maxCompressionN: Number(maxC.toFixed(0)), maxMomentNmm: Number(maxM.toFixed(0)), maxShearN: Number(maxV.toFixed(0)),
      ratios: Object.fromEntries(Object.entries(r).map(([k, v]) => [k, Number((v as number).toFixed(3))])) as MemberCheck['ratios'],
      slendernessMax: Number(slMax.toFixed(1)), slendernessOk: slenderOk, governing: { ...worst, ratio: Number(worst.ratio.toFixed(3)) }, status,
    };
  });

  const deflOk = deflFound && liveMm <= liveLimit && totalMm <= totalLimit;
  if (!deflFound) warnings.push('Midspan deflection could not be verified: no stable bottom-chord point at midspan in the pin-jointed model (add a midspan bottom-chord node / web). Deflection is treated as FAIL.');
  const overall: 'PASS' | 'FAIL' = members.every(m => m.status === 'PASS') && deflOk && !solved.unstable ? 'PASS' : 'FAIL';
  if (solved.unstable) warnings.push('Truss is unstable under the pin-jointed model: check web layout and supports.');

  return {
    members,
    reactionsN: { left: Math.round(reactionsN.left), right: Math.round(reactionsN.right), leftDead: Math.round(reactionsN.leftDead), leftSnow: Math.round(reactionsN.leftSnow) },
    deflection: { midspanNode: midId ?? 0, liveMm: Number(liveMm.toFixed(2)), liveLimitMm: Number(liveLimit.toFixed(1)), totalMm: Number(totalMm.toFixed(2)), totalLimitMm: Number(totalLimit.toFixed(1)), liveOk: deflFound && liveMm <= liveLimit, totalOk: deflFound && totalMm <= totalLimit },
    unstable: solved.unstable,
    overall,
    assumptions: [
      'Reference design values: NDS 2018 Supplement Table 4A, SPF No. 2 (2 in. and wider), dry, normal duration. Verify against your NDS edition before use.',
      'Load combinations: ASCE 7-16 Section 2.4 ASD (D, D+S, D+S unbalanced, D+Lr). Wind and seismic not included.',
      'Load duration: CD 0.9 (dead), 1.15 (snow), 1.25 (roof live), per NDS Table 2.3.2.',
      'Slenderness limit: le/d <= 50 for members in compression (NDS 3.7.1.4); tension-only members use 80, which must be verified against NDS 2018 section 4.4.1 for the edition in use.',
      'Overhang tails are cantilevers: their load is transferred to the heel joint (vertical load plus couple). Tail stiffness and tail deflection are not included in the deflection check; the tail is checked for bending and shear only.',
      'Repetitive member factor Cr = 1.15 applied to chords when spacing is 24 in (610 mm) or less (NDS 4.3.9); otherwise Cr = 1. Webs use Cr = 1. Confirm the three-or-more repetitive-member condition in the layout.',
      'Chord bending from panel loads as simple spans between panel points. Truss analysed as pin-jointed for axial forces.',
      'Column stability (NDS 3.7) uses Emin and le/d for both axes; the controlling Cp is used. Lateral torsional stability (NDS 3.3.3) uses CL with the out-of-plane support spacing.',
      'Deflection: live (snow) L/240 and total (dead + snow) L/180 at true midspan on the bottom chord, using NDS E and the unit-load method. Chord flexure from panel loads and long-term creep are NOT included, so total deflection is approximate.',
      'Roof dead load is treated as per sloped surface area (weight on sloped length). Snow and roof live load are per horizontal projection. Confirm the input basis.',
      'Web members are assumed unbraced out of plane over their full length unless a bracing spacing is provided. Chord out-of-plane restraint uses the chord lateral spacing input.',
      'Connectors and plates are NOT designed here. Joint capacity must be checked against manufacturer data.',
    ],
    warnings,
  };
}

// ---------------------------------------------------------------- adapter from the app's TrussStructure
/** Build an AdvInput from a TrussStructure (node x/y in metres, section width/depth in mm). */
export function advInputFromTruss(t: TrussStructure, opts: Partial<AdvInput> = {}): AdvInput {
  const nodes: AdvNode[] = t.nodes.map(n => ({ id: n.id, x: n.x * 1000, y: n.y * 1000 }));
  const members: AdvMember[] = t.members.map(m => ({
    id: m.id,
    a: m.startNodeId,
    b: m.endNodeId,
    kind: m.type === 'top_chord' ? 'top' : m.type === 'bottom_chord' ? 'bottom' : 'web',
    widthMm: m.section.width,
    depthMm: m.section.depth,
  }));
  const bottom = nodes.filter(n => Math.abs(n.y - Math.min(...nodes.map(q => q.y))) < 1e-3).sort((p, q) => p.x - q.x);
  return {
    nodes,
    members,
    spanMm: t.span * 1000,
    spacingMm: t.spacing * 1000,
    leftHeelId: bottom[0].id,
    rightHeelId: bottom[bottom.length - 1].id,
    ...opts,
  };
}

/** Markdown calculation summary. */
export function reportToMarkdown(title: string, r: AdvReport): string {
  const L: string[] = [];
  L.push(`# ${title}`, '', `**Overall: ${r.overall}**`, '');
  L.push('## Reactions (ASD, unfactored)', '', `- Left: ${r.reactionsN.left} N (dead ${r.reactionsN.leftDead} N, snow ${r.reactionsN.leftSnow} N)`, `- Right: ${r.reactionsN.right} N`, '');
  L.push('## Deflection', '', `- Midspan node ${r.deflection.midspanNode}`);
  L.push(`- Live (snow): ${r.deflection.liveMm} mm, limit L/240 = ${r.deflection.liveLimitMm} mm, ${r.deflection.liveOk ? 'OK' : 'FAIL'}`);
  L.push(`- Total (dead + snow): ${r.deflection.totalMm} mm, limit L/180 = ${r.deflection.totalLimitMm} mm, ${r.deflection.totalOk ? 'OK' : 'FAIL'}`, '');
  L.push('## Member checks', '', '| Member | Type | Size | Length (mm) | Max T (N) | Max C (N) | Max M (N·mm) | Governing | Ratio | Status |', '|---|---|---|---|---|---|---|---|---|---|');
  for (const m of r.members) {
    L.push(`| ${m.id} | ${m.kind} | ${m.sizeLabel} | ${m.lengthMm} | ${m.maxTensionN} | ${m.maxCompressionN} | ${m.maxMomentNmm} | ${m.governing.check} (${m.governing.name}) | ${m.governing.ratio} | ${m.status} |`);
  }
  L.push('', '## Assumptions', '', ...r.assumptions.map(a => `- ${a}`), '');
  if (r.warnings.length) L.push('## Warnings', '', ...r.warnings.map(w => `- ${w}`), '');
  L.push('> Design-assist output. Requires review and sealing by a licensed engineer. Connectors not designed.');
  return L.join('\n');
}

/** Pin-jointed axial forces for a single load set (tension positive). Used for checks and by the CLI. */
export function pinJointedAxial(nodes: AdvNode[], members: { a: number; b: number; EA: number }[], loadN: Record<number, [number, number]>, leftId: number, rightId: number): number[] {
  const nodeIdx = new Map(nodes.map((nd, i) => [nd.id, i]));
  const geo: Geo[] = members.map(m => {
    const A = nodes[nodeIdx.get(m.a)!], B = nodes[nodeIdx.get(m.b)!];
    const L = Math.hypot(B.x - A.x, B.y - A.y);
    return { a: nodeIdx.get(m.a)!, b: nodeIdx.get(m.b)!, L, c: (B.x - A.x) / L, s: (B.y - A.y) / L, dxh: Math.abs(B.x - A.x) };
  });
  const F = new Array(2 * nodes.length).fill(0);
  for (const [id, [fx, fy]] of Object.entries(loadN)) { const i = nodeIdx.get(Number(id))!; F[2 * i] = fx; F[2 * i + 1] = fy; }
  return solveAxial(nodeIdx, nodes, geo, members.map(m => m.EA), [F], nodeIdx.get(leftId)!, nodeIdx.get(rightId)!).forces[0];
}
